import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HistorySearch.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Search, Star, X } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistorySearch.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
export function HistorySearch({ value, favoriteOnly, inputRef, onChange, onToggleFavorites }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "history-search-panel",
		role: "search",
		"aria-label": "Recherche dans l’historique",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "history-search-heading",
			children: /* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "history-search-input",
				children: "Rechercher"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "history-search",
			children: [
				/* @__PURE__ */ _jsxDEV(Search, {
					className: "history-search-icon",
					size: 16,
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: "history-search-input",
					ref: inputRef,
					type: "text",
					value,
					onChange: (event) => onChange(event.target.value),
					placeholder: "Titres, questions…",
					"aria-label": "Rechercher dans l’historique",
					autoComplete: "off"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this),
				value && /* @__PURE__ */ _jsxDEV("button", {
					className: "history-search-clear",
					"aria-label": "Effacer la recherche",
					onClick: () => onChange(""),
					children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "history-search-divider",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: `history-search-favorites${favoriteOnly ? " favorite-filter-active" : ""}`,
					"aria-label": favoriteOnly ? "Afficher tout l’historique" : "Filtrer les favoris",
					"aria-pressed": favoriteOnly,
					title: favoriteOnly ? "Afficher tout l’historique" : "Filtrer les favoris",
					onClick: onToggleFavorites,
					children: /* @__PURE__ */ _jsxDEV(Star, {
						size: 15,
						fill: favoriteOnly ? "currentColor" : "none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = HistorySearch;
var _c;
$RefreshReg$(_c, "HistorySearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/HistorySearch.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistorySearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistorySearch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistorySearch.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLE1BQU0sU0FBUzs7O0FBV2hDLE9BQU8sU0FBUyxjQUFjLEVBQUUsT0FBTyxjQUFjLFVBQVUsVUFBVSxxQkFBNEI7Q0FDbkcsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUF1QixNQUFLO0VBQVMsY0FBVztZQUEvRCxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsU0FBRDtJQUFPLFNBQVE7Y0FBdUI7R0FBaUI7Ozs7O0VBQ3BEOzs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFFBQUQ7S0FBUSxXQUFVO0tBQXNCLE1BQU07S0FBSSxlQUFZO0lBQVE7Ozs7O0lBQ3RFLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsS0FBSztLQUNMLE1BQUs7S0FDRTtLQUNQLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO0tBQ2hELGFBQVk7S0FDWixjQUFXO0tBQ1gsY0FBYTtJQUNkOzs7OztJQUNBLFNBQ0Msd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBdUIsY0FBVztLQUF1QixlQUFlLFNBQVMsRUFBRTtlQUNuRyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztJQUNSOzs7OztJQUVWLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO0tBQXlCLGVBQVk7SUFBUTs7Ozs7SUFDN0Qsd0JBQUMsVUFBRDtLQUNFLFdBQVcsMkJBQTJCLGVBQWUsNEJBQTRCO0tBQ2pGLGNBQVksZUFBZSwrQkFBK0I7S0FDMUQsZ0JBQWM7S0FDZCxPQUFPLGVBQWUsK0JBQStCO0tBQ3JELFNBQVM7ZUFFVCx3QkFBQyxNQUFEO01BQU0sTUFBTTtNQUFJLE1BQU0sZUFBZSxpQkFBaUI7S0FBUzs7Ozs7SUFDekQ7Ozs7O0dBQ0w7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhpc3RvcnlTZWFyY2gudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaCwgU3RhciwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBSZWZPYmplY3QgfSBmcm9tICdyZWFjdCdcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgdmFsdWU6IHN0cmluZ1xyXG4gIGZhdm9yaXRlT25seTogYm9vbGVhblxyXG4gIGlucHV0UmVmOiBSZWZPYmplY3Q8SFRNTElucHV0RWxlbWVudCB8IG51bGw+XHJcbiAgb25DaGFuZ2U6ICh2YWx1ZTogc3RyaW5nKSA9PiB2b2lkXHJcbiAgb25Ub2dnbGVGYXZvcml0ZXM6ICgpID0+IHZvaWRcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEhpc3RvcnlTZWFyY2goeyB2YWx1ZSwgZmF2b3JpdGVPbmx5LCBpbnB1dFJlZiwgb25DaGFuZ2UsIG9uVG9nZ2xlRmF2b3JpdGVzIH06IFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1zZWFyY2gtcGFuZWxcIiByb2xlPVwic2VhcmNoXCIgYXJpYS1sYWJlbD1cIlJlY2hlcmNoZSBkYW5zIGzigJloaXN0b3JpcXVlXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1zZWFyY2gtaGVhZGluZ1wiPlxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwiaGlzdG9yeS1zZWFyY2gtaW5wdXRcIj5SZWNoZXJjaGVyPC9sYWJlbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1zZWFyY2hcIj5cclxuICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImhpc3Rvcnktc2VhcmNoLWljb25cIiBzaXplPXsxNn0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPVwiaGlzdG9yeS1zZWFyY2gtaW5wdXRcIlxyXG4gICAgICAgICAgcmVmPXtpbnB1dFJlZn1cclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRpdHJlcywgcXVlc3Rpb25z4oCmXCJcclxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJSZWNoZXJjaGVyIGRhbnMgbOKAmWhpc3RvcmlxdWVcIlxyXG4gICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIHt2YWx1ZSAmJiAoXHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImhpc3Rvcnktc2VhcmNoLWNsZWFyXCIgYXJpYS1sYWJlbD1cIkVmZmFjZXIgbGEgcmVjaGVyY2hlXCIgb25DbGljaz17KCkgPT4gb25DaGFuZ2UoJycpfT5cclxuICAgICAgICAgICAgPFggc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpc3Rvcnktc2VhcmNoLWRpdmlkZXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGhpc3Rvcnktc2VhcmNoLWZhdm9yaXRlcyR7ZmF2b3JpdGVPbmx5ID8gJyBmYXZvcml0ZS1maWx0ZXItYWN0aXZlJyA6ICcnfWB9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtmYXZvcml0ZU9ubHkgPyAnQWZmaWNoZXIgdG91dCBs4oCZaGlzdG9yaXF1ZScgOiAnRmlsdHJlciBsZXMgZmF2b3Jpcyd9XHJcbiAgICAgICAgICBhcmlhLXByZXNzZWQ9e2Zhdm9yaXRlT25seX1cclxuICAgICAgICAgIHRpdGxlPXtmYXZvcml0ZU9ubHkgPyAnQWZmaWNoZXIgdG91dCBs4oCZaGlzdG9yaXF1ZScgOiAnRmlsdHJlciBsZXMgZmF2b3Jpcyd9XHJcbiAgICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZUZhdm9yaXRlc31cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8U3RhciBzaXplPXsxNX0gZmlsbD17ZmF2b3JpdGVPbmx5ID8gJ2N1cnJlbnRDb2xvcicgOiAnbm9uZSd9IC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==