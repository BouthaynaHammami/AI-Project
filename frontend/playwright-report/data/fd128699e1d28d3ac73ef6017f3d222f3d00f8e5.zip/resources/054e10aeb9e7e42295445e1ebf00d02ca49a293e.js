import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Sidebar.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { BarChart3, ChevronDown, LogOut, Plus, Settings, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import { groupByDate } from "/src/utils/history.ts";
import { HistoryGroup } from "/src/components/HistoryGroup.tsx";
import { HistorySearch } from "/src/components/HistorySearch.tsx";
import { UndoToast } from "/src/components/UndoToast.tsx";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/Sidebar.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$();
export function Sidebar({ userName, profilePhoto, history, activeId, query = "", favoriteOnly = false, loading = false, hasMore = false, error = "", undoEntry = null, cascadePrompt = null, onNew, onHistory, onSettings, onLogout, onSearch, onLoadMore, onRetry, onRename, onToggleFavorite, onRemove, onUndoRemove, onConfirmCascade, onCancelCascade }) {
	_s();
	const [historyOpen, setHistoryOpen] = useState(false);
	const [search, setSearch] = useState(query);
	const [favorites, setFavorites] = useState(favoriteOnly);
	const [editingId, setEditingId] = useState(null);
	const searchRef = useRef(null);
	useEffect(() => setSearch(query), [query]);
	useEffect(() => setFavorites(favoriteOnly), [favoriteOnly]);
	useEffect(() => {
		if (!onSearch) return;
		const timer = window.setTimeout(() => onSearch(search, favorites), 300);
		return () => window.clearTimeout(timer);
	}, [
		favorites,
		onSearch,
		search
	]);
	const groups = groupByDate(history);
	const groupTitles = [
		["today", "Aujourd’hui"],
		["yesterday", "Hier"],
		["thisWeek", "Cette semaine"],
		["older", "Plus ancien"]
	];
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "sidebar",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sidebar-top",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "brand-mark",
					children: /* @__PURE__ */ _jsxDEV(BarChart3, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 64
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 36
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["AI Data ", /* @__PURE__ */ _jsxDEV("b", { children: "Analyst" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 107
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 93
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sidebar-user-card",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "sidebar-user-avatar",
					children: profilePhoto ? /* @__PURE__ */ _jsxDEV("img", {
						src: profilePhoto,
						alt: "Photo de profil"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 62
					}, this) : /* @__PURE__ */ _jsxDEV(UserRound, { size: 15 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 113
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "sidebar-user-meta",
					children: /* @__PURE__ */ _jsxDEV("strong", { children: userName }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 44
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: "new-analysis",
				onClick: onNew,
				children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 17 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 56
				}, this), " Nouvelle analyse"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this),
			onSearch && /* @__PURE__ */ _jsxDEV(HistorySearch, {
				value: search,
				favoriteOnly: favorites,
				inputRef: searchRef,
				onChange: setSearch,
				onToggleFavorites: () => setFavorites((current) => !current)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: `history-heading ${historyOpen ? "history-heading-open" : ""}`,
				onClick: () => setHistoryOpen((open) => !open),
				"aria-expanded": historyOpen,
				children: [/* @__PURE__ */ _jsxDEV("span", { children: "Historique" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "history-heading-right",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "history-count",
						children: history.length
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 49
					}, this), /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 104
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			historyOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "history-list",
				children: [
					history.length ? groupTitles.map(([key, title]) => /* @__PURE__ */ _jsxDEV(HistoryGroup, {
						title,
						items: groups[key],
						activeId,
						query: search,
						editingId,
						onHistory,
						onStartRename: setEditingId,
						onRename: async (item, nextTitle) => {
							await onRename?.(item, nextTitle);
							setEditingId(null);
						},
						onCancelRename: () => setEditingId(null),
						onToggleFavorite: (item) => onToggleFavorite?.(item) ?? Promise.resolve(),
						onRemove: (item) => onRemove?.(item) ?? Promise.resolve()
					}, key, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this)) : /* @__PURE__ */ _jsxDEV("p", {
						className: "history-empty",
						children: loading ? "Chargement de l’historique…" : "Aucune analyse enregistrée."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 16
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						className: "history-error",
						role: "alert",
						children: [error, /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onRetry,
							children: "Réessayer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 70
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 21
					}, this),
					hasMore && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onLoadMore,
						disabled: loading,
						children: loading ? "Chargement…" : "Charger plus"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 23
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 9
			}, this),
			cascadePrompt && /* @__PURE__ */ _jsxDEV("div", {
				role: "alertdialog",
				"aria-label": "Supprimer la conversation",
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: "Cette action supprimera toute la conversation." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onConfirmCascade,
						children: "Supprimer"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onCancelCascade,
						children: "Annuler"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 9
			}, this),
			undoEntry && /* @__PURE__ */ _jsxDEV(UndoToast, {
				message: "Analyse supprimée.",
				onUndo: () => onUndoRemove?.()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 21
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sidebar-bottom",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "sidebar-action",
					onClick: onSettings,
					children: [/* @__PURE__ */ _jsxDEV(Settings, { size: 17 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 65
					}, this), " Paramètres"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "sidebar-action logout",
					onClick: onLogout,
					children: [/* @__PURE__ */ _jsxDEV(LogOut, { size: 17 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 70
					}, this), " Déconnexion"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
}
_s(Sidebar, "dfWgA7mrYe5FD/w15Pv796b/0+U=");
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Sidebar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/Sidebar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGFBQWEsUUFBUSxNQUFNLFVBQVUsaUJBQWlCO0FBQzFFLFNBQVMsV0FBVyxRQUFRLGdCQUFnQjtBQUU1QyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGlCQUFpQjs7OztBQTZCMUIsT0FBTyxTQUFTLFFBQVEsRUFDdEIsVUFBVSxjQUFjLFNBQVMsVUFBVSxRQUFRLElBQUksZUFBZSxPQUN0RSxVQUFVLE9BQU8sVUFBVSxPQUFPLFFBQVEsSUFBSSxZQUFZLE1BQzFELGdCQUFnQixNQUFNLE9BQU8sV0FBVyxZQUFZLFVBQVUsVUFDOUQsWUFBWSxTQUFTLFVBQVUsa0JBQWtCLFVBQVUsY0FDM0Qsa0JBQWtCLG1CQUNWOztDQUNSLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsWUFBWTtDQUN2RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBd0IsSUFBSTtDQUM5RCxNQUFNLFlBQVksT0FBeUIsSUFBSTtDQUUvQyxnQkFBZ0IsVUFBVSxLQUFLLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDekMsZ0JBQWdCLGFBQWEsWUFBWSxHQUFHLENBQUMsWUFBWSxDQUFDO0NBQzFELGdCQUFnQjtFQUNkLElBQUksQ0FBQyxVQUFVO0VBQ2YsTUFBTSxRQUFRLE9BQU8saUJBQWlCLFNBQVMsUUFBUSxTQUFTLEdBQUcsR0FBRztFQUN0RSxhQUFhLE9BQU8sYUFBYSxLQUFLO0NBQ3hDLEdBQUc7RUFBQztFQUFXO0VBQVU7Q0FBTSxDQUFDO0NBRWhDLE1BQU0sU0FBUyxZQUFZLE9BQU87Q0FDbEMsTUFBTSxjQUFjO0VBQ2xCLENBQUMsU0FBUyxhQUFhO0VBQ3ZCLENBQUMsYUFBYSxNQUFNO0VBQ3BCLENBQUMsWUFBWSxlQUFlO0VBQzVCLENBQUMsU0FBUyxhQUFhO0NBQ3pCO0NBRUEsT0FDRSx3QkFBQyxTQUFEO0VBQU8sV0FBVTtZQUFqQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBNkIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBYSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7OztJQUFNOzs7O2NBQUMsd0JBQUMsUUFBRCxhQUFNLFlBQVEsd0JBQUMsS0FBRCxZQUFHLFVBQVU7Ozs7WUFBTzs7OztZQUFNOzs7Ozs7R0FDOUgsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQXVCLGVBQWUsd0JBQUMsT0FBRDtNQUFLLEtBQUs7TUFBYyxLQUFJO0tBQW1COzs7O2dCQUFJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O0lBQU87Ozs7Y0FDckksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBb0Isd0JBQUMsVUFBRCxZQUFTLFNBQWlCOzs7OztJQUFNOzs7O1lBQ2hFOzs7Ozs7R0FDTCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFlLFNBQVM7Y0FBMUMsQ0FBaUQsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztjQUFDLG1CQUF5Qjs7Ozs7O0dBQzNGLFlBQ0Msd0JBQUMsZUFBRDtJQUNFLE9BQU87SUFDUCxjQUFjO0lBQ2QsVUFBVTtJQUNWLFVBQVU7SUFDVix5QkFBeUIsY0FBYyxZQUFZLENBQUMsT0FBTztHQUM1RDs7Ozs7R0FFSCx3QkFBQyxVQUFEO0lBQVEsV0FBVyxtQkFBbUIsY0FBYyx5QkFBeUI7SUFBTSxlQUFlLGdCQUFnQixTQUFTLENBQUMsSUFBSTtJQUFHLGlCQUFlO2NBQWxKLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2NBQ3RCLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQXdDLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFpQixRQUFRO0tBQWE7Ozs7ZUFBQyx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O2FBQU87Ozs7O1lBQ3hIOzs7Ozs7R0FDUCxlQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRyxRQUFRLFNBQVMsWUFBWSxLQUFLLENBQUMsS0FBSyxXQUN2Qyx3QkFBQyxjQUFEO01BRVM7TUFDUCxPQUFPLE9BQU87TUFDSjtNQUNWLE9BQU87TUFDSTtNQUNBO01BQ1gsZUFBZTtNQUNmLFVBQVUsT0FBTyxNQUFNLGNBQWM7T0FDbkMsTUFBTSxXQUFXLE1BQU0sU0FBUztPQUNoQyxhQUFhLElBQUk7TUFDbkI7TUFDQSxzQkFBc0IsYUFBYSxJQUFJO01BQ3ZDLG1CQUFtQixTQUFTLG1CQUFtQixJQUFJLEtBQUssUUFBUSxRQUFRO01BQ3hFLFdBQVcsU0FBUyxXQUFXLElBQUksS0FBSyxRQUFRLFFBQVE7S0FDekQsR0FmTTs7OztZQWVOLENBQ0YsSUFBSSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBaUIsVUFBVSxnQ0FBZ0M7S0FBaUM7Ozs7O0tBQzdHLFNBQVMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7TUFBZ0IsTUFBSztnQkFBbEMsQ0FBMkMsT0FBTSx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFNBQVM7aUJBQVM7TUFBaUI7Ozs7Y0FBSTs7Ozs7O0tBQ3ZILFdBQVcsd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxTQUFTO01BQVksVUFBVTtnQkFBVSxVQUFVLGdCQUFnQjtLQUF1Qjs7Ozs7SUFDekg7Ozs7OztHQUVOLGlCQUNDLHdCQUFDLE9BQUQ7SUFBSyxNQUFLO0lBQWMsY0FBVztjQUFuQztLQUNFLHdCQUFDLEtBQUQsWUFBRyxpREFBaUQ7Ozs7O0tBQ3BELHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsU0FBUztnQkFBa0I7S0FBaUI7Ozs7O0tBQ2xFLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsU0FBUztnQkFBaUI7S0FBZTs7Ozs7SUFDNUQ7Ozs7OztHQUVOLGFBQWEsd0JBQUMsV0FBRDtJQUFXLFNBQVE7SUFBcUIsY0FBYyxlQUFlO0dBQUk7Ozs7O0dBQ3ZGLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFpQixTQUFTO2VBQTVDLENBQXdELHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7ZUFBQyxhQUFtQjs7Ozs7Y0FDakcsd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBd0IsU0FBUztlQUFuRCxDQUE2RCx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O2VBQUMsY0FBb0I7Ozs7O1lBQ2xHOzs7Ozs7RUFDQTs7Ozs7O0FBRVgiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2lkZWJhci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmFyQ2hhcnQzLCBDaGV2cm9uRG93biwgTG9nT3V0LCBQbHVzLCBTZXR0aW5ncywgVXNlclJvdW5kIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBIaXN0b3J5RW50cnkgfSBmcm9tICcuLi90eXBlcydcclxuaW1wb3J0IHsgZ3JvdXBCeURhdGUgfSBmcm9tICcuLi91dGlscy9oaXN0b3J5J1xyXG5pbXBvcnQgeyBIaXN0b3J5R3JvdXAgfSBmcm9tICcuL0hpc3RvcnlHcm91cCdcclxuaW1wb3J0IHsgSGlzdG9yeVNlYXJjaCB9IGZyb20gJy4vSGlzdG9yeVNlYXJjaCdcclxuaW1wb3J0IHsgVW5kb1RvYXN0IH0gZnJvbSAnLi9VbmRvVG9hc3QnXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIHVzZXJOYW1lOiBzdHJpbmdcclxuICBwcm9maWxlUGhvdG86IHN0cmluZ1xyXG4gIGhpc3Rvcnk6IEhpc3RvcnlFbnRyeVtdXHJcbiAgYWN0aXZlSWQ6IG51bWJlclxyXG4gIHF1ZXJ5Pzogc3RyaW5nXHJcbiAgZmF2b3JpdGVPbmx5PzogYm9vbGVhblxyXG4gIGxvYWRpbmc/OiBib29sZWFuXHJcbiAgaGFzTW9yZT86IGJvb2xlYW5cclxuICBlcnJvcj86IHN0cmluZ1xyXG4gIHVuZG9FbnRyeT86IEhpc3RvcnlFbnRyeSB8IG51bGxcclxuICBjYXNjYWRlUHJvbXB0PzogeyBpdGVtPzogSGlzdG9yeUVudHJ5IH0gfCBudWxsXHJcbiAgb25OZXc6ICgpID0+IHZvaWRcclxuICBvbkhpc3Rvcnk6IChpZDogbnVtYmVyKSA9PiB2b2lkXHJcbiAgb25TZXR0aW5nczogKCkgPT4gdm9pZFxyXG4gIG9uTG9nb3V0OiAoKSA9PiB2b2lkXHJcbiAgb25TZWFyY2g/OiAocXVlcnk6IHN0cmluZywgZmF2b3JpdGVPbmx5OiBib29sZWFuKSA9PiB2b2lkXHJcbiAgb25Mb2FkTW9yZT86ICgpID0+IHZvaWRcclxuICBvblJldHJ5PzogKCkgPT4gdm9pZFxyXG4gIG9uUmVuYW1lPzogKGl0ZW06IEhpc3RvcnlFbnRyeSwgdGl0bGU6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxyXG4gIG9uVG9nZ2xlRmF2b3JpdGU/OiAoaXRlbTogSGlzdG9yeUVudHJ5KSA9PiBQcm9taXNlPHZvaWQ+XHJcbiAgb25SZW1vdmU/OiAoaXRlbTogSGlzdG9yeUVudHJ5KSA9PiBQcm9taXNlPHZvaWQ+XHJcbiAgb25VbmRvUmVtb3ZlPzogKCkgPT4gdm9pZFxyXG4gIG9uQ29uZmlybUNhc2NhZGU/OiAoKSA9PiB2b2lkXHJcbiAgb25DYW5jZWxDYXNjYWRlPzogKCkgPT4gdm9pZFxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2lkZWJhcih7XHJcbiAgdXNlck5hbWUsIHByb2ZpbGVQaG90bywgaGlzdG9yeSwgYWN0aXZlSWQsIHF1ZXJ5ID0gJycsIGZhdm9yaXRlT25seSA9IGZhbHNlLFxyXG4gIGxvYWRpbmcgPSBmYWxzZSwgaGFzTW9yZSA9IGZhbHNlLCBlcnJvciA9ICcnLCB1bmRvRW50cnkgPSBudWxsLFxyXG4gIGNhc2NhZGVQcm9tcHQgPSBudWxsLCBvbk5ldywgb25IaXN0b3J5LCBvblNldHRpbmdzLCBvbkxvZ291dCwgb25TZWFyY2gsXHJcbiAgb25Mb2FkTW9yZSwgb25SZXRyeSwgb25SZW5hbWUsIG9uVG9nZ2xlRmF2b3JpdGUsIG9uUmVtb3ZlLCBvblVuZG9SZW1vdmUsXHJcbiAgb25Db25maXJtQ2FzY2FkZSwgb25DYW5jZWxDYXNjYWRlLFxyXG59OiBQcm9wcykge1xyXG4gIGNvbnN0IFtoaXN0b3J5T3Blbiwgc2V0SGlzdG9yeU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSA9IHVzZVN0YXRlKHF1ZXJ5KVxyXG4gIGNvbnN0IFtmYXZvcml0ZXMsIHNldEZhdm9yaXRlc10gPSB1c2VTdGF0ZShmYXZvcml0ZU9ubHkpXHJcbiAgY29uc3QgW2VkaXRpbmdJZCwgc2V0RWRpdGluZ0lkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXHJcbiAgY29uc3Qgc2VhcmNoUmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiBzZXRTZWFyY2gocXVlcnkpLCBbcXVlcnldKVxyXG4gIHVzZUVmZmVjdCgoKSA9PiBzZXRGYXZvcml0ZXMoZmF2b3JpdGVPbmx5KSwgW2Zhdm9yaXRlT25seV0pXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb25TZWFyY2gpIHJldHVyblxyXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBvblNlYXJjaChzZWFyY2gsIGZhdm9yaXRlcyksIDMwMClcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKVxyXG4gIH0sIFtmYXZvcml0ZXMsIG9uU2VhcmNoLCBzZWFyY2hdKVxyXG5cclxuICBjb25zdCBncm91cHMgPSBncm91cEJ5RGF0ZShoaXN0b3J5KVxyXG4gIGNvbnN0IGdyb3VwVGl0bGVzID0gW1xyXG4gICAgWyd0b2RheScsICdBdWpvdXJk4oCZaHVpJ10sXHJcbiAgICBbJ3llc3RlcmRheScsICdIaWVyJ10sXHJcbiAgICBbJ3RoaXNXZWVrJywgJ0NldHRlIHNlbWFpbmUnXSxcclxuICAgIFsnb2xkZXInLCAnUGx1cyBhbmNpZW4nXSxcclxuICBdIGFzIGNvbnN0XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwic2lkZWJhclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItdG9wXCI+PGRpdiBjbGFzc05hbWU9XCJicmFuZC1tYXJrXCI+PEJhckNoYXJ0MyBzaXplPXsxOH0gLz48L2Rpdj48c3Bhbj5BSSBEYXRhIDxiPkFuYWx5c3Q8L2I+PC9zcGFuPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItdXNlci1jYXJkXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLXVzZXItYXZhdGFyXCI+e3Byb2ZpbGVQaG90byA/IDxpbWcgc3JjPXtwcm9maWxlUGhvdG99IGFsdD1cIlBob3RvIGRlIHByb2ZpbFwiIC8+IDogPFVzZXJSb3VuZCBzaXplPXsxNX0gLz59PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLXVzZXItbWV0YVwiPjxzdHJvbmc+e3VzZXJOYW1lfTwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJuZXctYW5hbHlzaXNcIiBvbkNsaWNrPXtvbk5ld30+PFBsdXMgc2l6ZT17MTd9IC8+IE5vdXZlbGxlIGFuYWx5c2U8L2J1dHRvbj5cclxuICAgICAge29uU2VhcmNoICYmIChcclxuICAgICAgICA8SGlzdG9yeVNlYXJjaFxyXG4gICAgICAgICAgdmFsdWU9e3NlYXJjaH1cclxuICAgICAgICAgIGZhdm9yaXRlT25seT17ZmF2b3JpdGVzfVxyXG4gICAgICAgICAgaW5wdXRSZWY9e3NlYXJjaFJlZn1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWFyY2h9XHJcbiAgICAgICAgICBvblRvZ2dsZUZhdm9yaXRlcz17KCkgPT4gc2V0RmF2b3JpdGVzKChjdXJyZW50KSA9PiAhY3VycmVudCl9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e2BoaXN0b3J5LWhlYWRpbmcgJHtoaXN0b3J5T3BlbiA/ICdoaXN0b3J5LWhlYWRpbmctb3BlbicgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRIaXN0b3J5T3Blbigob3BlbikgPT4gIW9wZW4pfSBhcmlhLWV4cGFuZGVkPXtoaXN0b3J5T3Blbn0+XHJcbiAgICAgICAgPHNwYW4+SGlzdG9yaXF1ZTwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaXN0b3J5LWhlYWRpbmctcmlnaHRcIj48c3BhbiBjbGFzc05hbWU9XCJoaXN0b3J5LWNvdW50XCI+e2hpc3RvcnkubGVuZ3RofTwvc3Bhbj48Q2hldnJvbkRvd24gc2l6ZT17MTR9IC8+PC9zcGFuPlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAge2hpc3RvcnlPcGVuICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktbGlzdFwiPlxyXG4gICAgICAgICAge2hpc3RvcnkubGVuZ3RoID8gZ3JvdXBUaXRsZXMubWFwKChba2V5LCB0aXRsZV0pID0+IChcclxuICAgICAgICAgICAgPEhpc3RvcnlHcm91cFxyXG4gICAgICAgICAgICAgIGtleT17a2V5fVxyXG4gICAgICAgICAgICAgIHRpdGxlPXt0aXRsZX1cclxuICAgICAgICAgICAgICBpdGVtcz17Z3JvdXBzW2tleV19XHJcbiAgICAgICAgICAgICAgYWN0aXZlSWQ9e2FjdGl2ZUlkfVxyXG4gICAgICAgICAgICAgIHF1ZXJ5PXtzZWFyY2h9XHJcbiAgICAgICAgICAgICAgZWRpdGluZ0lkPXtlZGl0aW5nSWR9XHJcbiAgICAgICAgICAgICAgb25IaXN0b3J5PXtvbkhpc3Rvcnl9XHJcbiAgICAgICAgICAgICAgb25TdGFydFJlbmFtZT17c2V0RWRpdGluZ0lkfVxyXG4gICAgICAgICAgICAgIG9uUmVuYW1lPXthc3luYyAoaXRlbSwgbmV4dFRpdGxlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBvblJlbmFtZT8uKGl0ZW0sIG5leHRUaXRsZSlcclxuICAgICAgICAgICAgICAgIHNldEVkaXRpbmdJZChudWxsKVxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgb25DYW5jZWxSZW5hbWU9eygpID0+IHNldEVkaXRpbmdJZChudWxsKX1cclxuICAgICAgICAgICAgICBvblRvZ2dsZUZhdm9yaXRlPXsoaXRlbSkgPT4gb25Ub2dnbGVGYXZvcml0ZT8uKGl0ZW0pID8/IFByb21pc2UucmVzb2x2ZSgpfVxyXG4gICAgICAgICAgICAgIG9uUmVtb3ZlPXsoaXRlbSkgPT4gb25SZW1vdmU/LihpdGVtKSA/PyBQcm9taXNlLnJlc29sdmUoKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkpIDogPHAgY2xhc3NOYW1lPVwiaGlzdG9yeS1lbXB0eVwiPntsb2FkaW5nID8gJ0NoYXJnZW1lbnQgZGUgbOKAmWhpc3RvcmlxdWXigKYnIDogJ0F1Y3VuZSBhbmFseXNlIGVucmVnaXN0csOpZS4nfTwvcD59XHJcbiAgICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiaGlzdG9yeS1lcnJvclwiIHJvbGU9XCJhbGVydFwiPntlcnJvcn08YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvblJldHJ5fT5Sw6llc3NheWVyPC9idXR0b24+PC9wPn1cclxuICAgICAgICAgIHtoYXNNb3JlICYmIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uTG9hZE1vcmV9IGRpc2FibGVkPXtsb2FkaW5nfT57bG9hZGluZyA/ICdDaGFyZ2VtZW504oCmJyA6ICdDaGFyZ2VyIHBsdXMnfTwvYnV0dG9uPn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAge2Nhc2NhZGVQcm9tcHQgJiYgKFxyXG4gICAgICAgIDxkaXYgcm9sZT1cImFsZXJ0ZGlhbG9nXCIgYXJpYS1sYWJlbD1cIlN1cHByaW1lciBsYSBjb252ZXJzYXRpb25cIj5cclxuICAgICAgICAgIDxwPkNldHRlIGFjdGlvbiBzdXBwcmltZXJhIHRvdXRlIGxhIGNvbnZlcnNhdGlvbi48L3A+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtvbkNvbmZpcm1DYXNjYWRlfT5TdXBwcmltZXI8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ2FuY2VsQ2FzY2FkZX0+QW5udWxlcjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICB7dW5kb0VudHJ5ICYmIDxVbmRvVG9hc3QgbWVzc2FnZT1cIkFuYWx5c2Ugc3VwcHJpbcOpZS5cIiBvblVuZG89eygpID0+IG9uVW5kb1JlbW92ZT8uKCl9IC8+fVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItYm90dG9tXCI+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJzaWRlYmFyLWFjdGlvblwiIG9uQ2xpY2s9e29uU2V0dGluZ3N9PjxTZXR0aW5ncyBzaXplPXsxN30gLz4gUGFyYW3DqHRyZXM8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNpZGViYXItYWN0aW9uIGxvZ291dFwiIG9uQ2xpY2s9e29uTG9nb3V0fT48TG9nT3V0IHNpemU9ezE3fSAvPiBEw6ljb25uZXhpb248L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2FzaWRlPlxyXG4gIClcclxufVxyXG4iXX0=