import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AnalysisPage.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { BarChart3, Database, FileText, Hash, MessageSquare } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import { ChatWindow } from "/src/components/ChatWindow.tsx";
import { DataPreviewTable } from "/src/components/DataPreviewTable.tsx";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisPage.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
const formatBytes = (size) => {
	if (size < 1024) return `${size} o`;
	if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} Ko`;
	return `${(size / (1024 * 1024)).toFixed(1)} Mo`;
};
const documentSuggestions = [
	{
		label: "Résumer le document",
		question: "Résume le contenu du document en français, en mettant en évidence son objectif et ses conclusions."
	},
	{
		label: "Extraire les points clés",
		question: "Extrais les points clés, arguments et conclusions des documents importés sous forme de liste."
	},
	{
		label: "Poser une question sur le contenu du document",
		question: "Formule une question importante sur le contenu des documents importés, puis réponds-y à partir du texte."
	},
	{
		label: "Extraire dates, montants et informations importantes",
		question: "Extrais les dates, montants, noms et autres informations importantes des documents. Présente-les de façon structurée."
	}
];
export function AnalysisPage({ datasets, firstQuestion, messages, isAnalyzing, chartConfig, onAsk, onAddFiles }) {
	const primary = datasets[0] ?? null;
	const tabularDatasets = datasets.filter((dataset) => /\.(csv|xlsx?)$/i.test(dataset.filename));
	let chart = null;
	try {
		chart = chartConfig ? JSON.parse(chartConfig) : null;
	} catch {
		chart = null;
	}
	if (!chart && tabularDatasets.length > 0) {
		const numericDataset = tabularDatasets.find((dataset) => dataset.column_names.some((column) => dataset.preview.some((row) => typeof row[column] === "number")));
		const numericColumn = numericDataset?.column_names.find((column) => numericDataset.preview.some((row) => typeof row[column] === "number"));
		if (numericDataset && numericColumn) {
			const values = numericDataset.preview.map((row) => Number(row[numericColumn])).filter((value) => Number.isFinite(value));
			chart = {
				title: numericColumn,
				labels: values.map((_, index) => String(index + 1)),
				values
			};
		}
	}
	const maxValue = chart ? Math.max(...chart.values, 1) : 1;
	const totalRows = tabularDatasets.reduce((sum, dataset) => sum + dataset.row_count, 0);
	const totalColumns = tabularDatasets.reduce((sum, dataset) => sum + dataset.column_count, 0);
	const title = datasets.length > 1 ? `Analyse de ${datasets.length} fichiers` : primary ? `Analyse de ${primary.filename}` : "Analyse";
	const documentDatasets = datasets.filter((dataset) => /\.(pdf|docx?)$/i.test(dataset.filename));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "analysis-page",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "analysis-page-title",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "workspace-kicker",
						children: "RÉSULTAT DE L’ANALYSE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this),
					datasets.length > 1 && /* @__PURE__ */ _jsxDEV("p", {
						className: "analysis-file-list",
						children: datasets.map((dataset) => dataset.filename).join(" · ")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: firstQuestion || "Posez une question pour commencer." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "success-badge",
					children: "● Dataset connecté"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			documentDatasets.length > 0 && /* @__PURE__ */ _jsxDEV("section", {
				className: "document-analysis-card",
				"aria-label": "Analyse des documents",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "document-analysis-heading",
						children: [/* @__PURE__ */ _jsxDEV(FileText, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "section-kicker",
							children: "DOCUMENT IMPORTÉ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h3", { children: documentDatasets.length === 1 ? "Que souhaitez-vous analyser ?" : `Analyser ${documentDatasets.length} documents` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "document-file-list",
						children: documentDatasets.map((dataset) => /* @__PURE__ */ _jsxDEV("div", {
							className: "document-file-info",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", {
									className: "document-file-name",
									title: dataset.filename,
									children: dataset.filename
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: dataset.page_count == null ? "Nombre de pages indisponible" : `${dataset.page_count} page${dataset.page_count > 1 ? "s" : ""}` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 17
								}, this),
								dataset.file_size_bytes != null && /* @__PURE__ */ _jsxDEV("span", { children: formatBytes(dataset.file_size_bytes) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 53
								}, this)
							]
						}, dataset.id, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "document-suggestions",
						children: documentSuggestions.map((suggestion) => /* @__PURE__ */ _jsxDEV("button", {
							className: "document-suggestion",
							type: "button",
							onClick: () => onAsk(suggestion.question, datasets.map((dataset) => dataset.dataset_id)),
							children: suggestion.label
						}, suggestion.label, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 9
			}, this),
			tabularDatasets.length > 0 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "metric-grid",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "metric-card",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Database, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: totalRows.toLocaleString("fr-FR") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: "Lignes analysées" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "metric-card",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Hash, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: totalColumns }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: "Colonnes détectées" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "metric-card",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(BarChart3, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: datasets.length }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: [
								"Fichier",
								datasets.length > 1 ? "s" : "",
								" analysé",
								datasets.length > 1 ? "s" : ""
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "metric-card",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(MessageSquare, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: messages.filter((message) => message.role === "user").length }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: "Questions posées" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-grid",
				children: [/* @__PURE__ */ _jsxDEV("section", {
					className: "dashboard-card chart-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "dashboard-card-head",
						children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "section-kicker",
							children: "VISUALISATION"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("h3", { children: chart ? `Evolution de ${chart.title}` : "Graphique en attente de l’analyse IA" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 15
					}, this), chart ? /* @__PURE__ */ _jsxDEV("div", {
						className: "saved-chart",
						"aria-label": `Graphique de ${chart.title}`,
						children: chart.values.map((value, index) => /* @__PURE__ */ _jsxDEV("div", {
							className: "saved-chart-bar",
							children: [/* @__PURE__ */ _jsxDEV("span", { style: { height: `${Math.max(value / maxValue * 100, 4)}%` } }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 23
							}, this), /* @__PURE__ */ _jsxDEV("small", { children: chart?.labels[index] }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 23
							}, this)]
						}, `${chart?.labels[index] ?? index}-${value}`, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 21
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "empty-dashboard",
						children: [/* @__PURE__ */ _jsxDEV(BarChart3, { size: 28 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Le graphique sera disponible après la première question." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("section", {
					className: "dashboard-card insight-card",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "section-kicker",
							children: "INSIGHT IA"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", { children: "Résultat enregistré" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: [...messages].reverse().find((message) => message.role === "assistant")?.content ?? "Aucun résultat enregistré." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 9
			}, this),
			tabularDatasets.length > 0 && /* @__PURE__ */ _jsxDEV(DataPreviewTable, { datasets: tabularDatasets }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 181,
				columnNumber: 38
			}, this),
			/* @__PURE__ */ _jsxDEV(ChatWindow, {
				messages,
				isAnalyzing,
				onAsk: (question) => onAsk(question, datasets.map((dataset) => dataset.dataset_id)),
				onAddFiles
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 182,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 82,
		columnNumber: 5
	}, this);
}
_c = AnalysisPage;
var _c;
$RefreshReg$(_c, "AnalysisPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AnalysisPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFVBQVUsVUFBVSxNQUFNLHFCQUFxQjtBQUNuRSxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLHdCQUF3Qjs7O0FBY2pDLE1BQU0sZUFBZSxTQUFpQjtDQUNwQyxJQUFJLE9BQU8sTUFBTSxPQUFPLEdBQUcsS0FBSztDQUNoQyxJQUFJLE9BQU8sT0FBTyxNQUFNLE9BQU8sSUFBSSxPQUFPLEtBQUksQ0FBRSxRQUFRLENBQUMsRUFBRTtDQUMzRCxPQUFPLElBQUksUUFBUSxPQUFPLE1BQUssQ0FBRSxRQUFRLENBQUMsRUFBRTtBQUM5QztBQUVBLE1BQU0sc0JBQXNCO0NBQzFCO0VBQ0UsT0FBTztFQUNQLFVBQVU7Q0FDWjtDQUNBO0VBQ0UsT0FBTztFQUNQLFVBQVU7Q0FDWjtDQUNBO0VBQ0UsT0FBTztFQUNQLFVBQVU7Q0FDWjtDQUNBO0VBQ0UsT0FBTztFQUNQLFVBQVU7Q0FDWjtBQUNGO0FBRUEsT0FBTyxTQUFTLGFBQWEsRUFBRSxVQUFVLGVBQWUsVUFBVSxhQUFhLGFBQWEsT0FBTyxjQUFxQjtDQUN0SCxNQUFNLFVBQVUsU0FBUyxNQUFNO0NBQy9CLE1BQU0sa0JBQWtCLFNBQVMsUUFBUSxZQUFZLGtCQUFrQixLQUFLLFFBQVEsUUFBUSxDQUFDO0NBQzdGLElBQUksUUFBNEI7Q0FFaEMsSUFBSTtFQUNGLFFBQVEsY0FBYyxLQUFLLE1BQU0sV0FBVyxJQUFtQjtDQUNqRSxRQUFRO0VBQ04sUUFBUTtDQUNWO0NBRUEsSUFBSSxDQUFDLFNBQVMsZ0JBQWdCLFNBQVMsR0FBRztFQUN4QyxNQUFNLGlCQUFpQixnQkFBZ0IsTUFBTSxZQUMzQyxRQUFRLGFBQWEsTUFBTSxXQUN6QixRQUFRLFFBQVEsTUFBTSxRQUFRLE9BQU8sSUFBSSxZQUFZLFFBQVEsQ0FDL0QsQ0FDRjtFQUNBLE1BQU0sZ0JBQWdCLGdCQUFnQixhQUFhLE1BQU0sV0FDdkQsZUFBZSxRQUFRLE1BQU0sUUFBUSxPQUFPLElBQUksWUFBWSxRQUFRLENBQ3RFO0VBRUEsSUFBSSxrQkFBa0IsZUFBZTtHQUNuQyxNQUFNLFNBQVMsZUFBZSxRQUMzQixLQUFLLFFBQVEsT0FBTyxJQUFJLGNBQWMsQ0FBQyxDQUFDLENBQ3hDLFFBQVEsVUFBVSxPQUFPLFNBQVMsS0FBSyxDQUFDO0dBQzNDLFFBQVE7SUFBRSxPQUFPO0lBQWUsUUFBUSxPQUFPLEtBQUssR0FBRyxVQUFVLE9BQU8sUUFBUSxDQUFDLENBQUM7SUFBRztHQUFPO0VBQzlGO0NBQ0Y7Q0FFQSxNQUFNLFdBQVcsUUFBUSxLQUFLLElBQUksR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJO0NBQ3hELE1BQU0sWUFBWSxnQkFBZ0IsUUFBUSxLQUFLLFlBQVksTUFBTSxRQUFRLFdBQVcsQ0FBQztDQUNyRixNQUFNLGVBQWUsZ0JBQWdCLFFBQVEsS0FBSyxZQUFZLE1BQU0sUUFBUSxjQUFjLENBQUM7Q0FDM0YsTUFBTSxRQUFRLFNBQVMsU0FBUyxJQUM1QixjQUFjLFNBQVMsT0FBTyxhQUM5QixVQUNFLGNBQWMsUUFBUSxhQUN0QjtDQUNOLE1BQU0sbUJBQW1CLFNBQVMsUUFBUSxZQUFZLGtCQUFrQixLQUFLLFFBQVEsUUFBUSxDQUFDO0NBRTlGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1CO0tBQTJCOzs7OztLQUM5RCx3QkFBQyxNQUFELFlBQUssTUFBVTs7Ozs7S0FDZCxTQUFTLFNBQVMsS0FDakIsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQXNCLFNBQVMsS0FBSyxZQUFZLFFBQVEsUUFBUSxDQUFDLENBQUMsS0FBSyxLQUFLO0tBQUs7Ozs7O0tBRWhHLHdCQUFDLEtBQUQsWUFBSSxpQkFBaUIscUNBQXdDOzs7OztJQUMxRDs7OztjQUNMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWdCO0lBQXdCOzs7O1lBQ3JEOzs7Ozs7R0FFSixpQkFBaUIsU0FBUyxLQUN6Qix3QkFBQyxXQUFEO0lBQVMsV0FBVTtJQUF5QixjQUFXO2NBQXZEO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O2dCQUNyQix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlCO01BQXNCOzs7O2dCQUN2RCx3QkFBQyxNQUFELFlBQUssaUJBQWlCLFdBQVcsSUFBSSxrQ0FBa0MsWUFBWSxpQkFBaUIsT0FBTyxZQUFnQjs7OztjQUN4SDs7OztjQUNGOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixpQkFBaUIsS0FBSyxZQUNyQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO1NBQXFCLE9BQU8sUUFBUTttQkFBVyxRQUFRO1FBQWlCOzs7OztRQUMxRix3QkFBQyxRQUFELFlBQU8sUUFBUSxjQUFjLE9BQU8saUNBQWlDLEdBQUcsUUFBUSxXQUFXLE9BQU8sUUFBUSxhQUFhLElBQUksTUFBTSxLQUFXOzs7OztRQUMzSSxRQUFRLG1CQUFtQixRQUFRLHdCQUFDLFFBQUQsWUFBTyxZQUFZLFFBQVEsZUFBZSxFQUFROzs7OztPQUNuRjtTQUpvQyxRQUFROzs7O2FBSTVDLENBQ047S0FDRTs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixvQkFBb0IsS0FBSyxlQUN4Qix3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFzQixNQUFLO09BQWdDLGVBQWUsTUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLFlBQVksUUFBUSxVQUFVLENBQUM7aUJBQ2pLLFdBQVc7TUFDTixHQUZtRCxXQUFXOzs7O2FBRTlELENBQ1Q7S0FDRTs7Ozs7SUFDRTs7Ozs7O0dBR1YsZ0JBQWdCLFNBQVMsS0FDeEIsZ0RBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRCxZQUFNLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7Z0JBQU87Ozs7O09BQ2xDLHdCQUFDLFVBQUQsWUFBUyxVQUFVLGVBQWUsT0FBTyxFQUFVOzs7OztPQUNuRCx3QkFBQyxTQUFELFlBQU8sbUJBQXVCOzs7OztNQUMzQjs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELFlBQU0sd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztnQkFBTzs7Ozs7T0FDOUIsd0JBQUMsVUFBRCxZQUFTLGFBQXFCOzs7OztPQUM5Qix3QkFBQyxTQUFELFlBQU8scUJBQXlCOzs7OztNQUM3Qjs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELFlBQU0sd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztnQkFBTzs7Ozs7T0FDbkMsd0JBQUMsVUFBRCxZQUFTLFNBQVMsT0FBZTs7Ozs7T0FDakMsd0JBQUMsU0FBRDtRQUFPO1FBQVEsU0FBUyxTQUFTLElBQUksTUFBTTtRQUFHO1FBQVMsU0FBUyxTQUFTLElBQUksTUFBTTtPQUFVOzs7OztNQUMxRjs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELFlBQU0sd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7OztnQkFBTzs7Ozs7T0FDdkMsd0JBQUMsVUFBRCxZQUFTLFNBQVMsUUFBUSxZQUFZLFFBQVEsU0FBUyxNQUFNLENBQUMsQ0FBQyxPQUFlOzs7OztPQUM5RSx3QkFBQyxTQUFELFlBQU8sbUJBQXVCOzs7OztNQUMzQjs7Ozs7O0lBQ0Y7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFpQjtNQUFtQjs7OztnQkFDcEQsd0JBQUMsTUFBRCxZQUFLLFFBQVEsZ0JBQWdCLE1BQU0sVUFBVSx1Q0FBMkM7Ozs7Y0FDckY7Ozs7O0tBQ0Y7Ozs7ZUFDSixRQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQWMsY0FBWSxnQkFBZ0IsTUFBTTtnQkFDNUQsTUFBTSxPQUFPLEtBQUssT0FBTyxVQUN4Qix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxPQUFPLEVBQUUsUUFBUSxHQUFHLEtBQUssSUFBSyxRQUFRLFdBQVksS0FBSyxDQUFDLEVBQUUsR0FBRyxFQUFJOzs7O2lCQUN2RSx3QkFBQyxTQUFELFlBQVEsT0FBTyxPQUFPLE9BQWM7Ozs7ZUFDakM7U0FIaUMsR0FBRyxPQUFPLE9BQU8sVUFBVSxNQUFNLEdBQUc7Ozs7YUFHckUsQ0FDTjtLQUNFOzs7O2dCQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztnQkFDdEIsd0JBQUMsS0FBRCxZQUFHLDJEQUEyRDs7OztjQUMzRDs7Ozs7YUFFQTs7Ozs7Y0FDVCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQjtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFpQjtNQUFnQjs7Ozs7TUFDakQsd0JBQUMsTUFBRCxZQUFJLHNCQUF1Qjs7Ozs7TUFDM0Isd0JBQUMsS0FBRCxZQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLFlBQVksUUFBUSxTQUFTLFdBQVcsQ0FBQyxFQUFFLFdBQVcsNkJBQWdDOzs7OztLQUNqSDs7Ozs7WUFDTjs7Ozs7V0FDTDs7Ozs7R0FHSCxnQkFBZ0IsU0FBUyxLQUFLLHdCQUFDLGtCQUFELEVBQWtCLFVBQVUsZ0JBQWtCOzs7OztHQUM3RSx3QkFBQyxZQUFEO0lBQXNCO0lBQXVCO0lBQWEsUUFBUSxhQUFhLE1BQU0sVUFBVSxTQUFTLEtBQUssWUFBWSxRQUFRLFVBQVUsQ0FBQztJQUFlO0dBQWE7Ozs7O0VBQ3JLOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBbmFseXNpc1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJhckNoYXJ0MywgRGF0YWJhc2UsIEZpbGVUZXh0LCBIYXNoLCBNZXNzYWdlU3F1YXJlIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBDaGF0V2luZG93IH0gZnJvbSAnLi9DaGF0V2luZG93J1xyXG5pbXBvcnQgeyBEYXRhUHJldmlld1RhYmxlIH0gZnJvbSAnLi9EYXRhUHJldmlld1RhYmxlJ1xyXG5pbXBvcnQgdHlwZSB7IENoYXJ0Q29uZmlnLCBNZXNzYWdlIH0gZnJvbSAnLi4vdHlwZXMnXHJcbmltcG9ydCB0eXBlIHsgRGF0YXNldFByZXZpZXcgfSBmcm9tICcuLi9zZXJ2aWNlcy9maWxlU2VydmljZSdcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgZGF0YXNldHM6IERhdGFzZXRQcmV2aWV3W11cclxuICBmaXJzdFF1ZXN0aW9uOiBzdHJpbmdcclxuICBtZXNzYWdlczogTWVzc2FnZVtdXHJcbiAgaXNBbmFseXppbmc6IGJvb2xlYW5cclxuICBjaGFydENvbmZpZzogc3RyaW5nIHwgbnVsbFxyXG4gIG9uQXNrOiAocXVlc3Rpb246IHN0cmluZywgZGF0YXNldElkcz86IG51bWJlcltdKSA9PiB2b2lkXHJcbiAgb25BZGRGaWxlczogKGZpbGVzOiBGaWxlW10pID0+IFByb21pc2U8dm9pZD5cclxufVxyXG5cclxuY29uc3QgZm9ybWF0Qnl0ZXMgPSAoc2l6ZTogbnVtYmVyKSA9PiB7XHJcbiAgaWYgKHNpemUgPCAxMDI0KSByZXR1cm4gYCR7c2l6ZX0gb2BcclxuICBpZiAoc2l6ZSA8IDEwMjQgKiAxMDI0KSByZXR1cm4gYCR7KHNpemUgLyAxMDI0KS50b0ZpeGVkKDEpfSBLb2BcclxuICByZXR1cm4gYCR7KHNpemUgLyAoMTAyNCAqIDEwMjQpKS50b0ZpeGVkKDEpfSBNb2BcclxufVxyXG5cclxuY29uc3QgZG9jdW1lbnRTdWdnZXN0aW9ucyA9IFtcclxuICB7XHJcbiAgICBsYWJlbDogJ1LDqXN1bWVyIGxlIGRvY3VtZW50JyxcclxuICAgIHF1ZXN0aW9uOiAnUsOpc3VtZSBsZSBjb250ZW51IGR1IGRvY3VtZW50IGVuIGZyYW7Dp2FpcywgZW4gbWV0dGFudCBlbiDDqXZpZGVuY2Ugc29uIG9iamVjdGlmIGV0IHNlcyBjb25jbHVzaW9ucy4nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbGFiZWw6ICdFeHRyYWlyZSBsZXMgcG9pbnRzIGNsw6lzJyxcclxuICAgIHF1ZXN0aW9uOiAnRXh0cmFpcyBsZXMgcG9pbnRzIGNsw6lzLCBhcmd1bWVudHMgZXQgY29uY2x1c2lvbnMgZGVzIGRvY3VtZW50cyBpbXBvcnTDqXMgc291cyBmb3JtZSBkZSBsaXN0ZS4nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbGFiZWw6ICdQb3NlciB1bmUgcXVlc3Rpb24gc3VyIGxlIGNvbnRlbnUgZHUgZG9jdW1lbnQnLFxyXG4gICAgcXVlc3Rpb246ICdGb3JtdWxlIHVuZSBxdWVzdGlvbiBpbXBvcnRhbnRlIHN1ciBsZSBjb250ZW51IGRlcyBkb2N1bWVudHMgaW1wb3J0w6lzLCBwdWlzIHLDqXBvbmRzLXkgw6AgcGFydGlyIGR1IHRleHRlLicsXHJcbiAgfSxcclxuICB7XHJcbiAgICBsYWJlbDogJ0V4dHJhaXJlIGRhdGVzLCBtb250YW50cyBldCBpbmZvcm1hdGlvbnMgaW1wb3J0YW50ZXMnLFxyXG4gICAgcXVlc3Rpb246ICdFeHRyYWlzIGxlcyBkYXRlcywgbW9udGFudHMsIG5vbXMgZXQgYXV0cmVzIGluZm9ybWF0aW9ucyBpbXBvcnRhbnRlcyBkZXMgZG9jdW1lbnRzLiBQcsOpc2VudGUtbGVzIGRlIGZhw6dvbiBzdHJ1Y3R1csOpZS4nLFxyXG4gIH0sXHJcbl1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBbmFseXNpc1BhZ2UoeyBkYXRhc2V0cywgZmlyc3RRdWVzdGlvbiwgbWVzc2FnZXMsIGlzQW5hbHl6aW5nLCBjaGFydENvbmZpZywgb25Bc2ssIG9uQWRkRmlsZXMgfTogUHJvcHMpIHtcclxuICBjb25zdCBwcmltYXJ5ID0gZGF0YXNldHNbMF0gPz8gbnVsbFxyXG4gIGNvbnN0IHRhYnVsYXJEYXRhc2V0cyA9IGRhdGFzZXRzLmZpbHRlcigoZGF0YXNldCkgPT4gL1xcLihjc3Z8eGxzeD8pJC9pLnRlc3QoZGF0YXNldC5maWxlbmFtZSkpXHJcbiAgbGV0IGNoYXJ0OiBDaGFydENvbmZpZyB8IG51bGwgPSBudWxsXHJcblxyXG4gIHRyeSB7XHJcbiAgICBjaGFydCA9IGNoYXJ0Q29uZmlnID8gSlNPTi5wYXJzZShjaGFydENvbmZpZykgYXMgQ2hhcnRDb25maWcgOiBudWxsXHJcbiAgfSBjYXRjaCB7XHJcbiAgICBjaGFydCA9IG51bGxcclxuICB9XHJcblxyXG4gIGlmICghY2hhcnQgJiYgdGFidWxhckRhdGFzZXRzLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IG51bWVyaWNEYXRhc2V0ID0gdGFidWxhckRhdGFzZXRzLmZpbmQoKGRhdGFzZXQpID0+XHJcbiAgICAgIGRhdGFzZXQuY29sdW1uX25hbWVzLnNvbWUoKGNvbHVtbikgPT5cclxuICAgICAgICBkYXRhc2V0LnByZXZpZXcuc29tZSgocm93KSA9PiB0eXBlb2Ygcm93W2NvbHVtbl0gPT09ICdudW1iZXInKVxyXG4gICAgICApXHJcbiAgICApXHJcbiAgICBjb25zdCBudW1lcmljQ29sdW1uID0gbnVtZXJpY0RhdGFzZXQ/LmNvbHVtbl9uYW1lcy5maW5kKChjb2x1bW4pID0+XHJcbiAgICAgIG51bWVyaWNEYXRhc2V0LnByZXZpZXcuc29tZSgocm93KSA9PiB0eXBlb2Ygcm93W2NvbHVtbl0gPT09ICdudW1iZXInKVxyXG4gICAgKVxyXG5cclxuICAgIGlmIChudW1lcmljRGF0YXNldCAmJiBudW1lcmljQ29sdW1uKSB7XHJcbiAgICAgIGNvbnN0IHZhbHVlcyA9IG51bWVyaWNEYXRhc2V0LnByZXZpZXdcclxuICAgICAgICAubWFwKChyb3cpID0+IE51bWJlcihyb3dbbnVtZXJpY0NvbHVtbl0pKVxyXG4gICAgICAgIC5maWx0ZXIoKHZhbHVlKSA9PiBOdW1iZXIuaXNGaW5pdGUodmFsdWUpKVxyXG4gICAgICBjaGFydCA9IHsgdGl0bGU6IG51bWVyaWNDb2x1bW4sIGxhYmVsczogdmFsdWVzLm1hcCgoXywgaW5kZXgpID0+IFN0cmluZyhpbmRleCArIDEpKSwgdmFsdWVzIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IG1heFZhbHVlID0gY2hhcnQgPyBNYXRoLm1heCguLi5jaGFydC52YWx1ZXMsIDEpIDogMVxyXG4gIGNvbnN0IHRvdGFsUm93cyA9IHRhYnVsYXJEYXRhc2V0cy5yZWR1Y2UoKHN1bSwgZGF0YXNldCkgPT4gc3VtICsgZGF0YXNldC5yb3dfY291bnQsIDApXHJcbiAgY29uc3QgdG90YWxDb2x1bW5zID0gdGFidWxhckRhdGFzZXRzLnJlZHVjZSgoc3VtLCBkYXRhc2V0KSA9PiBzdW0gKyBkYXRhc2V0LmNvbHVtbl9jb3VudCwgMClcclxuICBjb25zdCB0aXRsZSA9IGRhdGFzZXRzLmxlbmd0aCA+IDFcclxuICAgID8gYEFuYWx5c2UgZGUgJHtkYXRhc2V0cy5sZW5ndGh9IGZpY2hpZXJzYFxyXG4gICAgOiBwcmltYXJ5XHJcbiAgICAgID8gYEFuYWx5c2UgZGUgJHtwcmltYXJ5LmZpbGVuYW1lfWBcclxuICAgICAgOiAnQW5hbHlzZSdcclxuICBjb25zdCBkb2N1bWVudERhdGFzZXRzID0gZGF0YXNldHMuZmlsdGVyKChkYXRhc2V0KSA9PiAvXFwuKHBkZnxkb2N4PykkL2kudGVzdChkYXRhc2V0LmZpbGVuYW1lKSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5hbHlzaXMtcGFnZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuYWx5c2lzLXBhZ2UtdGl0bGVcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid29ya3NwYWNlLWtpY2tlclwiPlLDiVNVTFRBVCBERSBM4oCZQU5BTFlTRTwvc3Bhbj5cclxuICAgICAgICAgIDxoMj57dGl0bGV9PC9oMj5cclxuICAgICAgICAgIHtkYXRhc2V0cy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYW5hbHlzaXMtZmlsZS1saXN0XCI+e2RhdGFzZXRzLm1hcCgoZGF0YXNldCkgPT4gZGF0YXNldC5maWxlbmFtZSkuam9pbignIMK3ICcpfTwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8cD57Zmlyc3RRdWVzdGlvbiB8fCAnUG9zZXogdW5lIHF1ZXN0aW9uIHBvdXIgY29tbWVuY2VyLid9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN1Y2Nlc3MtYmFkZ2VcIj7il48gRGF0YXNldCBjb25uZWN0w6k8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2RvY3VtZW50RGF0YXNldHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZG9jdW1lbnQtYW5hbHlzaXMtY2FyZFwiIGFyaWEtbGFiZWw9XCJBbmFseXNlIGRlcyBkb2N1bWVudHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZG9jdW1lbnQtYW5hbHlzaXMtaGVhZGluZ1wiPlxyXG4gICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi1raWNrZXJcIj5ET0NVTUVOVCBJTVBPUlTDiTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8aDM+e2RvY3VtZW50RGF0YXNldHMubGVuZ3RoID09PSAxID8gJ1F1ZSBzb3VoYWl0ZXotdm91cyBhbmFseXNlciA/JyA6IGBBbmFseXNlciAke2RvY3VtZW50RGF0YXNldHMubGVuZ3RofSBkb2N1bWVudHNgfTwvaDM+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRvY3VtZW50LWZpbGUtbGlzdFwiPlxyXG4gICAgICAgICAgICB7ZG9jdW1lbnREYXRhc2V0cy5tYXAoKGRhdGFzZXQpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRvY3VtZW50LWZpbGUtaW5mb1wiIGtleT17ZGF0YXNldC5pZH0+XHJcbiAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cImRvY3VtZW50LWZpbGUtbmFtZVwiIHRpdGxlPXtkYXRhc2V0LmZpbGVuYW1lfT57ZGF0YXNldC5maWxlbmFtZX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPntkYXRhc2V0LnBhZ2VfY291bnQgPT0gbnVsbCA/ICdOb21icmUgZGUgcGFnZXMgaW5kaXNwb25pYmxlJyA6IGAke2RhdGFzZXQucGFnZV9jb3VudH0gcGFnZSR7ZGF0YXNldC5wYWdlX2NvdW50ID4gMSA/ICdzJyA6ICcnfWB9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge2RhdGFzZXQuZmlsZV9zaXplX2J5dGVzICE9IG51bGwgJiYgPHNwYW4+e2Zvcm1hdEJ5dGVzKGRhdGFzZXQuZmlsZV9zaXplX2J5dGVzKX08L3NwYW4+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkb2N1bWVudC1zdWdnZXN0aW9uc1wiPlxyXG4gICAgICAgICAgICB7ZG9jdW1lbnRTdWdnZXN0aW9ucy5tYXAoKHN1Z2dlc3Rpb24pID0+IChcclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRvY3VtZW50LXN1Z2dlc3Rpb25cIiB0eXBlPVwiYnV0dG9uXCIga2V5PXtzdWdnZXN0aW9uLmxhYmVsfSBvbkNsaWNrPXsoKSA9PiBvbkFzayhzdWdnZXN0aW9uLnF1ZXN0aW9uLCBkYXRhc2V0cy5tYXAoKGRhdGFzZXQpID0+IGRhdGFzZXQuZGF0YXNldF9pZCkpfT5cclxuICAgICAgICAgICAgICAgIHtzdWdnZXN0aW9uLmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHt0YWJ1bGFyRGF0YXNldHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWV0cmljLWdyaWRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXRyaWMtY2FyZFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPjxEYXRhYmFzZSBzaXplPXsxNn0gLz48L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHN0cm9uZz57dG90YWxSb3dzLnRvTG9jYWxlU3RyaW5nKCdmci1GUicpfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgIDxzbWFsbD5MaWduZXMgYW5hbHlzw6llczwvc21hbGw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1ldHJpYy1jYXJkXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+PEhhc2ggc2l6ZT17MTZ9IC8+PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+e3RvdGFsQ29sdW1uc308L3N0cm9uZz5cclxuICAgICAgICAgICAgICA8c21hbGw+Q29sb25uZXMgZMOpdGVjdMOpZXM8L3NtYWxsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXRyaWMtY2FyZFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPjxCYXJDaGFydDMgc2l6ZT17MTZ9IC8+PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+e2RhdGFzZXRzLmxlbmd0aH08L3N0cm9uZz5cclxuICAgICAgICAgICAgICA8c21hbGw+RmljaGllcntkYXRhc2V0cy5sZW5ndGggPiAxID8gJ3MnIDogJyd9IGFuYWx5c8Ope2RhdGFzZXRzLmxlbmd0aCA+IDEgPyAncycgOiAnJ308L3NtYWxsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXRyaWMtY2FyZFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPjxNZXNzYWdlU3F1YXJlIHNpemU9ezE2fSAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPnttZXNzYWdlcy5maWx0ZXIoKG1lc3NhZ2UpID0+IG1lc3NhZ2Uucm9sZSA9PT0gJ3VzZXInKS5sZW5ndGh9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgPHNtYWxsPlF1ZXN0aW9ucyBwb3PDqWVzPC9zbWFsbD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1ncmlkXCI+XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImRhc2hib2FyZC1jYXJkIGNoYXJ0LWNhcmRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1jYXJkLWhlYWRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlY3Rpb24ta2lja2VyXCI+VklTVUFMSVNBVElPTjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGgzPntjaGFydCA/IGBFdm9sdXRpb24gZGUgJHtjaGFydC50aXRsZX1gIDogJ0dyYXBoaXF1ZSBlbiBhdHRlbnRlIGRlIGzigJlhbmFseXNlIElBJ308L2gzPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2NoYXJ0ID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1jaGFydFwiIGFyaWEtbGFiZWw9e2BHcmFwaGlxdWUgZGUgJHtjaGFydC50aXRsZX1gfT5cclxuICAgICAgICAgICAgICAgICAge2NoYXJ0LnZhbHVlcy5tYXAoKHZhbHVlLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2F2ZWQtY2hhcnQtYmFyXCIga2V5PXtgJHtjaGFydD8ubGFiZWxzW2luZGV4XSA/PyBpbmRleH0tJHt2YWx1ZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGhlaWdodDogYCR7TWF0aC5tYXgoKHZhbHVlIC8gbWF4VmFsdWUpICogMTAwLCA0KX0lYCB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNtYWxsPntjaGFydD8ubGFiZWxzW2luZGV4XX08L3NtYWxsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LWRhc2hib2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQzIHNpemU9ezI4fSAvPlxyXG4gICAgICAgICAgICAgICAgICA8cD5MZSBncmFwaGlxdWUgc2VyYSBkaXNwb25pYmxlIGFwcsOocyBsYSBwcmVtacOocmUgcXVlc3Rpb24uPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtY2FyZCBpbnNpZ2h0LWNhcmRcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWtpY2tlclwiPklOU0lHSFQgSUE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGgzPlLDqXN1bHRhdCBlbnJlZ2lzdHLDqTwvaDM+XHJcbiAgICAgICAgICAgICAgPHA+e1suLi5tZXNzYWdlc10ucmV2ZXJzZSgpLmZpbmQoKG1lc3NhZ2UpID0+IG1lc3NhZ2Uucm9sZSA9PT0gJ2Fzc2lzdGFudCcpPy5jb250ZW50ID8/ICdBdWN1biByw6lzdWx0YXQgZW5yZWdpc3Ryw6kuJ308L3A+XHJcbiAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3RhYnVsYXJEYXRhc2V0cy5sZW5ndGggPiAwICYmIDxEYXRhUHJldmlld1RhYmxlIGRhdGFzZXRzPXt0YWJ1bGFyRGF0YXNldHN9IC8+fVxyXG4gICAgICA8Q2hhdFdpbmRvdyBtZXNzYWdlcz17bWVzc2FnZXN9IGlzQW5hbHl6aW5nPXtpc0FuYWx5emluZ30gb25Bc2s9eyhxdWVzdGlvbikgPT4gb25Bc2socXVlc3Rpb24sIGRhdGFzZXRzLm1hcCgoZGF0YXNldCkgPT4gZGF0YXNldC5kYXRhc2V0X2lkKSl9IG9uQWRkRmlsZXM9e29uQWRkRmlsZXN9IC8+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn0iXX0=