import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AuthPage.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { ArrowLeft, ArrowRight, BarChart3, Check, Eye, EyeOff, LockKeyhole } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AuthPage.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const TRIVIAL_PASSWORDS = new Set([
	"password123",
	"password1234",
	"qwerty12345",
	"azerty12345",
	"1234567890",
	"iloveyou123"
]);
function passwordStrength(password) {
	const score = [
		password.length >= 10,
		/\p{L}/u.test(password),
		/\d/.test(password),
		/[^A-Za-z0-9]/.test(password)
	].filter(Boolean).length;
	return {
		score,
		label: score < 2 ? "Faible" : score < 4 ? "Moyen" : "Fort"
	};
}
function passwordDeliveryNotice(response) {
	if (response?.delivery_mode === "console") {
		return "L’envoi par email a échoué. En mode développement, le code est affiché dans le terminal du backend. Vérifiez la configuration SMTP et consultez les courriers indésirables.";
	}
	if (response?.delivery_mode === "unavailable") {
		return "Le service email n’est pas configuré. Demandez à l’administrateur de configurer le serveur SMTP.";
	}
	if (response?.delivery_mode === "email") {
		return "Si cette adresse est associée à un compte, un email contenant un code a été envoyé. Vérifiez aussi vos courriers indésirables.";
	}
	return "Si cette adresse est associée à un compte, un email contenant un code sera envoyé.";
}
function PasswordField({ label, value, onChange, placeholder, autoComplete }) {
	_s();
	const [visible, setVisible] = useState(false);
	const ToggleIcon = visible ? EyeOff : Eye;
	return /* @__PURE__ */ _jsxDEV("label", {
		className: "auth-password-field",
		children: [label, /* @__PURE__ */ _jsxDEV("span", {
			className: "auth-password-input-wrap",
			children: [/* @__PURE__ */ _jsxDEV("input", {
				type: visible ? "text" : "password",
				value,
				onChange: (event) => onChange(event.target.value),
				placeholder,
				autoComplete
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "password-visibility-toggle",
				"aria-label": visible ? "Masquer le mot de passe" : "Afficher le mot de passe",
				"aria-pressed": visible,
				onClick: () => setVisible((current) => !current),
				children: /* @__PURE__ */ _jsxDEV(ToggleIcon, {
					size: 16,
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 5
	}, this);
}
_s(PasswordField, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = PasswordField;
export function AuthPage({ type, onBack, onSubmit, onVerifyEmail, onResendCode, onForgotPassword, onResetPassword, onSwitch }) {
	_s2();
	const isSignup = type === "signup";
	const [step, setStep] = useState("credentials");
	const [name, setName] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [passwordConfirmation, setPasswordConfirmation] = useState("");
	const [otp, setOtp] = useState([
		"",
		"",
		"",
		"",
		"",
		""
	]);
	const [error, setError] = useState("");
	const [notice, setNotice] = useState("");
	const [loading, setLoading] = useState(false);
	const [resendSeconds, setResendSeconds] = useState(0);
	const otpRefs = useRef([]);
	const strength = passwordStrength(password);
	useEffect(() => {
		if (!resendSeconds) return;
		const timer = window.setTimeout(() => setResendSeconds((seconds) => seconds - 1), 1e3);
		return () => window.clearTimeout(timer);
	}, [resendSeconds]);
	const startVerification = async (resend, response) => {
		setStep("verify-email");
		setOtp([
			"",
			"",
			"",
			"",
			"",
			""
		]);
		setResendSeconds(60);
		setError("");
		setNotice(resend ? "" : passwordDeliveryNotice(response));
		if (resend) {
			try {
				const result = await onResendCode(email.trim());
				setNotice(passwordDeliveryNotice(result));
			} catch (sendError) {
				setError(sendError instanceof Error ? sendError.message : "Impossible de renvoyer le code.");
			}
		}
	};
	const submitCredentials = async (event) => {
		event.preventDefault();
		setError("");
		setNotice("");
		if (!email.trim()) {
			setError("Saisissez votre adresse email.");
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
			setError("Saisissez une adresse email valide.");
			return;
		}
		if (!password) {
			setError("Saisissez votre mot de passe.");
			return;
		}
		if (isSignup) {
			if (!name.trim()) {
				setError("Le nom complet est obligatoire.");
				return;
			}
			if (password.length < 10 || !/\p{L}/u.test(password) || !/\d/.test(password)) {
				setError("Le mot de passe doit contenir au moins 10 caractères, une lettre et un chiffre.");
				return;
			}
			if (new TextEncoder().encode(password).length > 72) {
				setError("Le mot de passe ne doit pas dépasser 72 octets.");
				return;
			}
			if (TRIVIAL_PASSWORDS.has(password.toLowerCase())) {
				setError("Ce mot de passe est trop facile à deviner.");
				return;
			}
			if (!passwordConfirmation) {
				setError("Confirmez votre mot de passe.");
				return;
			}
			if (password !== passwordConfirmation) {
				setError("Les mots de passe ne correspondent pas.");
				return;
			}
		}
		setLoading(true);
		try {
			const result = await onSubmit(name.trim(), email.trim(), password);
			if (isSignup) await startVerification(false, result || undefined);
		} catch (submitError) {
			const message = submitError instanceof Error ? submitError.message : "Une erreur est survenue.";
			if (!isSignup && message === "EMAIL_NOT_VERIFIED") {
				await startVerification(true);
			} else {
				setError(message);
			}
		} finally {
			setLoading(false);
		}
	};
	const verifyCode = async (code) => {
		if (code.length !== 6 || loading) return;
		setLoading(true);
		setError("");
		try {
			await onVerifyEmail(email.trim(), code);
		} catch (verifyError) {
			setError(verifyError instanceof Error ? verifyError.message : "Le code est invalide ou expiré.");
			setOtp([
				"",
				"",
				"",
				"",
				"",
				""
			]);
			otpRefs.current[0]?.focus();
		} finally {
			setLoading(false);
		}
	};
	const changeOtp = (index, rawValue) => {
		const digits = rawValue.replace(/\D/g, "");
		if (digits.length > 1) {
			const pasted = digits.slice(0, 6).split("");
			const next = [
				"",
				"",
				"",
				"",
				"",
				""
			];
			pasted.forEach((digit, position) => {
				next[position] = digit;
			});
			setOtp(next);
			const target = Math.min(pasted.length, 5);
			otpRefs.current[target]?.focus();
			if (pasted.length === 6 && step === "verify-email") void verifyCode(pasted.join(""));
			return;
		}
		const next = [...otp];
		next[index] = digits;
		setOtp(next);
		if (digits && index < 5) otpRefs.current[index + 1]?.focus();
		if (next.every(Boolean) && step === "verify-email") void verifyCode(next.join(""));
	};
	const resend = async () => {
		if (resendSeconds || loading) return;
		setError("");
		setNotice("");
		setLoading(true);
		try {
			const result = step === "reset-password" ? await onForgotPassword(email.trim()) : await onResendCode(email.trim());
			setResendSeconds(60);
			setNotice(passwordDeliveryNotice(result));
		} catch (sendError) {
			setError(sendError instanceof Error ? sendError.message : "Impossible de renvoyer le code.");
		} finally {
			setLoading(false);
		}
	};
	const requestPasswordReset = async (event) => {
		event.preventDefault();
		setError("");
		setNotice("");
		setLoading(true);
		try {
			const result = await onForgotPassword(email.trim());
			setStep("reset-password");
			setOtp([
				"",
				"",
				"",
				"",
				"",
				""
			]);
			setPassword("");
			setPasswordConfirmation("");
			setResendSeconds(60);
			setNotice(passwordDeliveryNotice(result));
		} catch (resetError) {
			setError(resetError instanceof Error ? resetError.message : "Impossible de traiter la demande.");
		} finally {
			setLoading(false);
		}
	};
	const completePasswordReset = async (event) => {
		event.preventDefault();
		setError("");
		if (otp.some((digit) => !digit)) {
			setError("Saisissez le code à six chiffres reçu par email.");
			return;
		}
		if (password.length < 10 || !/\p{L}/u.test(password) || !/\d/.test(password)) {
			setError("Le mot de passe doit contenir au moins 10 caractères, une lettre et un chiffre.");
			return;
		}
		if (new TextEncoder().encode(password).length > 72 || TRIVIAL_PASSWORDS.has(password.toLowerCase())) {
			setError("Choisissez un mot de passe moins facile à deviner et limité à 72 octets.");
			return;
		}
		if (password !== passwordConfirmation) {
			setError("Les mots de passe ne correspondent pas.");
			return;
		}
		setLoading(true);
		try {
			const code = otp.join("");
			await onResetPassword(email.trim(), code, password);
			setPassword("");
			setPasswordConfirmation("");
			setStep("credentials");
			setNotice("Votre mot de passe a été réinitialisé. Vous pouvez vous connecter.");
			onSwitch("login");
		} catch (resetError) {
			setError(resetError instanceof Error ? resetError.message : "Impossible de réinitialiser le mot de passe.");
		} finally {
			setLoading(false);
		}
	};
	const title = step === "verify-email" ? "Vérifier votre email" : step === "forgot-password" ? "Mot de passe oublié ?" : step === "reset-password" ? "Réinitialiser le mot de passe" : isSignup ? "Créer votre espace" : "Se connecter";
	const intro = step === "verify-email" ? `Saisissez le code à six chiffres envoyé à ${email}.` : step === "forgot-password" ? "Indiquez votre adresse email pour recevoir un code de réinitialisation." : step === "reset-password" ? "Saisissez le code reçu et choisissez un nouveau mot de passe." : isSignup ? "Commencez votre analyse en quelques secondes." : "Accédez à votre espace d’analyse.";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "auth-page",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "auth-header",
			children: [/* @__PURE__ */ _jsxDEV("button", {
				className: "brand auth-brand",
				onClick: onBack,
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "brand-mark",
					children: /* @__PURE__ */ _jsxDEV(BarChart3, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 314,
						columnNumber: 40
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 314,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["AI Data ", /* @__PURE__ */ _jsxDEV("b", { children: "Analyst" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 314,
					columnNumber: 84
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 314,
					columnNumber: 70
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 313,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "back-link",
				onClick: onBack,
				children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 15 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 56
				}, this), " Retour à l’accueil"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 312,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "auth-layout",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "auth-aside",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "eyebrow",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "eyebrow-line" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 37
						}, this), " VOTRE ESPACE DATA"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: isSignup ? "Donnez une nouvelle dimension à vos données." : "Ravi de vous revoir parmi nous." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: isSignup ? "Créez votre espace et commencez à transformer vos fichiers en décisions éclairées." : "Retrouvez vos analyses, vos questions et vos insights au même endroit." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 322,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "auth-trust",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV(Check, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 45
						}, this), " Analyses instantanées"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 39
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV(LockKeyhole, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 99
						}, this), " Données sécurisées"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 93
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 323,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 319,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("section", {
				className: "auth-card",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "section-kicker",
						children: "AI DATA ANALYST"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 326,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 327,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "auth-intro",
						children: intro
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 328,
						columnNumber: 11
					}, this),
					step === "credentials" && /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: (event) => void submitCredentials(event),
						children: [
							isSignup && /* @__PURE__ */ _jsxDEV("label", { children: ["Nom complet", /* @__PURE__ */ _jsxDEV("input", {
								value: name,
								onChange: (event) => setName(event.target.value),
								placeholder: "Votre nom",
								autoComplete: "name"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 46
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 28
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Email professionnel", /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value),
								placeholder: "vous@entreprise.com",
								autoComplete: "email"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 41
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(PasswordField, {
								label: "Mot de passe",
								value: password,
								onChange: setPassword,
								placeholder: "••••••••••",
								autoComplete: isSignup ? "new-password" : "current-password"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 334,
								columnNumber: 15
							}, this),
							isSignup && password && /* @__PURE__ */ _jsxDEV("div", {
								className: `password-strength strength-${strength.score}`,
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "password-strength-track",
									children: /* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 61
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 337,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: ["Force du mot de passe : ", strength.label] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 17
							}, this),
							isSignup && /* @__PURE__ */ _jsxDEV(PasswordField, {
								label: "Confirmer le mot de passe",
								value: passwordConfirmation,
								onChange: setPasswordConfirmation,
								placeholder: "••••••••••",
								autoComplete: "new-password"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 28
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "error-banner auth-error",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 25
							}, this),
							notice && /* @__PURE__ */ _jsxDEV("p", {
								className: "auth-notice",
								children: notice
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 26
							}, this),
							!isSignup && /* @__PURE__ */ _jsxDEV("button", {
								className: "auth-text-link forgot-link",
								type: "button",
								onClick: () => {
									setError("");
									setNotice("");
									setStep("forgot-password");
								},
								children: "Mot de passe oublié ?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 344,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "primary-button auth-submit",
								type: "submit",
								disabled: loading,
								children: [
									loading ? "Veuillez patienter..." : isSignup ? "Créer mon compte" : "Se connecter",
									" ",
									/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 346,
										columnNumber: 102
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 345,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "auth-switch",
								children: [
									isSignup ? "Vous avez déjà un compte ?" : "Pas encore de compte ?",
									" ",
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											setError("");
											setNotice("");
											onSwitch(isSignup ? "login" : "signup");
										},
										children: isSignup ? "Se connecter" : "Créer un compte"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 348,
										columnNumber: 111
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 13
					}, this),
					step === "verify-email" && /* @__PURE__ */ _jsxDEV("div", {
						className: "auth-flow",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "otp-inputs",
								"aria-label": "Code de vérification à six chiffres",
								children: otp.map((digit, index) => /* @__PURE__ */ _jsxDEV("input", {
									ref: (element) => {
										otpRefs.current[index] = element;
									},
									"aria-label": `Chiffre ${index + 1}`,
									value: digit,
									inputMode: "numeric",
									autoComplete: index === 0 ? "one-time-code" : "off",
									maxLength: 6,
									onChange: (event) => changeOtp(index, event.target.value),
									onKeyDown: (event) => {
										if (event.key === "Backspace" && !digit && index > 0) otpRefs.current[index - 1]?.focus();
									}
								}, index, false, {
									fileName: _jsxFileName,
									lineNumber: 356,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 354,
								columnNumber: 15
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "error-banner auth-error",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 371,
								columnNumber: 25
							}, this),
							notice && /* @__PURE__ */ _jsxDEV("p", {
								className: "auth-notice",
								children: notice
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 372,
								columnNumber: 26
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "resend-code-row",
								children: [
									resendSeconds > 0 ? `Vous pourrez renvoyer le code dans ${resendSeconds} s` : "Vous n’avez pas reçu le code ?",
									" ",
									/* @__PURE__ */ _jsxDEV("button", {
										className: "auth-text-link",
										disabled: resendSeconds > 0 || loading,
										onClick: () => void resend(),
										children: "Renvoyer le code"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 373,
										columnNumber: 159
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 373,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "primary-button auth-submit",
								disabled: loading || otp.some((digit) => !digit),
								onClick: () => void verifyCode(otp.join("")),
								children: [
									loading ? "Vérification..." : "Vérifier mon email",
									" ",
									/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 211
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "auth-switch",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setError("");
										setNotice("");
										setStep("credentials");
									},
									children: "Retour à la connexion"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 42
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 375,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 353,
						columnNumber: 13
					}, this),
					step === "forgot-password" && /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: (event) => void requestPasswordReset(event),
						children: [
							/* @__PURE__ */ _jsxDEV("label", { children: ["Email professionnel", /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value),
								placeholder: "vous@entreprise.com",
								autoComplete: "email"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 381,
								columnNumber: 41
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 381,
								columnNumber: 15
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "error-banner auth-error",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "primary-button auth-submit",
								type: "submit",
								disabled: loading,
								children: [
									loading ? "Envoi..." : "Envoyer un code",
									" ",
									/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 138
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "auth-switch",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setError("");
										setStep("credentials");
									},
									children: "Retour à la connexion"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 384,
									columnNumber: 42
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 384,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 13
					}, this),
					step === "reset-password" && /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: (event) => void completePasswordReset(event),
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "otp-inputs",
								"aria-label": "Code de réinitialisation à six chiffres",
								children: otp.map((digit, index) => /* @__PURE__ */ _jsxDEV("input", {
									ref: (element) => {
										otpRefs.current[index] = element;
									},
									"aria-label": `Chiffre ${index + 1}`,
									value: digit,
									inputMode: "numeric",
									autoComplete: index === 0 ? "one-time-code" : "off",
									maxLength: 6,
									onChange: (event) => changeOtp(index, event.target.value),
									onKeyDown: (event) => {
										if (event.key === "Backspace" && !digit && index > 0) otpRefs.current[index - 1]?.focus();
									}
								}, index, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(PasswordField, {
								label: "Nouveau mot de passe",
								value: password,
								onChange: setPassword,
								autoComplete: "new-password"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 407,
								columnNumber: 15
							}, this),
							password && /* @__PURE__ */ _jsxDEV("p", {
								className: "password-hint",
								children: ["Force du mot de passe : ", strength.label]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 408,
								columnNumber: 28
							}, this),
							/* @__PURE__ */ _jsxDEV(PasswordField, {
								label: "Confirmer le mot de passe",
								value: passwordConfirmation,
								onChange: setPasswordConfirmation,
								autoComplete: "new-password"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 409,
								columnNumber: 15
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "error-banner auth-error",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 25
							}, this),
							notice && /* @__PURE__ */ _jsxDEV("p", {
								className: "auth-notice",
								children: notice
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 411,
								columnNumber: 26
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "resend-code-row",
								children: [
									resendSeconds > 0 ? `Vous pourrez renvoyer le code dans ${resendSeconds} s` : "Vous n’avez pas reçu le code ?",
									" ",
									/* @__PURE__ */ _jsxDEV("button", {
										className: "auth-text-link",
										type: "button",
										disabled: resendSeconds > 0 || loading,
										onClick: () => void resend(),
										children: "Renvoyer le code"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 412,
										columnNumber: 159
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 412,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "primary-button auth-submit",
								type: "submit",
								disabled: loading,
								children: [
									loading ? "Réinitialisation..." : "Réinitialiser le mot de passe",
									" ",
									/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 163
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 389,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 325,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 318,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 311,
		columnNumber: 5
	}, this);
}
_s2(AuthPage, "qmNpo6QzlqpIAS2IRgRGHivrumM=");
_c2 = AuthPage;
var _c, _c2;
$RefreshReg$(_c, "PasswordField");
$RefreshReg$(_c2, "AuthPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AuthPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AuthPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AuthPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AuthPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFlBQVksV0FBVyxPQUFPLEtBQUssUUFBUSxtQkFBbUI7QUFDbEYsU0FBUyxXQUFXLFFBQVEsZ0JBQWdDOzs7O0FBZTVELE1BQU0sb0JBQW9CLElBQUksSUFBSTtDQUFDO0NBQWU7Q0FBZ0I7Q0FBZTtDQUFlO0NBQWM7QUFBYSxDQUFDO0FBRTVILFNBQVMsaUJBQWlCLFVBQWtCO0NBQzFDLE1BQU0sUUFBUTtFQUNaLFNBQVMsVUFBVTtFQUNuQixTQUFTLEtBQUssUUFBUTtFQUN0QixLQUFLLEtBQUssUUFBUTtFQUNsQixlQUFlLEtBQUssUUFBUTtDQUM5QixDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQztDQUNsQixPQUFPO0VBQUU7RUFBTyxPQUFPLFFBQVEsSUFBSSxXQUFXLFFBQVEsSUFBSSxVQUFVO0NBQU87QUFDN0U7QUFFQSxTQUFTLHVCQUF1QixVQUEyQjtDQUN6RCxJQUFJLFVBQVUsa0JBQWtCLFdBQVc7RUFDekMsT0FBTztDQUNUO0NBQ0EsSUFBSSxVQUFVLGtCQUFrQixlQUFlO0VBQzdDLE9BQU87Q0FDVDtDQUNBLElBQUksVUFBVSxrQkFBa0IsU0FBUztFQUN2QyxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLGNBQWMsRUFDckIsT0FDQSxPQUNBLFVBQ0EsYUFDQSxnQkFPQzs7Q0FDRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLGFBQWEsVUFBVSxTQUFTO0NBQ3RDLE9BQ0Usd0JBQUMsU0FBRDtFQUFPLFdBQVU7WUFBakIsQ0FDRyxPQUNELHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQ0Usd0JBQUMsU0FBRDtJQUNFLE1BQU0sVUFBVSxTQUFTO0lBQ2xCO0lBQ1AsV0FBVyxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7SUFDbkM7SUFDQztHQUNmOzs7O2FBQ0Qsd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO0lBQ1YsY0FBWSxVQUFVLDRCQUE0QjtJQUNsRCxnQkFBYztJQUNkLGVBQWUsWUFBWSxZQUFZLENBQUMsT0FBTztjQUUvQyx3QkFBQyxZQUFEO0tBQVksTUFBTTtLQUFJLGVBQVk7SUFBUTs7Ozs7R0FDcEM7Ozs7V0FDSjs7Ozs7VUFDRDs7Ozs7O0FBRVg7OztBQUVBLE9BQU8sU0FBUyxTQUFTLEVBQ3ZCLE1BQ0EsUUFDQSxVQUNBLGVBQ0EsY0FDQSxrQkFDQSxpQkFDQSxZQUNROztDQUNSLE1BQU0sV0FBVyxTQUFTO0NBQzFCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBbUIsYUFBYTtDQUN4RCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUFTLEVBQUU7Q0FDbkUsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTO0VBQUM7RUFBSTtFQUFJO0VBQUk7RUFBSTtFQUFJO0NBQUUsQ0FBQztDQUN2RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxDQUFDO0NBQ3BELE1BQU0sVUFBVSxPQUF1QyxDQUFDLENBQUM7Q0FDekQsTUFBTSxXQUFXLGlCQUFpQixRQUFRO0NBRTFDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxlQUFlO0VBQ3BCLE1BQU0sUUFBUSxPQUFPLGlCQUFpQixrQkFBa0IsWUFBWSxVQUFVLENBQUMsR0FBRyxHQUFJO0VBQ3RGLGFBQWEsT0FBTyxhQUFhLEtBQUs7Q0FDeEMsR0FBRyxDQUFDLGFBQWEsQ0FBQztDQUVsQixNQUFNLG9CQUFvQixPQUFPLFFBQWlCLGFBQThCO0VBQzlFLFFBQVEsY0FBYztFQUN0QixPQUFPO0dBQUM7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0VBQUUsQ0FBQztFQUMvQixpQkFBaUIsRUFBRTtFQUNuQixTQUFTLEVBQUU7RUFDWCxVQUFVLFNBQVMsS0FBSyx1QkFBdUIsUUFBUSxDQUFDO0VBQ3hELElBQUksUUFBUTtHQUNWLElBQUk7SUFDRixNQUFNLFNBQVMsTUFBTSxhQUFhLE1BQU0sS0FBSyxDQUFDO0lBQzlDLFVBQVUsdUJBQXVCLE1BQU0sQ0FBQztHQUMxQyxTQUFTLFdBQVc7SUFDbEIsU0FBUyxxQkFBcUIsUUFBUSxVQUFVLFVBQVUsaUNBQWlDO0dBQzdGO0VBQ0Y7Q0FDRjtDQUVBLE1BQU0sb0JBQW9CLE9BQU8sVUFBc0M7RUFDckUsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsRUFBRTtFQUNYLFVBQVUsRUFBRTtFQUNaLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRztHQUNqQixTQUFTLGdDQUFnQztHQUN6QztFQUNGO0VBQ0EsSUFBSSxDQUFDLDZCQUE2QixLQUFLLE1BQU0sS0FBSyxDQUFDLEdBQUc7R0FDcEQsU0FBUyxxQ0FBcUM7R0FDOUM7RUFDRjtFQUNBLElBQUksQ0FBQyxVQUFVO0dBQ2IsU0FBUywrQkFBK0I7R0FDeEM7RUFDRjtFQUNBLElBQUksVUFBVTtHQUNaLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRztJQUNoQixTQUFTLGlDQUFpQztJQUMxQztHQUNGO0dBQ0EsSUFBSSxTQUFTLFNBQVMsTUFBTSxDQUFDLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxLQUFLLEtBQUssUUFBUSxHQUFHO0lBQzVFLFNBQVMsaUZBQWlGO0lBQzFGO0dBQ0Y7R0FDQSxJQUFJLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFTLElBQUk7SUFDbEQsU0FBUyxpREFBaUQ7SUFDMUQ7R0FDRjtHQUNBLElBQUksa0JBQWtCLElBQUksU0FBUyxZQUFZLENBQUMsR0FBRztJQUNqRCxTQUFTLDRDQUE0QztJQUNyRDtHQUNGO0dBQ0EsSUFBSSxDQUFDLHNCQUFzQjtJQUN6QixTQUFTLCtCQUErQjtJQUN4QztHQUNGO0dBQ0EsSUFBSSxhQUFhLHNCQUFzQjtJQUNyQyxTQUFTLHlDQUF5QztJQUNsRDtHQUNGO0VBQ0Y7RUFFQSxXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsTUFBTSxTQUFTLE1BQU0sU0FBUyxLQUFLLEtBQUssR0FBRyxNQUFNLEtBQUssR0FBRyxRQUFRO0dBQ2pFLElBQUksVUFBVSxNQUFNLGtCQUFrQixPQUFPLFVBQVUsU0FBUztFQUNsRSxTQUFTLGFBQWE7R0FDcEIsTUFBTSxVQUFVLHVCQUF1QixRQUFRLFlBQVksVUFBVTtHQUNyRSxJQUFJLENBQUMsWUFBWSxZQUFZLHNCQUFzQjtJQUNqRCxNQUFNLGtCQUFrQixJQUFJO0dBQzlCLE9BQU87SUFDTCxTQUFTLE9BQU87R0FDbEI7RUFDRixVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxNQUFNLGFBQWEsT0FBTyxTQUFpQjtFQUN6QyxJQUFJLEtBQUssV0FBVyxLQUFLLFNBQVM7RUFDbEMsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBQ1gsSUFBSTtHQUNGLE1BQU0sY0FBYyxNQUFNLEtBQUssR0FBRyxJQUFJO0VBQ3hDLFNBQVMsYUFBYTtHQUNwQixTQUFTLHVCQUF1QixRQUFRLFlBQVksVUFBVSxpQ0FBaUM7R0FDL0YsT0FBTztJQUFDO0lBQUk7SUFBSTtJQUFJO0lBQUk7SUFBSTtHQUFFLENBQUM7R0FDL0IsUUFBUSxRQUFRLEVBQUUsRUFBRSxNQUFNO0VBQzVCLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE1BQU0sYUFBYSxPQUFlLGFBQXFCO0VBQ3JELE1BQU0sU0FBUyxTQUFTLFFBQVEsT0FBTyxFQUFFO0VBQ3pDLElBQUksT0FBTyxTQUFTLEdBQUc7R0FDckIsTUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtHQUMxQyxNQUFNLE9BQU87SUFBQztJQUFJO0lBQUk7SUFBSTtJQUFJO0lBQUk7R0FBRTtHQUNwQyxPQUFPLFNBQVMsT0FBTyxhQUFhO0lBQUUsS0FBSyxZQUFZO0dBQU0sQ0FBQztHQUM5RCxPQUFPLElBQUk7R0FDWCxNQUFNLFNBQVMsS0FBSyxJQUFJLE9BQU8sUUFBUSxDQUFDO0dBQ3hDLFFBQVEsUUFBUSxPQUFPLEVBQUUsTUFBTTtHQUMvQixJQUFJLE9BQU8sV0FBVyxLQUFLLFNBQVMsZ0JBQWdCLEtBQUssV0FBVyxPQUFPLEtBQUssRUFBRSxDQUFDO0dBQ25GO0VBQ0Y7RUFFQSxNQUFNLE9BQU8sQ0FBQyxHQUFHLEdBQUc7RUFDcEIsS0FBSyxTQUFTO0VBQ2QsT0FBTyxJQUFJO0VBQ1gsSUFBSSxVQUFVLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxFQUFFLEVBQUUsTUFBTTtFQUMzRCxJQUFJLEtBQUssTUFBTSxPQUFPLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxXQUFXLEtBQUssS0FBSyxFQUFFLENBQUM7Q0FDbkY7Q0FFQSxNQUFNLFNBQVMsWUFBWTtFQUN6QixJQUFJLGlCQUFpQixTQUFTO0VBQzlCLFNBQVMsRUFBRTtFQUNYLFVBQVUsRUFBRTtFQUNaLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNLFNBQVMsU0FBUyxtQkFDcEIsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLENBQUMsSUFDbkMsTUFBTSxhQUFhLE1BQU0sS0FBSyxDQUFDO0dBQ25DLGlCQUFpQixFQUFFO0dBQ25CLFVBQVUsdUJBQXVCLE1BQU0sQ0FBQztFQUMxQyxTQUFTLFdBQVc7R0FDbEIsU0FBUyxxQkFBcUIsUUFBUSxVQUFVLFVBQVUsaUNBQWlDO0VBQzdGLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE1BQU0sdUJBQXVCLE9BQU8sVUFBc0M7RUFDeEUsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsRUFBRTtFQUNYLFVBQVUsRUFBRTtFQUNaLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNLFNBQVMsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLENBQUM7R0FDbEQsUUFBUSxnQkFBZ0I7R0FDeEIsT0FBTztJQUFDO0lBQUk7SUFBSTtJQUFJO0lBQUk7SUFBSTtHQUFFLENBQUM7R0FDL0IsWUFBWSxFQUFFO0dBQ2Qsd0JBQXdCLEVBQUU7R0FDMUIsaUJBQWlCLEVBQUU7R0FDbkIsVUFBVSx1QkFBdUIsTUFBTSxDQUFDO0VBQzFDLFNBQVMsWUFBWTtHQUNuQixTQUFTLHNCQUFzQixRQUFRLFdBQVcsVUFBVSxtQ0FBbUM7RUFDakcsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsTUFBTSx3QkFBd0IsT0FBTyxVQUFzQztFQUN6RSxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBQ1gsSUFBSSxJQUFJLE1BQU0sVUFBVSxDQUFDLEtBQUssR0FBRztHQUMvQixTQUFTLGtEQUFrRDtHQUMzRDtFQUNGO0VBQ0EsSUFBSSxTQUFTLFNBQVMsTUFBTSxDQUFDLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxLQUFLLEtBQUssUUFBUSxHQUFHO0dBQzVFLFNBQVMsaUZBQWlGO0dBQzFGO0VBQ0Y7RUFDQSxJQUFJLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFTLE1BQU0sa0JBQWtCLElBQUksU0FBUyxZQUFZLENBQUMsR0FBRztHQUNuRyxTQUFTLDBFQUEwRTtHQUNuRjtFQUNGO0VBQ0EsSUFBSSxhQUFhLHNCQUFzQjtHQUNyQyxTQUFTLHlDQUF5QztHQUNsRDtFQUNGO0VBQ0EsV0FBVyxJQUFJO0VBQ2YsSUFBSTtHQUNGLE1BQU0sT0FBTyxJQUFJLEtBQUssRUFBRTtHQUN4QixNQUFNLGdCQUFnQixNQUFNLEtBQUssR0FBRyxNQUFNLFFBQVE7R0FDbEQsWUFBWSxFQUFFO0dBQ2Qsd0JBQXdCLEVBQUU7R0FDMUIsUUFBUSxhQUFhO0dBQ3JCLFVBQVUsb0VBQW9FO0dBQzlFLFNBQVMsT0FBTztFQUNsQixTQUFTLFlBQVk7R0FDbkIsU0FBUyxzQkFBc0IsUUFBUSxXQUFXLFVBQVUsOENBQThDO0VBQzVHLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE1BQU0sUUFBUSxTQUFTLGlCQUNuQix5QkFDQSxTQUFTLG9CQUNQLDBCQUNBLFNBQVMsbUJBQ1Asa0NBQ0EsV0FBVyx1QkFBdUI7Q0FDMUMsTUFBTSxRQUFRLFNBQVMsaUJBQ25CLDZDQUE2QyxNQUFNLEtBQ25ELFNBQVMsb0JBQ1AsNEVBQ0EsU0FBUyxtQkFDUCxrRUFDQSxXQUFXLGtEQUFrRDtDQUVyRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUFsQixDQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQW1CLFNBQVM7Y0FBOUMsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O0lBQU87Ozs7Y0FBQyx3QkFBQyxRQUFELGFBQU0sWUFBUSx3QkFBQyxLQUFELFlBQUcsVUFBVTs7OztZQUFPOzs7O1lBQ3ZGOzs7OzthQUNSLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQVksU0FBUztjQUF2QyxDQUErQyx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2NBQUMscUJBQTJCOzs7OztXQUMzRjs7Ozs7WUFDUix3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFoQixDQUNFLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQTBCLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGVBQWdCOzs7O2dCQUFDLG9CQUF3Qjs7Ozs7O0tBQ25GLHdCQUFDLE1BQUQsWUFBSyxXQUFXLGlEQUFpRCxrQ0FBc0M7Ozs7O0tBQ3ZHLHdCQUFDLEtBQUQsWUFBSSxXQUFXLHVGQUF1Rix5RUFBNEU7Ozs7O0tBQ2xMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTRCLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O2dCQUFDLHdCQUE0Qjs7OztnQkFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztnQkFBQyxxQkFBeUI7Ozs7Y0FBTTs7Ozs7O0lBQ3pJOzs7OzthQUNULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWlCO0tBQXFCOzs7OztLQUN0RCx3QkFBQyxNQUFELFlBQUssTUFBVTs7Ozs7S0FDZix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYztLQUFTOzs7OztLQUVuQyxTQUFTLGlCQUNSLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLFVBQVUsS0FBSyxrQkFBa0IsS0FBSztnQkFBdkQ7T0FDRyxZQUFZLHdCQUFDLFNBQUQsYUFBTyxlQUFXLHdCQUFDLFNBQUQ7UUFBTyxPQUFPO1FBQU0sV0FBVyxVQUFVLFFBQVEsTUFBTSxPQUFPLEtBQUs7UUFBRyxhQUFZO1FBQVksY0FBYTtPQUFROzs7O2VBQVE7Ozs7O09BQzFKLHdCQUFDLFNBQUQsYUFBTyx1QkFBbUIsd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBUSxPQUFPO1FBQU8sV0FBVyxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7UUFBRyxhQUFZO1FBQXNCLGNBQWE7T0FBUzs7OztlQUFROzs7OztPQUMvSyx3QkFBQyxlQUFEO1FBQWUsT0FBTTtRQUFlLE9BQU87UUFBVSxVQUFVO1FBQWEsYUFBWTtRQUFhLGNBQWMsV0FBVyxpQkFBaUI7T0FBcUI7Ozs7O09BQ25LLFlBQVksWUFDWCx3QkFBQyxPQUFEO1FBQUssV0FBVyw4QkFBOEIsU0FBUztrQkFBdkQsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBMEIsd0JBQUMsUUFBRCxDQUFPOzs7OztRQUFPOzs7O2tCQUN4RCx3QkFBQyxTQUFELGFBQU8sNEJBQXlCLFNBQVMsS0FBYTs7OztnQkFDbkQ7Ozs7OztPQUVOLFlBQVksd0JBQUMsZUFBRDtRQUFlLE9BQU07UUFBNEIsT0FBTztRQUFzQixVQUFVO1FBQXlCLGFBQVk7UUFBYSxjQUFhO09BQWdCOzs7OztPQUNuTCxTQUFTLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUEyQjtPQUFXOzs7OztPQUM5RCxVQUFVLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFlO09BQVU7Ozs7O09BQ2hELENBQUMsWUFBWSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUE2QixNQUFLO1FBQVMsZUFBZTtTQUFFLFNBQVMsRUFBRTtTQUFHLFVBQVUsRUFBRTtTQUFHLFFBQVEsaUJBQWlCO1FBQUU7a0JBQUc7T0FBNkI7Ozs7O09BQ3BMLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQTZCLE1BQUs7UUFBUyxVQUFVO2tCQUF2RTtTQUNHLFVBQVUsMEJBQTBCLFdBQVcscUJBQXFCO1NBQWU7U0FBQyx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztRQUN0Rzs7Ozs7O09BQ1Isd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWI7U0FBNEIsV0FBVywrQkFBK0I7U0FBeUI7U0FBQyx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWU7V0FBRSxTQUFTLEVBQUU7V0FBRyxVQUFVLEVBQUU7V0FBRyxTQUFTLFdBQVcsVUFBVSxRQUFRO1VBQUU7b0JBQUksV0FBVyxpQkFBaUI7U0FBMEI7Ozs7O1FBQUk7Ozs7OztNQUN0UTs7Ozs7O0tBR1AsU0FBUyxrQkFDUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQWEsY0FBVztrQkFDcEMsSUFBSSxLQUFLLE9BQU8sVUFDZix3QkFBQyxTQUFEO1NBRUUsTUFBTSxZQUFZO1VBQUUsUUFBUSxRQUFRLFNBQVM7U0FBUTtTQUNyRCxjQUFZLFdBQVcsUUFBUTtTQUMvQixPQUFPO1NBQ1AsV0FBVTtTQUNWLGNBQWMsVUFBVSxJQUFJLGtCQUFrQjtTQUM5QyxXQUFXO1NBQ1gsV0FBVyxVQUFVLFVBQVUsT0FBTyxNQUFNLE9BQU8sS0FBSztTQUN4RCxZQUFZLFVBQVU7VUFDcEIsSUFBSSxNQUFNLFFBQVEsZUFBZSxDQUFDLFNBQVMsUUFBUSxHQUFHLFFBQVEsUUFBUSxRQUFRLEVBQUUsRUFBRSxNQUFNO1NBQzFGO1FBQ0QsR0FYTTs7OztlQVdOLENBQ0Y7T0FDRTs7Ozs7T0FDSixTQUFTLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUEyQjtPQUFXOzs7OztPQUM5RCxVQUFVLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFlO09BQVU7Ozs7O09BQ2pELHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQWdDLGdCQUFnQixJQUFJLHNDQUFzQyxjQUFjLE1BQU07U0FBaUM7U0FBQyx3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFpQixVQUFVLGdCQUFnQixLQUFLO1VBQVMsZUFBZSxLQUFLLE9BQU87b0JBQUc7U0FBd0I7Ozs7O1FBQUk7Ozs7OztPQUNyUix3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUE2QixVQUFVLFdBQVcsSUFBSSxNQUFNLFVBQVUsQ0FBQyxLQUFLO1FBQUcsZUFBZSxLQUFLLFdBQVcsSUFBSSxLQUFLLEVBQUUsQ0FBQztrQkFBNUk7U0FBZ0osVUFBVSxvQkFBb0I7U0FBcUI7U0FBQyx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztRQUFTOzs7Ozs7T0FDcE8sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWMsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxlQUFlO1VBQUUsU0FBUyxFQUFFO1VBQUcsVUFBVSxFQUFFO1VBQUcsUUFBUSxhQUFhO1NBQUU7bUJBQUc7UUFBNkI7Ozs7O09BQUk7Ozs7O01BQ3ZKOzs7Ozs7S0FHTixTQUFTLHFCQUNSLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLFVBQVUsS0FBSyxxQkFBcUIsS0FBSztnQkFBMUQ7T0FDRSx3QkFBQyxTQUFELGFBQU8sdUJBQW1CLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQVEsT0FBTztRQUFPLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO1FBQUcsYUFBWTtRQUFzQixjQUFhO09BQVM7Ozs7ZUFBUTs7Ozs7T0FDOUssU0FBUyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBMkI7T0FBVzs7Ozs7T0FDL0Qsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBNkIsTUFBSztRQUFTLFVBQVU7a0JBQXZFO1NBQWlGLFVBQVUsYUFBYTtTQUFrQjtTQUFDLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O1FBQVM7Ozs7OztPQUMzSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYyx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLGVBQWU7VUFBRSxTQUFTLEVBQUU7VUFBRyxRQUFRLGFBQWE7U0FBRTttQkFBRztRQUE2Qjs7Ozs7T0FBSTs7Ozs7TUFDdkk7Ozs7OztLQUdQLFNBQVMsb0JBQ1Isd0JBQUMsUUFBRDtNQUFNLFdBQVcsVUFBVSxLQUFLLHNCQUFzQixLQUFLO2dCQUEzRDtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQWEsY0FBVztrQkFDcEMsSUFBSSxLQUFLLE9BQU8sVUFDZix3QkFBQyxTQUFEO1NBRUUsTUFBTSxZQUFZO1VBQUUsUUFBUSxRQUFRLFNBQVM7U0FBUTtTQUNyRCxjQUFZLFdBQVcsUUFBUTtTQUMvQixPQUFPO1NBQ1AsV0FBVTtTQUNWLGNBQWMsVUFBVSxJQUFJLGtCQUFrQjtTQUM5QyxXQUFXO1NBQ1gsV0FBVyxVQUFVLFVBQVUsT0FBTyxNQUFNLE9BQU8sS0FBSztTQUN4RCxZQUFZLFVBQVU7VUFDcEIsSUFBSSxNQUFNLFFBQVEsZUFBZSxDQUFDLFNBQVMsUUFBUSxHQUFHLFFBQVEsUUFBUSxRQUFRLEVBQUUsRUFBRSxNQUFNO1NBQzFGO1FBQ0QsR0FYTTs7OztlQVdOLENBQ0Y7T0FDRTs7Ozs7T0FDTCx3QkFBQyxlQUFEO1FBQWUsT0FBTTtRQUF1QixPQUFPO1FBQVUsVUFBVTtRQUFhLGNBQWE7T0FBZ0I7Ozs7O09BQ2hILFlBQVksd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FBNkIsNEJBQXlCLFNBQVMsS0FBUzs7Ozs7O09BQ3JGLHdCQUFDLGVBQUQ7UUFBZSxPQUFNO1FBQTRCLE9BQU87UUFBc0IsVUFBVTtRQUF5QixjQUFhO09BQWdCOzs7OztPQUM3SSxTQUFTLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUEyQjtPQUFXOzs7OztPQUM5RCxVQUFVLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFlO09BQVU7Ozs7O09BQ2pELHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQWdDLGdCQUFnQixJQUFJLHNDQUFzQyxjQUFjLE1BQU07U0FBaUM7U0FBQyx3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFpQixNQUFLO1VBQVMsVUFBVSxnQkFBZ0IsS0FBSztVQUFTLGVBQWUsS0FBSyxPQUFPO29CQUFHO1NBQXdCOzs7OztRQUFJOzs7Ozs7T0FDblMsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBNkIsTUFBSztRQUFTLFVBQVU7a0JBQXZFO1NBQWlGLFVBQVUsd0JBQXdCO1NBQWdDO1NBQUMsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7Ozs7UUFBUzs7Ozs7O01BQ2hMOzs7Ozs7SUFFRDs7Ozs7V0FDTDs7Ozs7VUFDSDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFycm93TGVmdCwgQXJyb3dSaWdodCwgQmFyQ2hhcnQzLCBDaGVjaywgRXllLCBFeWVPZmYsIExvY2tLZXlob2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB0eXBlIHsgU2lnbnVwQWNjZXB0ZWQgfSBmcm9tICcuLi9zZXJ2aWNlcy9hdXRoU2VydmljZSdcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgdHlwZTogJ3NpZ251cCcgfCAnbG9naW4nXHJcbiAgb25CYWNrOiAoKSA9PiB2b2lkXHJcbiAgb25TdWJtaXQ6IChuYW1lOiBzdHJpbmcsIGVtYWlsOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpID0+IFByb21pc2U8U2lnbnVwQWNjZXB0ZWQgfCB2b2lkPlxyXG4gIG9uVmVyaWZ5RW1haWw6IChlbWFpbDogc3RyaW5nLCBjb2RlOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD5cclxuICBvblJlc2VuZENvZGU6IChlbWFpbDogc3RyaW5nKSA9PiBQcm9taXNlPFNpZ251cEFjY2VwdGVkPlxyXG4gIG9uRm9yZ290UGFzc3dvcmQ6IChlbWFpbDogc3RyaW5nKSA9PiBQcm9taXNlPFNpZ251cEFjY2VwdGVkPlxyXG4gIG9uUmVzZXRQYXNzd29yZDogKGVtYWlsOiBzdHJpbmcsIGNvZGU6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxyXG4gIG9uU3dpdGNoOiAodHlwZTogJ3NpZ251cCcgfCAnbG9naW4nKSA9PiB2b2lkXHJcbn1cclxuXHJcbnR5cGUgQXV0aFN0ZXAgPSAnY3JlZGVudGlhbHMnIHwgJ3ZlcmlmeS1lbWFpbCcgfCAnZm9yZ290LXBhc3N3b3JkJyB8ICdyZXNldC1wYXNzd29yZCdcclxuY29uc3QgVFJJVklBTF9QQVNTV09SRFMgPSBuZXcgU2V0KFsncGFzc3dvcmQxMjMnLCAncGFzc3dvcmQxMjM0JywgJ3F3ZXJ0eTEyMzQ1JywgJ2F6ZXJ0eTEyMzQ1JywgJzEyMzQ1Njc4OTAnLCAnaWxvdmV5b3UxMjMnXSlcclxuXHJcbmZ1bmN0aW9uIHBhc3N3b3JkU3RyZW5ndGgocGFzc3dvcmQ6IHN0cmluZykge1xyXG4gIGNvbnN0IHNjb3JlID0gW1xyXG4gICAgcGFzc3dvcmQubGVuZ3RoID49IDEwLFxyXG4gICAgL1xccHtMfS91LnRlc3QocGFzc3dvcmQpLFxyXG4gICAgL1xcZC8udGVzdChwYXNzd29yZCksXHJcbiAgICAvW15BLVphLXowLTldLy50ZXN0KHBhc3N3b3JkKSxcclxuICBdLmZpbHRlcihCb29sZWFuKS5sZW5ndGhcclxuICByZXR1cm4geyBzY29yZSwgbGFiZWw6IHNjb3JlIDwgMiA/ICdGYWlibGUnIDogc2NvcmUgPCA0ID8gJ01veWVuJyA6ICdGb3J0JyB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhc3N3b3JkRGVsaXZlcnlOb3RpY2UocmVzcG9uc2U/OiBTaWdudXBBY2NlcHRlZCkge1xyXG4gIGlmIChyZXNwb25zZT8uZGVsaXZlcnlfbW9kZSA9PT0gJ2NvbnNvbGUnKSB7XHJcbiAgICByZXR1cm4gJ0zigJllbnZvaSBwYXIgZW1haWwgYSDDqWNob3XDqS4gRW4gbW9kZSBkw6l2ZWxvcHBlbWVudCwgbGUgY29kZSBlc3QgYWZmaWNow6kgZGFucyBsZSB0ZXJtaW5hbCBkdSBiYWNrZW5kLiBWw6lyaWZpZXogbGEgY29uZmlndXJhdGlvbiBTTVRQIGV0IGNvbnN1bHRleiBsZXMgY291cnJpZXJzIGluZMOpc2lyYWJsZXMuJ1xyXG4gIH1cclxuICBpZiAocmVzcG9uc2U/LmRlbGl2ZXJ5X21vZGUgPT09ICd1bmF2YWlsYWJsZScpIHtcclxuICAgIHJldHVybiAnTGUgc2VydmljZSBlbWFpbCBu4oCZZXN0IHBhcyBjb25maWd1csOpLiBEZW1hbmRleiDDoCBs4oCZYWRtaW5pc3RyYXRldXIgZGUgY29uZmlndXJlciBsZSBzZXJ2ZXVyIFNNVFAuJ1xyXG4gIH1cclxuICBpZiAocmVzcG9uc2U/LmRlbGl2ZXJ5X21vZGUgPT09ICdlbWFpbCcpIHtcclxuICAgIHJldHVybiAnU2kgY2V0dGUgYWRyZXNzZSBlc3QgYXNzb2Npw6llIMOgIHVuIGNvbXB0ZSwgdW4gZW1haWwgY29udGVuYW50IHVuIGNvZGUgYSDDqXTDqSBlbnZvecOpLiBWw6lyaWZpZXogYXVzc2kgdm9zIGNvdXJyaWVycyBpbmTDqXNpcmFibGVzLidcclxuICB9XHJcbiAgcmV0dXJuICdTaSBjZXR0ZSBhZHJlc3NlIGVzdCBhc3NvY2nDqWUgw6AgdW4gY29tcHRlLCB1biBlbWFpbCBjb250ZW5hbnQgdW4gY29kZSBzZXJhIGVudm95w6kuJ1xyXG59XHJcblxyXG5mdW5jdGlvbiBQYXNzd29yZEZpZWxkKHtcclxuICBsYWJlbCxcclxuICB2YWx1ZSxcclxuICBvbkNoYW5nZSxcclxuICBwbGFjZWhvbGRlcixcclxuICBhdXRvQ29tcGxldGUsXHJcbn06IHtcclxuICBsYWJlbDogc3RyaW5nXHJcbiAgdmFsdWU6IHN0cmluZ1xyXG4gIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZFxyXG4gIHBsYWNlaG9sZGVyPzogc3RyaW5nXHJcbiAgYXV0b0NvbXBsZXRlOiBzdHJpbmdcclxufSkge1xyXG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFRvZ2dsZUljb24gPSB2aXNpYmxlID8gRXllT2ZmIDogRXllXHJcbiAgcmV0dXJuIChcclxuICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdXRoLXBhc3N3b3JkLWZpZWxkXCI+XHJcbiAgICAgIHtsYWJlbH1cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYXV0aC1wYXNzd29yZC1pbnB1dC13cmFwXCI+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPXt2aXNpYmxlID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ31cclxuICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17cGxhY2Vob2xkZXJ9XHJcbiAgICAgICAgICBhdXRvQ29tcGxldGU9e2F1dG9Db21wbGV0ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicGFzc3dvcmQtdmlzaWJpbGl0eS10b2dnbGVcIlxyXG4gICAgICAgICAgYXJpYS1sYWJlbD17dmlzaWJsZSA/ICdNYXNxdWVyIGxlIG1vdCBkZSBwYXNzZScgOiAnQWZmaWNoZXIgbGUgbW90IGRlIHBhc3NlJ31cclxuICAgICAgICAgIGFyaWEtcHJlc3NlZD17dmlzaWJsZX1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpc2libGUoKGN1cnJlbnQpID0+ICFjdXJyZW50KX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8VG9nZ2xlSWNvbiBzaXplPXsxNn0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9sYWJlbD5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBdXRoUGFnZSh7XHJcbiAgdHlwZSxcclxuICBvbkJhY2ssXHJcbiAgb25TdWJtaXQsXHJcbiAgb25WZXJpZnlFbWFpbCxcclxuICBvblJlc2VuZENvZGUsXHJcbiAgb25Gb3Jnb3RQYXNzd29yZCxcclxuICBvblJlc2V0UGFzc3dvcmQsXHJcbiAgb25Td2l0Y2gsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgaXNTaWdudXAgPSB0eXBlID09PSAnc2lnbnVwJ1xyXG4gIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlPEF1dGhTdGVwPignY3JlZGVudGlhbHMnKVxyXG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbcGFzc3dvcmRDb25maXJtYXRpb24sIHNldFBhc3N3b3JkQ29uZmlybWF0aW9uXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtvdHAsIHNldE90cF0gPSB1c2VTdGF0ZShbJycsICcnLCAnJywgJycsICcnLCAnJ10pXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbbm90aWNlLCBzZXROb3RpY2VdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW3Jlc2VuZFNlY29uZHMsIHNldFJlc2VuZFNlY29uZHNdID0gdXNlU3RhdGUoMClcclxuICBjb25zdCBvdHBSZWZzID0gdXNlUmVmPEFycmF5PEhUTUxJbnB1dEVsZW1lbnQgfCBudWxsPj4oW10pXHJcbiAgY29uc3Qgc3RyZW5ndGggPSBwYXNzd29yZFN0cmVuZ3RoKHBhc3N3b3JkKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFyZXNlbmRTZWNvbmRzKSByZXR1cm5cclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0UmVzZW5kU2Vjb25kcygoc2Vjb25kcykgPT4gc2Vjb25kcyAtIDEpLCAxMDAwKVxyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpXHJcbiAgfSwgW3Jlc2VuZFNlY29uZHNdKVxyXG5cclxuICBjb25zdCBzdGFydFZlcmlmaWNhdGlvbiA9IGFzeW5jIChyZXNlbmQ6IGJvb2xlYW4sIHJlc3BvbnNlPzogU2lnbnVwQWNjZXB0ZWQpID0+IHtcclxuICAgIHNldFN0ZXAoJ3ZlcmlmeS1lbWFpbCcpXHJcbiAgICBzZXRPdHAoWycnLCAnJywgJycsICcnLCAnJywgJyddKVxyXG4gICAgc2V0UmVzZW5kU2Vjb25kcyg2MClcclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgc2V0Tm90aWNlKHJlc2VuZCA/ICcnIDogcGFzc3dvcmREZWxpdmVyeU5vdGljZShyZXNwb25zZSkpXHJcbiAgICBpZiAocmVzZW5kKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb25SZXNlbmRDb2RlKGVtYWlsLnRyaW0oKSlcclxuICAgICAgICBzZXROb3RpY2UocGFzc3dvcmREZWxpdmVyeU5vdGljZShyZXN1bHQpKVxyXG4gICAgICB9IGNhdGNoIChzZW5kRXJyb3IpIHtcclxuICAgICAgICBzZXRFcnJvcihzZW5kRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IHNlbmRFcnJvci5tZXNzYWdlIDogJ0ltcG9zc2libGUgZGUgcmVudm95ZXIgbGUgY29kZS4nKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBzdWJtaXRDcmVkZW50aWFscyA9IGFzeW5jIChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgc2V0Tm90aWNlKCcnKVxyXG4gICAgaWYgKCFlbWFpbC50cmltKCkpIHtcclxuICAgICAgc2V0RXJyb3IoJ1NhaXNpc3NleiB2b3RyZSBhZHJlc3NlIGVtYWlsLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgaWYgKCEvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLy50ZXN0KGVtYWlsLnRyaW0oKSkpIHtcclxuICAgICAgc2V0RXJyb3IoJ1NhaXNpc3NleiB1bmUgYWRyZXNzZSBlbWFpbCB2YWxpZGUuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcbiAgICBpZiAoIXBhc3N3b3JkKSB7XHJcbiAgICAgIHNldEVycm9yKCdTYWlzaXNzZXogdm90cmUgbW90IGRlIHBhc3NlLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgaWYgKGlzU2lnbnVwKSB7XHJcbiAgICAgIGlmICghbmFtZS50cmltKCkpIHtcclxuICAgICAgICBzZXRFcnJvcignTGUgbm9tIGNvbXBsZXQgZXN0IG9ibGlnYXRvaXJlLicpXHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIH1cclxuICAgICAgaWYgKHBhc3N3b3JkLmxlbmd0aCA8IDEwIHx8ICEvXFxwe0x9L3UudGVzdChwYXNzd29yZCkgfHwgIS9cXGQvLnRlc3QocGFzc3dvcmQpKSB7XHJcbiAgICAgICAgc2V0RXJyb3IoJ0xlIG1vdCBkZSBwYXNzZSBkb2l0IGNvbnRlbmlyIGF1IG1vaW5zIDEwIGNhcmFjdMOocmVzLCB1bmUgbGV0dHJlIGV0IHVuIGNoaWZmcmUuJylcclxuICAgICAgICByZXR1cm5cclxuICAgICAgfVxyXG4gICAgICBpZiAobmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBhc3N3b3JkKS5sZW5ndGggPiA3Mikge1xyXG4gICAgICAgIHNldEVycm9yKCdMZSBtb3QgZGUgcGFzc2UgbmUgZG9pdCBwYXMgZMOpcGFzc2VyIDcyIG9jdGV0cy4nKVxyXG4gICAgICAgIHJldHVyblxyXG4gICAgICB9XHJcbiAgICAgIGlmIChUUklWSUFMX1BBU1NXT1JEUy5oYXMocGFzc3dvcmQudG9Mb3dlckNhc2UoKSkpIHtcclxuICAgICAgICBzZXRFcnJvcignQ2UgbW90IGRlIHBhc3NlIGVzdCB0cm9wIGZhY2lsZSDDoCBkZXZpbmVyLicpXHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIH1cclxuICAgICAgaWYgKCFwYXNzd29yZENvbmZpcm1hdGlvbikge1xyXG4gICAgICAgIHNldEVycm9yKCdDb25maXJtZXogdm90cmUgbW90IGRlIHBhc3NlLicpXHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIH1cclxuICAgICAgaWYgKHBhc3N3b3JkICE9PSBwYXNzd29yZENvbmZpcm1hdGlvbikge1xyXG4gICAgICAgIHNldEVycm9yKCdMZXMgbW90cyBkZSBwYXNzZSBuZSBjb3JyZXNwb25kZW50IHBhcy4nKVxyXG4gICAgICAgIHJldHVyblxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb25TdWJtaXQobmFtZS50cmltKCksIGVtYWlsLnRyaW0oKSwgcGFzc3dvcmQpXHJcbiAgICAgIGlmIChpc1NpZ251cCkgYXdhaXQgc3RhcnRWZXJpZmljYXRpb24oZmFsc2UsIHJlc3VsdCB8fCB1bmRlZmluZWQpXHJcbiAgICB9IGNhdGNoIChzdWJtaXRFcnJvcikge1xyXG4gICAgICBjb25zdCBtZXNzYWdlID0gc3VibWl0RXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IHN1Ym1pdEVycm9yLm1lc3NhZ2UgOiAnVW5lIGVycmV1ciBlc3Qgc3VydmVudWUuJ1xyXG4gICAgICBpZiAoIWlzU2lnbnVwICYmIG1lc3NhZ2UgPT09ICdFTUFJTF9OT1RfVkVSSUZJRUQnKSB7XHJcbiAgICAgICAgYXdhaXQgc3RhcnRWZXJpZmljYXRpb24odHJ1ZSlcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRFcnJvcihtZXNzYWdlKVxyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgdmVyaWZ5Q29kZSA9IGFzeW5jIChjb2RlOiBzdHJpbmcpID0+IHtcclxuICAgIGlmIChjb2RlLmxlbmd0aCAhPT0gNiB8fCBsb2FkaW5nKSByZXR1cm5cclxuICAgIHNldExvYWRpbmcodHJ1ZSlcclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgb25WZXJpZnlFbWFpbChlbWFpbC50cmltKCksIGNvZGUpXHJcbiAgICB9IGNhdGNoICh2ZXJpZnlFcnJvcikge1xyXG4gICAgICBzZXRFcnJvcih2ZXJpZnlFcnJvciBpbnN0YW5jZW9mIEVycm9yID8gdmVyaWZ5RXJyb3IubWVzc2FnZSA6ICdMZSBjb2RlIGVzdCBpbnZhbGlkZSBvdSBleHBpcsOpLicpXHJcbiAgICAgIHNldE90cChbJycsICcnLCAnJywgJycsICcnLCAnJ10pXHJcbiAgICAgIG90cFJlZnMuY3VycmVudFswXT8uZm9jdXMoKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGNoYW5nZU90cCA9IChpbmRleDogbnVtYmVyLCByYXdWYWx1ZTogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkaWdpdHMgPSByYXdWYWx1ZS5yZXBsYWNlKC9cXEQvZywgJycpXHJcbiAgICBpZiAoZGlnaXRzLmxlbmd0aCA+IDEpIHtcclxuICAgICAgY29uc3QgcGFzdGVkID0gZGlnaXRzLnNsaWNlKDAsIDYpLnNwbGl0KCcnKVxyXG4gICAgICBjb25zdCBuZXh0ID0gWycnLCAnJywgJycsICcnLCAnJywgJyddXHJcbiAgICAgIHBhc3RlZC5mb3JFYWNoKChkaWdpdCwgcG9zaXRpb24pID0+IHsgbmV4dFtwb3NpdGlvbl0gPSBkaWdpdCB9KVxyXG4gICAgICBzZXRPdHAobmV4dClcclxuICAgICAgY29uc3QgdGFyZ2V0ID0gTWF0aC5taW4ocGFzdGVkLmxlbmd0aCwgNSlcclxuICAgICAgb3RwUmVmcy5jdXJyZW50W3RhcmdldF0/LmZvY3VzKClcclxuICAgICAgaWYgKHBhc3RlZC5sZW5ndGggPT09IDYgJiYgc3RlcCA9PT0gJ3ZlcmlmeS1lbWFpbCcpIHZvaWQgdmVyaWZ5Q29kZShwYXN0ZWQuam9pbignJykpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG5leHQgPSBbLi4ub3RwXVxyXG4gICAgbmV4dFtpbmRleF0gPSBkaWdpdHNcclxuICAgIHNldE90cChuZXh0KVxyXG4gICAgaWYgKGRpZ2l0cyAmJiBpbmRleCA8IDUpIG90cFJlZnMuY3VycmVudFtpbmRleCArIDFdPy5mb2N1cygpXHJcbiAgICBpZiAobmV4dC5ldmVyeShCb29sZWFuKSAmJiBzdGVwID09PSAndmVyaWZ5LWVtYWlsJykgdm9pZCB2ZXJpZnlDb2RlKG5leHQuam9pbignJykpXHJcbiAgfVxyXG5cclxuICBjb25zdCByZXNlbmQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAocmVzZW5kU2Vjb25kcyB8fCBsb2FkaW5nKSByZXR1cm5cclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgc2V0Tm90aWNlKCcnKVxyXG4gICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gc3RlcCA9PT0gJ3Jlc2V0LXBhc3N3b3JkJ1xyXG4gICAgICAgID8gYXdhaXQgb25Gb3Jnb3RQYXNzd29yZChlbWFpbC50cmltKCkpXHJcbiAgICAgICAgOiBhd2FpdCBvblJlc2VuZENvZGUoZW1haWwudHJpbSgpKVxyXG4gICAgICBzZXRSZXNlbmRTZWNvbmRzKDYwKVxyXG4gICAgICBzZXROb3RpY2UocGFzc3dvcmREZWxpdmVyeU5vdGljZShyZXN1bHQpKVxyXG4gICAgfSBjYXRjaCAoc2VuZEVycm9yKSB7XHJcbiAgICAgIHNldEVycm9yKHNlbmRFcnJvciBpbnN0YW5jZW9mIEVycm9yID8gc2VuZEVycm9yLm1lc3NhZ2UgOiAnSW1wb3NzaWJsZSBkZSByZW52b3llciBsZSBjb2RlLicpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVxdWVzdFBhc3N3b3JkUmVzZXQgPSBhc3luYyAoZXZlbnQ6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBzZXRFcnJvcignJylcclxuICAgIHNldE5vdGljZSgnJylcclxuICAgIHNldExvYWRpbmcodHJ1ZSlcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9uRm9yZ290UGFzc3dvcmQoZW1haWwudHJpbSgpKVxyXG4gICAgICBzZXRTdGVwKCdyZXNldC1wYXNzd29yZCcpXHJcbiAgICAgIHNldE90cChbJycsICcnLCAnJywgJycsICcnLCAnJ10pXHJcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxyXG4gICAgICBzZXRQYXNzd29yZENvbmZpcm1hdGlvbignJylcclxuICAgICAgc2V0UmVzZW5kU2Vjb25kcyg2MClcclxuICAgICAgc2V0Tm90aWNlKHBhc3N3b3JkRGVsaXZlcnlOb3RpY2UocmVzdWx0KSlcclxuICAgIH0gY2F0Y2ggKHJlc2V0RXJyb3IpIHtcclxuICAgICAgc2V0RXJyb3IocmVzZXRFcnJvciBpbnN0YW5jZW9mIEVycm9yID8gcmVzZXRFcnJvci5tZXNzYWdlIDogJ0ltcG9zc2libGUgZGUgdHJhaXRlciBsYSBkZW1hbmRlLicpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgY29tcGxldGVQYXNzd29yZFJlc2V0ID0gYXN5bmMgKGV2ZW50OiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50PikgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0RXJyb3IoJycpXHJcbiAgICBpZiAob3RwLnNvbWUoKGRpZ2l0KSA9PiAhZGlnaXQpKSB7XHJcbiAgICAgIHNldEVycm9yKCdTYWlzaXNzZXogbGUgY29kZSDDoCBzaXggY2hpZmZyZXMgcmXDp3UgcGFyIGVtYWlsLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgaWYgKHBhc3N3b3JkLmxlbmd0aCA8IDEwIHx8ICEvXFxwe0x9L3UudGVzdChwYXNzd29yZCkgfHwgIS9cXGQvLnRlc3QocGFzc3dvcmQpKSB7XHJcbiAgICAgIHNldEVycm9yKCdMZSBtb3QgZGUgcGFzc2UgZG9pdCBjb250ZW5pciBhdSBtb2lucyAxMCBjYXJhY3TDqHJlcywgdW5lIGxldHRyZSBldCB1biBjaGlmZnJlLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgaWYgKG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwYXNzd29yZCkubGVuZ3RoID4gNzIgfHwgVFJJVklBTF9QQVNTV09SRFMuaGFzKHBhc3N3b3JkLnRvTG93ZXJDYXNlKCkpKSB7XHJcbiAgICAgIHNldEVycm9yKCdDaG9pc2lzc2V6IHVuIG1vdCBkZSBwYXNzZSBtb2lucyBmYWNpbGUgw6AgZGV2aW5lciBldCBsaW1pdMOpIMOgIDcyIG9jdGV0cy4nKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuICAgIGlmIChwYXNzd29yZCAhPT0gcGFzc3dvcmRDb25maXJtYXRpb24pIHtcclxuICAgICAgc2V0RXJyb3IoJ0xlcyBtb3RzIGRlIHBhc3NlIG5lIGNvcnJlc3BvbmRlbnQgcGFzLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY29kZSA9IG90cC5qb2luKCcnKVxyXG4gICAgICBhd2FpdCBvblJlc2V0UGFzc3dvcmQoZW1haWwudHJpbSgpLCBjb2RlLCBwYXNzd29yZClcclxuICAgICAgc2V0UGFzc3dvcmQoJycpXHJcbiAgICAgIHNldFBhc3N3b3JkQ29uZmlybWF0aW9uKCcnKVxyXG4gICAgICBzZXRTdGVwKCdjcmVkZW50aWFscycpXHJcbiAgICAgIHNldE5vdGljZSgnVm90cmUgbW90IGRlIHBhc3NlIGEgw6l0w6kgcsOpaW5pdGlhbGlzw6kuIFZvdXMgcG91dmV6IHZvdXMgY29ubmVjdGVyLicpXHJcbiAgICAgIG9uU3dpdGNoKCdsb2dpbicpXHJcbiAgICB9IGNhdGNoIChyZXNldEVycm9yKSB7XHJcbiAgICAgIHNldEVycm9yKHJlc2V0RXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IHJlc2V0RXJyb3IubWVzc2FnZSA6ICdJbXBvc3NpYmxlIGRlIHLDqWluaXRpYWxpc2VyIGxlIG1vdCBkZSBwYXNzZS4nKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IHRpdGxlID0gc3RlcCA9PT0gJ3ZlcmlmeS1lbWFpbCdcclxuICAgID8gJ1bDqXJpZmllciB2b3RyZSBlbWFpbCdcclxuICAgIDogc3RlcCA9PT0gJ2ZvcmdvdC1wYXNzd29yZCdcclxuICAgICAgPyAnTW90IGRlIHBhc3NlIG91Ymxpw6kgPydcclxuICAgICAgOiBzdGVwID09PSAncmVzZXQtcGFzc3dvcmQnXHJcbiAgICAgICAgPyAnUsOpaW5pdGlhbGlzZXIgbGUgbW90IGRlIHBhc3NlJ1xyXG4gICAgICAgIDogaXNTaWdudXAgPyAnQ3LDqWVyIHZvdHJlIGVzcGFjZScgOiAnU2UgY29ubmVjdGVyJ1xyXG4gIGNvbnN0IGludHJvID0gc3RlcCA9PT0gJ3ZlcmlmeS1lbWFpbCdcclxuICAgID8gYFNhaXNpc3NleiBsZSBjb2RlIMOgIHNpeCBjaGlmZnJlcyBlbnZvecOpIMOgICR7ZW1haWx9LmBcclxuICAgIDogc3RlcCA9PT0gJ2ZvcmdvdC1wYXNzd29yZCdcclxuICAgICAgPyAnSW5kaXF1ZXogdm90cmUgYWRyZXNzZSBlbWFpbCBwb3VyIHJlY2V2b2lyIHVuIGNvZGUgZGUgcsOpaW5pdGlhbGlzYXRpb24uJ1xyXG4gICAgICA6IHN0ZXAgPT09ICdyZXNldC1wYXNzd29yZCdcclxuICAgICAgICA/ICdTYWlzaXNzZXogbGUgY29kZSByZcOndSBldCBjaG9pc2lzc2V6IHVuIG5vdXZlYXUgbW90IGRlIHBhc3NlLidcclxuICAgICAgICA6IGlzU2lnbnVwID8gJ0NvbW1lbmNleiB2b3RyZSBhbmFseXNlIGVuIHF1ZWxxdWVzIHNlY29uZGVzLicgOiAnQWNjw6lkZXogw6Agdm90cmUgZXNwYWNlIGTigJlhbmFseXNlLidcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1wYWdlXCI+XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYXV0aC1oZWFkZXJcIj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJyYW5kIGF1dGgtYnJhbmRcIiBvbkNsaWNrPXtvbkJhY2t9PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnJhbmQtbWFya1wiPjxCYXJDaGFydDMgc2l6ZT17MTh9IC8+PC9zcGFuPjxzcGFuPkFJIERhdGEgPGI+QW5hbHlzdDwvYj48L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJiYWNrLWxpbmtcIiBvbkNsaWNrPXtvbkJhY2t9PjxBcnJvd0xlZnQgc2l6ZT17MTV9IC8+IFJldG91ciDDoCBs4oCZYWNjdWVpbDwvYnV0dG9uPlxyXG4gICAgICA8L2hlYWRlcj5cclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiYXV0aC1sYXlvdXRcIj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJhdXRoLWFzaWRlXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+PHNwYW4gY2xhc3NOYW1lPVwiZXllYnJvdy1saW5lXCIgLz4gVk9UUkUgRVNQQUNFIERBVEE8L3NwYW4+XHJcbiAgICAgICAgICA8aDE+e2lzU2lnbnVwID8gJ0Rvbm5leiB1bmUgbm91dmVsbGUgZGltZW5zaW9uIMOgIHZvcyBkb25uw6llcy4nIDogJ1JhdmkgZGUgdm91cyByZXZvaXIgcGFybWkgbm91cy4nfTwvaDE+XHJcbiAgICAgICAgICA8cD57aXNTaWdudXAgPyAnQ3LDqWV6IHZvdHJlIGVzcGFjZSBldCBjb21tZW5jZXogw6AgdHJhbnNmb3JtZXIgdm9zIGZpY2hpZXJzIGVuIGTDqWNpc2lvbnMgw6ljbGFpcsOpZXMuJyA6ICdSZXRyb3V2ZXogdm9zIGFuYWx5c2VzLCB2b3MgcXVlc3Rpb25zIGV0IHZvcyBpbnNpZ2h0cyBhdSBtw6ptZSBlbmRyb2l0Lid9PC9wPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXRydXN0XCI+PHNwYW4+PENoZWNrIHNpemU9ezE0fSAvPiBBbmFseXNlcyBpbnN0YW50YW7DqWVzPC9zcGFuPjxzcGFuPjxMb2NrS2V5aG9sZSBzaXplPXsxNH0gLz4gRG9ubsOpZXMgc8OpY3VyaXPDqWVzPC9zcGFuPjwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJhdXRoLWNhcmRcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlY3Rpb24ta2lja2VyXCI+QUkgREFUQSBBTkFMWVNUPC9zcGFuPlxyXG4gICAgICAgICAgPGgyPnt0aXRsZX08L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1pbnRyb1wiPntpbnRyb308L3A+XHJcblxyXG4gICAgICAgICAge3N0ZXAgPT09ICdjcmVkZW50aWFscycgJiYgKFxyXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGV2ZW50KSA9PiB2b2lkIHN1Ym1pdENyZWRlbnRpYWxzKGV2ZW50KX0+XHJcbiAgICAgICAgICAgICAge2lzU2lnbnVwICYmIDxsYWJlbD5Ob20gY29tcGxldDxpbnB1dCB2YWx1ZT17bmFtZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0TmFtZShldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIlZvdHJlIG5vbVwiIGF1dG9Db21wbGV0ZT1cIm5hbWVcIiAvPjwvbGFiZWw+fVxyXG4gICAgICAgICAgICAgIDxsYWJlbD5FbWFpbCBwcm9mZXNzaW9ubmVsPGlucHV0IHR5cGU9XCJlbWFpbFwiIHZhbHVlPXtlbWFpbH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJ2b3VzQGVudHJlcHJpc2UuY29tXCIgYXV0b0NvbXBsZXRlPVwiZW1haWxcIiAvPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFBhc3N3b3JkRmllbGQgbGFiZWw9XCJNb3QgZGUgcGFzc2VcIiB2YWx1ZT17cGFzc3dvcmR9IG9uQ2hhbmdlPXtzZXRQYXNzd29yZH0gcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKLigKLigKJcIiBhdXRvQ29tcGxldGU9e2lzU2lnbnVwID8gJ25ldy1wYXNzd29yZCcgOiAnY3VycmVudC1wYXNzd29yZCd9IC8+XHJcbiAgICAgICAgICAgICAge2lzU2lnbnVwICYmIHBhc3N3b3JkICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcGFzc3dvcmQtc3RyZW5ndGggc3RyZW5ndGgtJHtzdHJlbmd0aC5zY29yZX1gfT5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGFzc3dvcmQtc3RyZW5ndGgtdHJhY2tcIj48c3BhbiAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNtYWxsPkZvcmNlIGR1IG1vdCBkZSBwYXNzZSA6IHtzdHJlbmd0aC5sYWJlbH08L3NtYWxsPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7aXNTaWdudXAgJiYgPFBhc3N3b3JkRmllbGQgbGFiZWw9XCJDb25maXJtZXIgbGUgbW90IGRlIHBhc3NlXCIgdmFsdWU9e3Bhc3N3b3JkQ29uZmlybWF0aW9ufSBvbkNoYW5nZT17c2V0UGFzc3dvcmRDb25maXJtYXRpb259IHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCIgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCIgLz59XHJcbiAgICAgICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3ItYmFubmVyIGF1dGgtZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxyXG4gICAgICAgICAgICAgIHtub3RpY2UgJiYgPHAgY2xhc3NOYW1lPVwiYXV0aC1ub3RpY2VcIj57bm90aWNlfTwvcD59XHJcbiAgICAgICAgICAgICAgeyFpc1NpZ251cCAmJiA8YnV0dG9uIGNsYXNzTmFtZT1cImF1dGgtdGV4dC1saW5rIGZvcmdvdC1saW5rXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IoJycpOyBzZXROb3RpY2UoJycpOyBzZXRTdGVwKCdmb3Jnb3QtcGFzc3dvcmQnKSB9fT5Nb3QgZGUgcGFzc2Ugb3VibGnDqSA/PC9idXR0b24+fVxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b24gYXV0aC1zdWJtaXRcIiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2xvYWRpbmd9PlxyXG4gICAgICAgICAgICAgICAge2xvYWRpbmcgPyAnVmV1aWxsZXogcGF0aWVudGVyLi4uJyA6IGlzU2lnbnVwID8gJ0Nyw6llciBtb24gY29tcHRlJyA6ICdTZSBjb25uZWN0ZXInfSA8QXJyb3dSaWdodCBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN3aXRjaFwiPntpc1NpZ251cCA/ICdWb3VzIGF2ZXogZMOpasOgIHVuIGNvbXB0ZSA/JyA6ICdQYXMgZW5jb3JlIGRlIGNvbXB0ZSA/J30gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcignJyk7IHNldE5vdGljZSgnJyk7IG9uU3dpdGNoKGlzU2lnbnVwID8gJ2xvZ2luJyA6ICdzaWdudXAnKSB9fT57aXNTaWdudXAgPyAnU2UgY29ubmVjdGVyJyA6ICdDcsOpZXIgdW4gY29tcHRlJ308L2J1dHRvbj48L3A+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge3N0ZXAgPT09ICd2ZXJpZnktZW1haWwnICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWZsb3dcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm90cC1pbnB1dHNcIiBhcmlhLWxhYmVsPVwiQ29kZSBkZSB2w6lyaWZpY2F0aW9uIMOgIHNpeCBjaGlmZnJlc1wiPlxyXG4gICAgICAgICAgICAgICAge290cC5tYXAoKGRpZ2l0LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgIHJlZj17KGVsZW1lbnQpID0+IHsgb3RwUmVmcy5jdXJyZW50W2luZGV4XSA9IGVsZW1lbnQgfX1cclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQ2hpZmZyZSAke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkaWdpdH1cclxuICAgICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcclxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9e2luZGV4ID09PSAwID8gJ29uZS10aW1lLWNvZGUnIDogJ29mZid9XHJcbiAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs2fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IGNoYW5nZU90cChpbmRleCwgZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBvbktleURvd249eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0JhY2tzcGFjZScgJiYgIWRpZ2l0ICYmIGluZGV4ID4gMCkgb3RwUmVmcy5jdXJyZW50W2luZGV4IC0gMV0/LmZvY3VzKClcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3ItYmFubmVyIGF1dGgtZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxyXG4gICAgICAgICAgICAgIHtub3RpY2UgJiYgPHAgY2xhc3NOYW1lPVwiYXV0aC1ub3RpY2VcIj57bm90aWNlfTwvcD59XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicmVzZW5kLWNvZGUtcm93XCI+e3Jlc2VuZFNlY29uZHMgPiAwID8gYFZvdXMgcG91cnJleiByZW52b3llciBsZSBjb2RlIGRhbnMgJHtyZXNlbmRTZWNvbmRzfSBzYCA6ICdWb3VzIG7igJlhdmV6IHBhcyByZcOndSBsZSBjb2RlID8nfSA8YnV0dG9uIGNsYXNzTmFtZT1cImF1dGgtdGV4dC1saW5rXCIgZGlzYWJsZWQ9e3Jlc2VuZFNlY29uZHMgPiAwIHx8IGxvYWRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgcmVzZW5kKCl9PlJlbnZveWVyIGxlIGNvZGU8L2J1dHRvbj48L3A+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvbiBhdXRoLXN1Ym1pdFwiIGRpc2FibGVkPXtsb2FkaW5nIHx8IG90cC5zb21lKChkaWdpdCkgPT4gIWRpZ2l0KX0gb25DbGljaz17KCkgPT4gdm9pZCB2ZXJpZnlDb2RlKG90cC5qb2luKCcnKSl9Pntsb2FkaW5nID8gJ1bDqXJpZmljYXRpb24uLi4nIDogJ1bDqXJpZmllciBtb24gZW1haWwnfSA8QXJyb3dSaWdodCBzaXplPXsxNn0gLz48L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN3aXRjaFwiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IoJycpOyBzZXROb3RpY2UoJycpOyBzZXRTdGVwKCdjcmVkZW50aWFscycpIH19PlJldG91ciDDoCBsYSBjb25uZXhpb248L2J1dHRvbj48L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c3RlcCA9PT0gJ2ZvcmdvdC1wYXNzd29yZCcgJiYgKFxyXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGV2ZW50KSA9PiB2b2lkIHJlcXVlc3RQYXNzd29yZFJlc2V0KGV2ZW50KX0+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkVtYWlsIHByb2Zlc3Npb25uZWw8aW5wdXQgdHlwZT1cImVtYWlsXCIgdmFsdWU9e2VtYWlsfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFbWFpbChldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cInZvdXNAZW50cmVwcmlzZS5jb21cIiBhdXRvQ29tcGxldGU9XCJlbWFpbFwiIC8+PC9sYWJlbD5cclxuICAgICAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJlcnJvci1iYW5uZXIgYXV0aC1lcnJvclwiPntlcnJvcn08L2Rpdj59XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvbiBhdXRoLXN1Ym1pdFwiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30+e2xvYWRpbmcgPyAnRW52b2kuLi4nIDogJ0Vudm95ZXIgdW4gY29kZSd9IDxBcnJvd1JpZ2h0IHNpemU9ezE2fSAvPjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImF1dGgtc3dpdGNoXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRFcnJvcignJyk7IHNldFN0ZXAoJ2NyZWRlbnRpYWxzJykgfX0+UmV0b3VyIMOgIGxhIGNvbm5leGlvbjwvYnV0dG9uPjwvcD5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c3RlcCA9PT0gJ3Jlc2V0LXBhc3N3b3JkJyAmJiAoXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXsoZXZlbnQpID0+IHZvaWQgY29tcGxldGVQYXNzd29yZFJlc2V0KGV2ZW50KX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdHAtaW5wdXRzXCIgYXJpYS1sYWJlbD1cIkNvZGUgZGUgcsOpaW5pdGlhbGlzYXRpb24gw6Agc2l4IGNoaWZmcmVzXCI+XHJcbiAgICAgICAgICAgICAgICB7b3RwLm1hcCgoZGlnaXQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVmPXsoZWxlbWVudCkgPT4geyBvdHBSZWZzLmN1cnJlbnRbaW5kZXhdID0gZWxlbWVudCB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BDaGlmZnJlICR7aW5kZXggKyAxfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RpZ2l0fVxyXG4gICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT17aW5kZXggPT09IDAgPyAnb25lLXRpbWUtY29kZScgOiAnb2ZmJ31cclxuICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezZ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gY2hhbmdlT3RwKGluZGV4LCBldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnQmFja3NwYWNlJyAmJiAhZGlnaXQgJiYgaW5kZXggPiAwKSBvdHBSZWZzLmN1cnJlbnRbaW5kZXggLSAxXT8uZm9jdXMoKVxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8UGFzc3dvcmRGaWVsZCBsYWJlbD1cIk5vdXZlYXUgbW90IGRlIHBhc3NlXCIgdmFsdWU9e3Bhc3N3b3JkfSBvbkNoYW5nZT17c2V0UGFzc3dvcmR9IGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiIC8+XHJcbiAgICAgICAgICAgICAge3Bhc3N3b3JkICYmIDxwIGNsYXNzTmFtZT1cInBhc3N3b3JkLWhpbnRcIj5Gb3JjZSBkdSBtb3QgZGUgcGFzc2UgOiB7c3RyZW5ndGgubGFiZWx9PC9wPn1cclxuICAgICAgICAgICAgICA8UGFzc3dvcmRGaWVsZCBsYWJlbD1cIkNvbmZpcm1lciBsZSBtb3QgZGUgcGFzc2VcIiB2YWx1ZT17cGFzc3dvcmRDb25maXJtYXRpb259IG9uQ2hhbmdlPXtzZXRQYXNzd29yZENvbmZpcm1hdGlvbn0gYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCIgLz5cclxuICAgICAgICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJlcnJvci1iYW5uZXIgYXV0aC1lcnJvclwiPntlcnJvcn08L2Rpdj59XHJcbiAgICAgICAgICAgICAge25vdGljZSAmJiA8cCBjbGFzc05hbWU9XCJhdXRoLW5vdGljZVwiPntub3RpY2V9PC9wPn1cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyZXNlbmQtY29kZS1yb3dcIj57cmVzZW5kU2Vjb25kcyA+IDAgPyBgVm91cyBwb3VycmV6IHJlbnZveWVyIGxlIGNvZGUgZGFucyAke3Jlc2VuZFNlY29uZHN9IHNgIDogJ1ZvdXMgbuKAmWF2ZXogcGFzIHJlw6d1IGxlIGNvZGUgPyd9IDxidXR0b24gY2xhc3NOYW1lPVwiYXV0aC10ZXh0LWxpbmtcIiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e3Jlc2VuZFNlY29uZHMgPiAwIHx8IGxvYWRpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgcmVzZW5kKCl9PlJlbnZveWVyIGxlIGNvZGU8L2J1dHRvbj48L3A+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvbiBhdXRoLXN1Ym1pdFwiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30+e2xvYWRpbmcgPyAnUsOpaW5pdGlhbGlzYXRpb24uLi4nIDogJ1LDqWluaXRpYWxpc2VyIGxlIG1vdCBkZSBwYXNzZSd9IDxBcnJvd1JpZ2h0IHNpemU9ezE2fSAvPjwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgPC9tYWluPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==