const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=5b99bddd";
import App from "/src/App.tsx";
import "/src/style.css";
import "/src/error-styles.css";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/main.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
createRoot(document.getElementById("app")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 7,
	columnNumber: 64
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 7,
	columnNumber: 52
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxTQUFTO0FBQ2hCLE9BQU87QUFDUCxPQUFPOzs7QUFFUCxXQUFXLFNBQVMsZUFBZSxLQUFLLENBQUUsQ0FBQyxDQUFDLE9BQU8sd0JBQUMsWUFBRCxZQUFZLHdCQUFDLEtBQUQsQ0FBTTs7OztTQUFhOzs7O1FBQUMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcclxuaW1wb3J0IEFwcCBmcm9tICcuL0FwcCdcclxuaW1wb3J0ICcuL3N0eWxlLmNzcydcclxuaW1wb3J0ICcuL2Vycm9yLXN0eWxlcy5jc3MnXHJcblxyXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhcHAnKSEpLnJlbmRlcig8U3RyaWN0TW9kZT48QXBwIC8+PC9TdHJpY3RNb2RlPikiXX0=