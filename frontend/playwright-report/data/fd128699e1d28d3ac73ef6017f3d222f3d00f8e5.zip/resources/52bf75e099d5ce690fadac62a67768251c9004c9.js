import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DataPreviewTable.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];import { Rows3 } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/DataPreviewTable.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
function SingleTable({ dataset }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "preview-card",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "preview-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "section-kicker",
					children: "APERÇU DU FICHIER"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 81
				}, this), /* @__PURE__ */ _jsxDEV("h2", { children: dataset.filename }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 138
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 76
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "success-badge",
					children: "● Données prêtes"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 171
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 44
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "stats-row",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: dataset.row_count.toLocaleString("fr-FR") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 264
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Lignes" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 324
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 259
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: dataset.column_count }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 354
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Colonnes" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 393
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 349
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "columns-stat",
						children: [/* @__PURE__ */ _jsxDEV(Rows3, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 7,
							columnNumber: 450
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: dataset.column_names.join(" · ") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 7,
							columnNumber: 469
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 420
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 232
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "table-wrap",
				children: /* @__PURE__ */ _jsxDEV("table", { children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: dataset.column_names.map((column, index) => /* @__PURE__ */ _jsxDEV("th", { children: column }, `${column}-${index}`, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 619
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 570
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 563
				}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: dataset.preview.map((row, rowIndex) => /* @__PURE__ */ _jsxDEV("tr", { children: dataset.column_names.map((column, columnIndex) => /* @__PURE__ */ _jsxDEV("td", { children: String(row[column] ?? "") }, `${column}-${columnIndex}`, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 795
				}, this)) }, rowIndex, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 725
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 678
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 7,
					columnNumber: 556
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 528
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 10
	}, this);
}
_c = SingleTable;
export function DataPreviewTable({ datasets }) {
	if (!datasets.length) return /* @__PURE__ */ _jsxDEV("section", {
		className: "preview-card empty-state",
		children: [/* @__PURE__ */ _jsxDEV(Rows3, { size: 22 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 78
		}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Aucun aperçu disponible. Importez un fichier pour afficher ses données." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 97
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 32
	}, this);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: datasets.map((dataset) => /* @__PURE__ */ _jsxDEV(SingleTable, { dataset }, dataset.dataset_id, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 39
	}, this)) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 10
	}, this);
}
_c2 = DataPreviewTable;
var _c, _c2;
$RefreshReg$(_c, "SingleTable");
$RefreshReg$(_c2, "DataPreviewTable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DataPreviewTable.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/DataPreviewTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/DataPreviewTable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/DataPreviewTable.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhOzs7QUFLdEIsU0FBUyxZQUFZLEVBQUUsV0FBd0M7Q0FDN0QsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUFrQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQWdDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFpQjtJQUF1Qjs7OztjQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFRLFNBQWE7Ozs7WUFBTTs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWdCO0lBQXNCOzs7O1lBQU07Ozs7OztHQUFDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FBMkIsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUyxRQUFRLFVBQVUsZUFBZSxPQUFPLEVBQVU7Ozs7ZUFBQyx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OzthQUFNOzs7OztLQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVMsUUFBUSxhQUFxQjs7OztlQUFDLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O2FBQU07Ozs7O0tBQUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBOEIsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztnQkFBQyx3QkFBQyxRQUFELFlBQU8sUUFBUSxhQUFhLEtBQUssS0FBSyxFQUFROzs7O2NBQU07Ozs7OztJQUFNOzs7Ozs7R0FBQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFhLHdCQUFDLFNBQUQsYUFBTyx3QkFBQyxTQUFELFlBQU8sd0JBQUMsTUFBRCxZQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsVUFBVSx3QkFBQyxNQUFELFlBQWdDLE9BQVcsR0FBbEMsR0FBRyxPQUFPLEdBQUc7Ozs7V0FBcUIsQ0FBQyxFQUFNOzs7O2FBQVE7Ozs7Y0FBQyx3QkFBQyxTQUFELFlBQVEsUUFBUSxRQUFRLEtBQUssS0FBSyxhQUFhLHdCQUFDLE1BQUQsWUFBb0IsUUFBUSxhQUFhLEtBQUssUUFBUSxnQkFBZ0Isd0JBQUMsTUFBRCxZQUFzQyxPQUFPLElBQUksV0FBVyxFQUFFLEVBQU0sR0FBM0QsR0FBRyxPQUFPLEdBQUc7Ozs7V0FBOEMsQ0FBQyxFQUFNLEdBQXhJOzs7O1dBQXdJLENBQUMsRUFBUzs7OztZQUFROzs7OztHQUFNOzs7OztFQUFVOzs7Ozs7QUFDdjRCOztBQUVBLE9BQU8sU0FBUyxpQkFBaUIsRUFBRSxZQUFtQjtDQUNwRCxJQUFJLENBQUMsU0FBUyxRQUFRLE9BQU8sd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkIsQ0FBOEMsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztZQUFDLHdCQUFDLEtBQUQsWUFBRywwRUFBMEU7Ozs7VUFBVTs7Ozs7O0NBQ3JMLE9BQU8sK0NBQUcsU0FBUyxLQUFLLFlBQVksd0JBQUMsYUFBRCxFQUErQyxRQUFVLEdBQXZDLFFBQVE7Ozs7UUFBK0IsQ0FBQyxFQUFJOzs7OztBQUNwRyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXRhUHJldmlld1RhYmxlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSb3dzMyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBEYXRhc2V0UHJldmlldyB9IGZyb20gJy4uL3NlcnZpY2VzL2ZpbGVTZXJ2aWNlJ1xyXG5cclxudHlwZSBQcm9wcyA9IHsgZGF0YXNldHM6IERhdGFzZXRQcmV2aWV3W10gfVxyXG5cclxuZnVuY3Rpb24gU2luZ2xlVGFibGUoeyBkYXRhc2V0IH06IHsgZGF0YXNldDogRGF0YXNldFByZXZpZXcgfSkge1xyXG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJwcmV2aWV3LWNhcmRcIj48ZGl2IGNsYXNzTmFtZT1cInByZXZpZXctaGVhZGVyXCI+PGRpdj48c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWtpY2tlclwiPkFQRVLDh1UgRFUgRklDSElFUjwvc3Bhbj48aDI+e2RhdGFzZXQuZmlsZW5hbWV9PC9oMj48L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJzdWNjZXNzLWJhZGdlXCI+4pePIERvbm7DqWVzIHByw6p0ZXM8L3NwYW4+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJzdGF0cy1yb3dcIj48ZGl2PjxzdHJvbmc+e2RhdGFzZXQucm93X2NvdW50LnRvTG9jYWxlU3RyaW5nKCdmci1GUicpfTwvc3Ryb25nPjxzcGFuPkxpZ25lczwvc3Bhbj48L2Rpdj48ZGl2PjxzdHJvbmc+e2RhdGFzZXQuY29sdW1uX2NvdW50fTwvc3Ryb25nPjxzcGFuPkNvbG9ubmVzPC9zcGFuPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiY29sdW1ucy1zdGF0XCI+PFJvd3MzIHNpemU9ezE2fSAvPjxzcGFuPntkYXRhc2V0LmNvbHVtbl9uYW1lcy5qb2luKCcgwrcgJyl9PC9zcGFuPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwidGFibGUtd3JhcFwiPjx0YWJsZT48dGhlYWQ+PHRyPntkYXRhc2V0LmNvbHVtbl9uYW1lcy5tYXAoKGNvbHVtbiwgaW5kZXgpID0+IDx0aCBrZXk9e2Ake2NvbHVtbn0tJHtpbmRleH1gfT57Y29sdW1ufTwvdGg+KX08L3RyPjwvdGhlYWQ+PHRib2R5PntkYXRhc2V0LnByZXZpZXcubWFwKChyb3csIHJvd0luZGV4KSA9PiA8dHIga2V5PXtyb3dJbmRleH0+e2RhdGFzZXQuY29sdW1uX25hbWVzLm1hcCgoY29sdW1uLCBjb2x1bW5JbmRleCkgPT4gPHRkIGtleT17YCR7Y29sdW1ufS0ke2NvbHVtbkluZGV4fWB9PntTdHJpbmcocm93W2NvbHVtbl0gPz8gJycpfTwvdGQ+KX08L3RyPil9PC90Ym9keT48L3RhYmxlPjwvZGl2Pjwvc2VjdGlvbj5cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERhdGFQcmV2aWV3VGFibGUoeyBkYXRhc2V0cyB9OiBQcm9wcykge1xyXG4gIGlmICghZGF0YXNldHMubGVuZ3RoKSByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicHJldmlldy1jYXJkIGVtcHR5LXN0YXRlXCI+PFJvd3MzIHNpemU9ezIyfSAvPjxwPkF1Y3VuIGFwZXLDp3UgZGlzcG9uaWJsZS4gSW1wb3J0ZXogdW4gZmljaGllciBwb3VyIGFmZmljaGVyIHNlcyBkb25uw6llcy48L3A+PC9zZWN0aW9uPlxyXG4gIHJldHVybiA8PntkYXRhc2V0cy5tYXAoKGRhdGFzZXQpID0+IDxTaW5nbGVUYWJsZSBrZXk9e2RhdGFzZXQuZGF0YXNldF9pZH0gZGF0YXNldD17ZGF0YXNldH0gLz4pfTwvPlxyXG59Il19