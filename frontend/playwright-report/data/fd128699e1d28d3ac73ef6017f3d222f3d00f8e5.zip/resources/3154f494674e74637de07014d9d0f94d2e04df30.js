import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/error-styles.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/error-styles.css"
const __vite__css = ".error-banner {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  width: 100%;\r\n  padding: 11px 12px;\r\n  margin-top: 14px;\r\n  color: #991b1b;\r\n  background: #fef2f2;\r\n  border: 1px solid #fecaca;\r\n  border-left: 4px solid #dc2626;\r\n  border-radius: 7px;\r\n  font-size: 12px;\r\n  line-height: 1.45;\r\n}\r\n\r\n.auth-error {\r\n  position: static;\r\n  box-shadow: 0 4px 12px #991b1b12;\r\n}\r\n\r\n.settings-page .error-banner {\r\n  position: static;\r\n  margin-bottom: 14px;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))