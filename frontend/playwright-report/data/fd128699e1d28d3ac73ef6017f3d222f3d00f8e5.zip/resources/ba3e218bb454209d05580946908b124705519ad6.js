import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport12_react_jsxDevRuntime["Fragment"];import { ArrowRight, BarChart3, Check, CheckCircle2, ChevronRight, Database, FileChartColumn, LockKeyhole, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import { AuthPage } from "/src/components/AuthPage.tsx";
import { AnalysisBar } from "/src/components/AnalysisBar.tsx";
import { AnalysisPage } from "/src/components/AnalysisPage.tsx";
import { SettingsPage } from "/src/components/SettingsPage.tsx";
import { Sidebar } from "/src/components/Sidebar.tsx";
import { PublicSharedAnalysis } from "/src/components/PublicSharedAnalysis.tsx";
import { useDemoData } from "/src/hooks/useDemoData.ts";
import { getApiError } from "/src/services/api.ts";
import { getProfile, login, logout, requestPasswordReset, resendVerificationCode, resetPassword, signup, verifyEmail } from "/src/services/authService.ts";
import { uploadFiles } from "/src/services/fileService.ts";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/App.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
function Landing({ onAuth }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "landing",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "landing-header",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "brand",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "brand-mark",
						children: /* @__PURE__ */ _jsxDEV(BarChart3, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 122
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 93
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["AI Data ", /* @__PURE__ */ _jsxDEV("b", { children: "Analyst" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 166
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 152
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 70
				}, this), /* @__PURE__ */ _jsxDEV("nav", { children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "nav-login",
					onClick: () => onAuth("login"),
					children: "Log In"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 198
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "nav-signup",
					onClick: () => onAuth("signup"),
					children: ["Sign Up ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 15 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 347
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 275
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 193
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 35
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "hero",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "hero-copy",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "eyebrow",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "eyebrow-line" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 470
							}, this), " ANALYSEZ AVEC CLARTÉ"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 445
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", { children: [
							"Vos données.",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 546
							}, this),
							/* @__PURE__ */ _jsxDEV("em", { children: "Des réponses" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 552
							}, this),
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 573
							}, this),
							"qui comptent."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 530
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Importez vos données, posez vos questions, obtenez des analyses instantanées grâce à l’IA." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 597
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "trust-line",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV(Check, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 728
							}, this), " Sans carte bancaire"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 722
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV(LockKeyhole, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 780
							}, this), " Données sécurisées"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 774
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 694
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 418
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "hero-visual",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { className: "visual-grid" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 872
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "floating-card card-main",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "card-label",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "live-dot" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 15,
										columnNumber: 972
									}, this), " ANALYSE EN COURS"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 944
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "visual-title",
									children: [
										"Performance",
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1065
										}, this),
										/* @__PURE__ */ _jsxDEV("b", { children: "étudiants" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1071
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1024
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mini-chart",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "34%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1121
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "48%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1155
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "43%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1189
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "68%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1223
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "58%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1257
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "86%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1291
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { style: { height: "76%" } }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1325
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1093
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "chart-caption",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Jan" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1396
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "Juil" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1412
										}, this),
										/* @__PURE__ */ _jsxDEV("strong", { children: "+24.8%" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 15,
											columnNumber: 1429
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1365
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 903
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "floating-card card-stat",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "stat-icon",
									children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 15,
										columnNumber: 1533
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1505
								}, this),
								/* @__PURE__ */ _jsxDEV("strong", { children: "1,204" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1562
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: "lignes analysées" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1584
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 1464
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "floating-card card-question",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "question-mark",
									children: "?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1666
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [
									"Pourquoi ce pic",
									/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 15,
										columnNumber: 1727
									}, this),
									"en juin ?"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1706
								}, this),
								/* @__PURE__ */ _jsxDEV(ChevronRight, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 15,
									columnNumber: 1749
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 1621
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 843
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 395
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "landing-bottom",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Database, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1835
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: "Un espace unique" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1863
					}, this), " pour comprendre vos données"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1857
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1830
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(FileChartColumn, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1932
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: "Des réponses visuelles" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1967
					}, this), " en quelques secondes"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1961
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 1927
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(BarChart3, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 2035
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("b", { children: "Des décisions éclairées" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 2064
					}, this), " par des faits"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 2058
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 15,
						columnNumber: 2030
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 1794
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 10
	}, this);
}
_c = Landing;
function Analyst({ userName, profilePhoto, onSettings, onLogout }) {
	_s();
	const { history, messages, isAnalyzing, activeConversationId, historyError, askQuestion, createNewConversation, updateConversationDatasets, loadHistoryEntry, refreshHistory, remove, rename, toggleFavorite } = useDemoData();
	const [analysis, setAnalysis] = useState(null);
	const initials = userName.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "U";
	const startNewConversation = async () => {
		setAnalysis(null);
		await createNewConversation();
	};
	const openHistory = async (id) => {
		try {
			const selected = await loadHistoryEntry(id);
			if (selected) {
				setAnalysis({
					datasets: selected.datasets,
					question: selected.question,
					chartConfig: selected.chartConfig
				});
			}
		} catch {
			return;
		}
	};
	const askFromAnalysis = async (question, datasetIds) => {
		const selectedDatasetIds = datasetIds ?? analysis?.datasets.map((dataset) => dataset.dataset_id) ?? [];
		let conversationId = activeConversationId;
		if (conversationId === null) {
			conversationId = await createNewConversation(selectedDatasetIds);
		} else {
			const currentDatasetIds = analysis?.datasets.map((dataset) => dataset.dataset_id) ?? [];
			await updateConversationDatasets(conversationId, [...new Set([...currentDatasetIds, ...selectedDatasetIds])]);
		}
		const answer = await askQuestion(question, selectedDatasetIds, conversationId);
		if (answer?.chart_config) setAnalysis((current) => current ? {
			...current,
			chartConfig: answer.chart_config
		} : current);
	};
	const addFilesToAnalysis = async (files) => {
		const addedDatasets = await uploadFiles(files);
		const updatedDatasets = [...analysis?.datasets ?? [], ...addedDatasets];
		if (activeConversationId !== null) {
			await updateConversationDatasets(activeConversationId, updatedDatasets.map((dataset) => dataset.dataset_id));
		}
		setAnalysis((current) => current ? {
			...current,
			datasets: [...current.datasets, ...addedDatasets]
		} : current);
		await refreshHistory();
	};
	const startAnalysis = async (datasets, question) => {
		const datasetIds = datasets.map((dataset) => dataset.dataset_id);
		const conversationId = activeConversationId === null ? await createNewConversation(datasetIds) : activeConversationId;
		if (activeConversationId !== null) await updateConversationDatasets(conversationId, datasetIds);
		setAnalysis({
			datasets,
			question,
			chartConfig: null
		});
		if (!question.trim()) return;
		const answer = await askQuestion(question, datasetIds, conversationId);
		if (answer?.chart_config) setAnalysis((current) => current ? {
			...current,
			chartConfig: answer.chart_config
		} : current);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-shell",
		children: [/* @__PURE__ */ _jsxDEV(Sidebar, {
			userName,
			profilePhoto,
			history,
			activeId: activeConversationId ?? 0,
			error: historyError,
			onRetry: () => void refreshHistory(),
			onNew: () => void startNewConversation().catch(() => undefined),
			onHistory: (id) => void openHistory(id),
			onSettings,
			onLogout,
			onRename: rename,
			onToggleFavorite: toggleFavorite,
			onRemove: remove
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "workspace",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "workspace-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "workspace-kicker",
					children: "ESPACE D’ANALYSE"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 16
				}, this), /* @__PURE__ */ _jsxDEV("h1", { children: [
					analysis ? "Analyse détaillée" : `Bonjour, ${userName}`,
					" ",
					/* @__PURE__ */ _jsxDEV("span", { children: analysis ? "📊" : "👋" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 136
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 74
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "user-chip",
					onClick: onSettings,
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: `user-chip-avatar ${profilePhoto ? "user-chip-avatar-image" : ""}`,
						children: profilePhoto ? /* @__PURE__ */ _jsxDEV("img", {
							src: profilePhoto,
							alt: "Photo de profil"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 114
						}, this) : initials
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("strong", { children: userName }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 18
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "workspace-content",
				children: analysis ? /* @__PURE__ */ _jsxDEV(AnalysisPage, {
					datasets: analysis.datasets,
					firstQuestion: analysis.question,
					messages,
					isAnalyzing,
					chartConfig: analysis.chartConfig,
					onAsk: (question, datasetIds) => void askFromAnalysis(question, datasetIds),
					onAddFiles: addFilesToAnalysis
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 15
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "page-intro",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Nouvelle analyse" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 50
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Transformez une question en décision." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 75
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 45
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "usage-pill",
						children: "12 / 50 analyses ce mois"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 125
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV(AnalysisBar, { onAnalyze: (dataset, question) => void startAnalysis(dataset, question) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 191
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 5
	}, this);
}
_s(Analyst, "upiOtGqBqDtQxqIDmJQ3mmhY23s=", false, function() {
	return [useDemoData];
});
_c2 = Analyst;
function AppShell() {
	_s2();
	const [isLoggedIn, setIsLoggedIn] = useState(Boolean(localStorage.getItem("access_token")));
	const [userName, setUserName] = useState("Utilisateur");
	const [profilePhoto, setProfilePhoto] = useState(localStorage.getItem("user_photo") || "");
	const [authPage, setAuthPage] = useState(null);
	const [settingsPage, setSettingsPage] = useState(false);
	const [accountDeletionNotice, setAccountDeletionNotice] = useState(null);
	useEffect(() => {
		const onExpired = () => {
			setIsLoggedIn(false);
			setSettingsPage(false);
			setProfilePhoto("");
		};
		window.addEventListener("auth:expired", onExpired);
		if (localStorage.getItem("access_token")) {
			getProfile().then((profile) => {
				setUserName(profile.name);
				setProfilePhoto(profile.profile_photo || "");
			}).catch(onExpired);
		}
		return () => window.removeEventListener("auth:expired", onExpired);
	}, []);
	useEffect(() => {
		if (profilePhoto) localStorage.setItem("user_photo", profilePhoto);
		else localStorage.removeItem("user_photo");
	}, [profilePhoto]);
	const submitAuth = async (name, email, password) => {
		try {
			if (authPage === "signup") {
				return await signup({
					name: name.trim(),
					email,
					password
				});
			}
			await login({
				email,
				password
			});
			const profile = await getProfile();
			setUserName(profile.name);
			setProfilePhoto(profile.profile_photo || "");
			setIsLoggedIn(true);
			setAuthPage(null);
		} catch (error) {
			throw new Error(getApiError(error));
		}
	};
	const signOut = async () => {
		await logout();
		setIsLoggedIn(false);
		setSettingsPage(false);
		setProfilePhoto("");
	};
	if (isLoggedIn && settingsPage) {
		return /* @__PURE__ */ _jsxDEV(SettingsPage, {
			initialName: userName,
			profilePhoto,
			onBack: () => setSettingsPage(false),
			onSaveName: (name) => {
				setUserName(name);
				setSettingsPage(false);
			},
			onSavePhoto: setProfilePhoto,
			onAccountDeleted: (filesCleanupPending) => {
				setIsLoggedIn(false);
				setSettingsPage(false);
				setUserName("Utilisateur");
				setProfilePhoto("");
				setAccountDeletionNotice(filesCleanupPending);
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 174,
			columnNumber: 7
		}, this);
	}
	if (isLoggedIn) {
		return /* @__PURE__ */ _jsxDEV(Analyst, {
			userName,
			profilePhoto,
			onSettings: () => setSettingsPage(true),
			onLogout: signOut
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 195,
			columnNumber: 12
		}, this);
	}
	if (authPage) {
		return /* @__PURE__ */ _jsxDEV(AuthPage, {
			type: authPage,
			onBack: () => setAuthPage(null),
			onSubmit: submitAuth,
			onVerifyEmail: async (email, code) => {
				await verifyEmail({
					email,
					code
				});
				const profile = await getProfile();
				setUserName(profile.name);
				setProfilePhoto(profile.profile_photo || "");
				setIsLoggedIn(true);
				setAuthPage(null);
			},
			onResendCode: resendVerificationCode,
			onForgotPassword: requestPasswordReset,
			onResetPassword: async (email, code, password) => {
				await resetPassword({
					email,
					code,
					new_password: password
				});
			},
			onSwitch: setAuthPage
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 198,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Landing, { onAuth: setAuthPage }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 218,
		columnNumber: 7
	}, this), accountDeletionNotice !== null && /* @__PURE__ */ _jsxDEV("div", {
		className: "success-modal-backdrop",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "success-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "account-deleted-title",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "success-modal-icon",
					children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 26 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 222,
						columnNumber: 50
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					id: "account-deleted-title",
					children: "Compte supprimé"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 223,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: ["Votre compte et ses données ont été supprimés. Vous avez été déconnecté.", accountDeletionNotice > 0 && ` ${accountDeletionNotice} fichier(s) importé(s) n’ont pas pu être supprimés du disque.`] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 224,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: "primary-button",
					onClick: () => setAccountDeletionNotice(null),
					children: "Retour à l’accueil"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 228,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 221,
			columnNumber: 11
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 220,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 217,
		columnNumber: 5
	}, this);
}
_s2(AppShell, "cjA8MQvYedXsdqO31dG25mfOB+g=");
_c3 = AppShell;
export default function App() {
	const shareToken = window.location.pathname.match(/^\/share\/([^/]+)$/)?.[1];
	if (shareToken) return /* @__PURE__ */ _jsxDEV(PublicSharedAnalysis, { token: decodeURIComponent(shareToken) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 238,
		columnNumber: 26
	}, this);
	return /* @__PURE__ */ _jsxDEV(AppShell, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 239,
		columnNumber: 10
	}, this);
}
_c4 = App;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Landing");
$RefreshReg$(_c2, "Analyst");
$RefreshReg$(_c3, "AppShell");
$RefreshReg$(_c4, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZLFdBQVcsT0FBTyxjQUFjLGNBQWMsVUFBVSxpQkFBaUIsYUFBYSxnQkFBZ0I7QUFDM0gsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGVBQWU7QUFDeEIsU0FBUyw0QkFBNEI7QUFDckMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxZQUFZLE9BQU8sUUFBUSxzQkFBc0Isd0JBQXdCLGVBQWUsUUFBUSxtQkFBbUI7QUFDNUgsU0FBUyxtQkFBd0M7Ozs7QUFFakQsU0FBUyxRQUFRLEVBQUUsVUFBMEQ7Q0FDM0UsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQXlCLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQW1DLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBdUIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWEsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7S0FBTzs7OztlQUFDLHdCQUFDLFFBQUQsYUFBTSxZQUFRLHdCQUFDLEtBQUQsWUFBRyxVQUFVOzs7O2FBQU87Ozs7YUFBTTs7Ozs7Y0FBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBWSxlQUFlLE9BQU8sT0FBTztlQUFHO0lBQWM7Ozs7Y0FBQyx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFhLGVBQWUsT0FBTyxRQUFRO2VBQTdELENBQWdFLFlBQVEsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OzthQUFTOzs7OztZQUFNOzs7O1lBQVM7Ozs7OztHQUFDLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCLENBQXVCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFBMkIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBeUIsd0JBQUMsUUFBRCxFQUFNLFdBQVUsZUFBZ0I7Ozs7aUJBQUMsdUJBQTBCOzs7Ozs7TUFBQyx3QkFBQyxNQUFEO09BQUk7T0FBWSx3QkFBQyxNQUFELENBQUs7Ozs7O09BQUMsd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7OztPQUFDLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7T0FBQztNQUFpQjs7Ozs7TUFBQyx3QkFBQyxLQUFELFlBQUcsNkZBQTZGOzs7OztNQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTRCLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O2lCQUFDLHNCQUEwQjs7OztpQkFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztpQkFBQyxxQkFBeUI7Ozs7ZUFBTTs7Ozs7O0tBQU07Ozs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUE2Qix3QkFBQyxPQUFELEVBQUssV0FBVSxjQUFlOzs7OztNQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQXlDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQTRCLHdCQUFDLFFBQUQsRUFBTSxXQUFVLFdBQVk7Ozs7bUJBQUMsbUJBQXNCOzs7Ozs7UUFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUE4QjtVQUFXLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7VUFBQyx3QkFBQyxLQUFELFlBQUcsWUFBWTs7Ozs7U0FBTTs7Ozs7O1FBQUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBNEIsd0JBQUMsUUFBRCxFQUFNLE9BQU8sRUFBRSxRQUFRLE1BQU0sRUFBSTs7Ozs7VUFBQyx3QkFBQyxRQUFELEVBQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxFQUFJOzs7OztVQUFDLHdCQUFDLFFBQUQsRUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLEVBQUk7Ozs7O1VBQUMsd0JBQUMsUUFBRCxFQUFNLE9BQU8sRUFBRSxRQUFRLE1BQU0sRUFBSTs7Ozs7VUFBQyx3QkFBQyxRQUFELEVBQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxFQUFJOzs7OztVQUFDLHdCQUFDLFFBQUQsRUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLEVBQUk7Ozs7O1VBQUMsd0JBQUMsUUFBRCxFQUFNLE9BQU8sRUFBRSxRQUFRLE1BQU0sRUFBSTs7Ozs7U0FBTTs7Ozs7O1FBQUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBK0Isd0JBQUMsUUFBRCxZQUFNLE1BQVM7Ozs7O1VBQUMsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7O1VBQUMsd0JBQUMsVUFBRCxZQUFRLFNBQWM7Ozs7O1NBQU07Ozs7OztPQUFNOzs7Ozs7TUFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUF5Qyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBWSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztRQUFPOzs7OztRQUFDLHdCQUFDLFVBQUQsWUFBUSxRQUFhOzs7OztRQUFDLHdCQUFDLFNBQUQsWUFBTyxtQkFBdUI7Ozs7O09BQU07Ozs7OztNQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQTZDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnQjtRQUFPOzs7OztRQUFDLHdCQUFDLFFBQUQ7U0FBTTtTQUFlLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7U0FBQztRQUFlOzs7OztRQUFDLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O09BQU07Ozs7OztLQUFNOzs7OztZQUFPOzs7Ozs7R0FBQyx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUFvQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztlQUFDLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxLQUFELFlBQUcsbUJBQW1COzs7O2VBQUMsOEJBQWtDOzs7O2FBQU07Ozs7O0tBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLGlCQUFELEVBQWlCLE1BQU0sR0FBSzs7OztlQUFDLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxLQUFELFlBQUcseUJBQXlCOzs7O2VBQUMsdUJBQTJCOzs7O2FBQU07Ozs7O0tBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7ZUFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRCxZQUFHLDBCQUEwQjs7OztlQUFDLGdCQUFvQjs7OzthQUFNOzs7OztJQUFVOzs7Ozs7RUFBTTs7Ozs7O0FBQ3ZsRTs7QUFFQSxTQUFTLFFBQVEsRUFBRSxVQUFVLGNBQWMsWUFBWSxZQUFzRzs7Q0FDM0osTUFBTSxFQUNKLFNBQ0EsVUFDQSxhQUNBLHNCQUNBLGNBQ0EsYUFDQSx1QkFDQSw0QkFDQSxrQkFDQSxnQkFDQSxRQUNBLFFBQ0EsbUJBQ0UsWUFBWTtDQUNoQixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQThGLElBQUk7Q0FDbEksTUFBTSxXQUFXLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLFlBQVksS0FBSztDQUNwSCxNQUFNLHVCQUF1QixZQUFZO0VBQ3ZDLFlBQVksSUFBSTtFQUNoQixNQUFNLHNCQUFzQjtDQUM5QjtDQUNBLE1BQU0sY0FBYyxPQUFPLE9BQWU7RUFDeEMsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLGlCQUFpQixFQUFFO0dBQzFDLElBQUksVUFBVTtJQUNaLFlBQVk7S0FBRSxVQUFVLFNBQVM7S0FBVSxVQUFVLFNBQVM7S0FBVSxhQUFhLFNBQVM7SUFBWSxDQUFDO0dBQzdHO0VBQ0YsUUFBUTtHQUNOO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sa0JBQWtCLE9BQU8sVUFBa0IsZUFBMEI7RUFDekUsTUFBTSxxQkFBcUIsY0FBYyxVQUFVLFNBQVMsS0FBSyxZQUFZLFFBQVEsVUFBVSxLQUFLLENBQUM7RUFDckcsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxtQkFBbUIsTUFBTTtHQUMzQixpQkFBaUIsTUFBTSxzQkFBc0Isa0JBQWtCO0VBQ2pFLE9BQU87R0FDTCxNQUFNLG9CQUFvQixVQUFVLFNBQVMsS0FBSyxZQUFZLFFBQVEsVUFBVSxLQUFLLENBQUM7R0FDdEYsTUFBTSwyQkFBMkIsZ0JBQWdCLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLG1CQUFtQixHQUFHLGtCQUFrQixDQUFDLENBQUMsQ0FBQztFQUM5RztFQUNBLE1BQU0sU0FBUyxNQUFNLFlBQVksVUFBVSxvQkFBb0IsY0FBYztFQUM3RSxJQUFJLFFBQVEsY0FBYyxhQUFhLFlBQVksVUFBVTtHQUFFLEdBQUc7R0FBUyxhQUFhLE9BQU87RUFBYSxJQUFJLE9BQU87Q0FDekg7Q0FDQSxNQUFNLHFCQUFxQixPQUFPLFVBQWtCO0VBQ2xELE1BQU0sZ0JBQWdCLE1BQU0sWUFBWSxLQUFLO0VBQzdDLE1BQU0sa0JBQWtCLENBQUMsR0FBSSxVQUFVLFlBQVksQ0FBQyxHQUFJLEdBQUcsYUFBYTtFQUN4RSxJQUFJLHlCQUF5QixNQUFNO0dBQ2pDLE1BQU0sMkJBQTJCLHNCQUFzQixnQkFBZ0IsS0FBSyxZQUFZLFFBQVEsVUFBVSxDQUFDO0VBQzdHO0VBQ0EsYUFBYSxZQUFZLFVBQVU7R0FBRSxHQUFHO0dBQVMsVUFBVSxDQUFDLEdBQUcsUUFBUSxVQUFVLEdBQUcsYUFBYTtFQUFFLElBQUksT0FBTztFQUM5RyxNQUFNLGVBQWU7Q0FDdkI7Q0FDQSxNQUFNLGdCQUFnQixPQUFPLFVBQTRCLGFBQXFCO0VBQzVFLE1BQU0sYUFBYSxTQUFTLEtBQUssWUFBWSxRQUFRLFVBQVU7RUFDL0QsTUFBTSxpQkFBaUIseUJBQXlCLE9BQzVDLE1BQU0sc0JBQXNCLFVBQVUsSUFDdEM7RUFDSixJQUFJLHlCQUF5QixNQUFNLE1BQU0sMkJBQTJCLGdCQUFnQixVQUFVO0VBQzlGLFlBQVk7R0FBRTtHQUFVO0dBQVUsYUFBYTtFQUFLLENBQUM7RUFDckQsSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHO0VBQ3RCLE1BQU0sU0FBUyxNQUFNLFlBQVksVUFBVSxZQUFZLGNBQWM7RUFDckUsSUFBSSxRQUFRLGNBQWMsYUFBYSxZQUFZLFVBQVU7R0FBRSxHQUFHO0dBQVMsYUFBYSxPQUFPO0VBQWEsSUFBSSxPQUFPO0NBQ3pIO0NBQ0EsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsU0FBRDtHQUNZO0dBQ0k7R0FDTDtHQUNULFVBQVUsd0JBQXdCO0dBQ2xDLE9BQU87R0FDUCxlQUFlLEtBQUssZUFBZTtHQUNuQyxhQUFhLEtBQUsscUJBQXFCLENBQUMsQ0FBQyxZQUFZLFNBQVM7R0FDOUQsWUFBWSxPQUFPLEtBQUssWUFBWSxFQUFFO0dBQzFCO0dBQ0Y7R0FDVixVQUFVO0dBQ1Ysa0JBQWtCO0dBQ2xCLFVBQVU7RUFDWDs7OztZQUNELHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFELGFBQUssd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBbUI7SUFBc0I7Ozs7Y0FBQyx3QkFBQyxNQUFEO0tBQUssV0FBVyxzQkFBc0IsWUFBWTtLQUFXO0tBQUMsd0JBQUMsUUFBRCxZQUFPLFdBQVcsT0FBTyxLQUFXOzs7OztJQUFLOzs7O1lBQU07Ozs7Y0FDNUssd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBWSxTQUFTO2VBQXZDLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVcsb0JBQW9CLGVBQWUsMkJBQTJCO2dCQUFPLGVBQWUsd0JBQUMsT0FBRDtPQUFLLEtBQUs7T0FBYyxLQUFJO01BQW1COzs7O2lCQUFJO0tBQWU7Ozs7ZUFDdkssd0JBQUMsT0FBRCxZQUFLLHdCQUFDLFVBQUQsWUFBUyxTQUFpQjs7OztjQUFNOzs7O2FBQy9COzs7OztZQUNGOzs7OzthQUNSLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osV0FDRyx3QkFBQyxjQUFEO0tBQWMsVUFBVSxTQUFTO0tBQVUsZUFBZSxTQUFTO0tBQW9CO0tBQXVCO0tBQWEsYUFBYSxTQUFTO0tBQWEsUUFBUSxVQUFVLGVBQWUsS0FBSyxnQkFBZ0IsVUFBVSxVQUFVO0tBQUcsWUFBWTtJQUFxQjs7OztlQUM1USxnREFBRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQTRCLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7O2VBQUMsd0JBQUMsS0FBRCxZQUFHLHdDQUF3Qzs7OzthQUFNOzs7O2VBQUMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWE7S0FBOEI7Ozs7YUFBTTs7Ozs7Y0FBQyx3QkFBQyxhQUFELEVBQWEsWUFBWSxTQUFTLGFBQWEsS0FBSyxjQUFjLFNBQVMsUUFBUSxFQUFJOzs7O1lBQUc7Ozs7O0dBQzNROzs7O1dBQ0Q7Ozs7O1VBQ0g7Ozs7OztBQUVUOzs7OztBQUVBLFNBQVMsV0FBVzs7Q0FDbEIsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsUUFBUSxhQUFhLFFBQVEsY0FBYyxDQUFDLENBQUM7Q0FDMUYsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLGFBQWE7Q0FDdEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsYUFBYSxRQUFRLFlBQVksS0FBSyxFQUFFO0NBQ3pGLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBb0MsSUFBSTtDQUN4RSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyx1QkFBdUIsNEJBQTRCLFNBQXdCLElBQUk7Q0FFdEYsZ0JBQWdCO0VBQ2QsTUFBTSxrQkFBa0I7R0FDdEIsY0FBYyxLQUFLO0dBQ25CLGdCQUFnQixLQUFLO0dBQ3JCLGdCQUFnQixFQUFFO0VBQ3BCO0VBRUEsT0FBTyxpQkFBaUIsZ0JBQWdCLFNBQVM7RUFDakQsSUFBSSxhQUFhLFFBQVEsY0FBYyxHQUFHO0dBQ3hDLFdBQVcsQ0FBQyxDQUNULE1BQU0sWUFBWTtJQUNqQixZQUFZLFFBQVEsSUFBSTtJQUN4QixnQkFBZ0IsUUFBUSxpQkFBaUIsRUFBRTtHQUM3QyxDQUFDLENBQUMsQ0FDRCxNQUFNLFNBQVM7RUFDcEI7RUFDQSxhQUFhLE9BQU8sb0JBQW9CLGdCQUFnQixTQUFTO0NBQ25FLEdBQUcsQ0FBQyxDQUFDO0NBRUwsZ0JBQWdCO0VBQ2QsSUFBSSxjQUFjLGFBQWEsUUFBUSxjQUFjLFlBQVk7T0FDNUQsYUFBYSxXQUFXLFlBQVk7Q0FDM0MsR0FBRyxDQUFDLFlBQVksQ0FBQztDQUVqQixNQUFNLGFBQWEsT0FBTyxNQUFjLE9BQWUsYUFBcUI7RUFDMUUsSUFBSTtHQUNGLElBQUksYUFBYSxVQUFVO0lBQ3pCLE9BQU8sTUFBTSxPQUFPO0tBQUUsTUFBTSxLQUFLLEtBQUs7S0FBRztLQUFPO0lBQVMsQ0FBQztHQUM1RDtHQUNBLE1BQU0sTUFBTTtJQUFFO0lBQU87R0FBUyxDQUFDO0dBQy9CLE1BQU0sVUFBVSxNQUFNLFdBQVc7R0FDakMsWUFBWSxRQUFRLElBQUk7R0FDeEIsZ0JBQWdCLFFBQVEsaUJBQWlCLEVBQUU7R0FDM0MsY0FBYyxJQUFJO0dBQ2xCLFlBQVksSUFBSTtFQUNsQixTQUFTLE9BQU87R0FDZCxNQUFNLElBQUksTUFBTSxZQUFZLEtBQUssQ0FBQztFQUNwQztDQUNGO0NBRUEsTUFBTSxVQUFVLFlBQVk7RUFDMUIsTUFBTSxPQUFPO0VBQ2IsY0FBYyxLQUFLO0VBQ25CLGdCQUFnQixLQUFLO0VBQ3JCLGdCQUFnQixFQUFFO0NBQ3BCO0NBRUEsSUFBSSxjQUFjLGNBQWM7RUFDOUIsT0FDRSx3QkFBQyxjQUFEO0dBQ0UsYUFBYTtHQUNDO0dBQ2QsY0FBYyxnQkFBZ0IsS0FBSztHQUNuQyxhQUFhLFNBQVM7SUFDcEIsWUFBWSxJQUFJO0lBQ2hCLGdCQUFnQixLQUFLO0dBQ3ZCO0dBQ0EsYUFBYTtHQUNiLG1CQUFtQix3QkFBd0I7SUFDekMsY0FBYyxLQUFLO0lBQ25CLGdCQUFnQixLQUFLO0lBQ3JCLFlBQVksYUFBYTtJQUN6QixnQkFBZ0IsRUFBRTtJQUNsQix5QkFBeUIsbUJBQW1CO0dBQzlDO0VBQ0Q7Ozs7O0NBRUw7Q0FFQSxJQUFJLFlBQVk7RUFDZCxPQUFPLHdCQUFDLFNBQUQ7R0FBbUI7R0FBd0I7R0FBYyxrQkFBa0IsZ0JBQWdCLElBQUk7R0FBRyxVQUFVO0VBQVU7Ozs7O0NBQy9IO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyx3QkFBQyxVQUFEO0dBQ0wsTUFBTTtHQUNOLGNBQWMsWUFBWSxJQUFJO0dBQzlCLFVBQVU7R0FDVixlQUFlLE9BQU8sT0FBTyxTQUFTO0lBQ3BDLE1BQU0sWUFBWTtLQUFFO0tBQU87SUFBSyxDQUFDO0lBQ2pDLE1BQU0sVUFBVSxNQUFNLFdBQVc7SUFDakMsWUFBWSxRQUFRLElBQUk7SUFDeEIsZ0JBQWdCLFFBQVEsaUJBQWlCLEVBQUU7SUFDM0MsY0FBYyxJQUFJO0lBQ2xCLFlBQVksSUFBSTtHQUNsQjtHQUNBLGNBQWM7R0FDZCxrQkFBa0I7R0FDbEIsaUJBQWlCLE9BQU8sT0FBTyxNQUFNLGFBQWE7SUFBRSxNQUFNLGNBQWM7S0FBRTtLQUFPO0tBQU0sY0FBYztJQUFTLENBQUM7R0FBRTtHQUNqSCxVQUFVO0VBQ1g7Ozs7O0NBQ0g7Q0FDQSxPQUNFLGdEQUNFLHdCQUFDLFNBQUQsRUFBUyxRQUFRLFlBQWM7Ozs7V0FDOUIsMEJBQTBCLFFBQ3pCLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsV0FBRDtHQUFTLFdBQVU7R0FBZ0IsTUFBSztHQUFTLGNBQVc7R0FBTyxtQkFBZ0I7YUFBbkY7SUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFxQix3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztJQUFPOzs7OztJQUNyRSx3QkFBQyxNQUFEO0tBQUksSUFBRztlQUF3QjtJQUFtQjs7Ozs7SUFDbEQsd0JBQUMsS0FBRCxhQUFHLDRFQUVBLHdCQUF3QixLQUFLLElBQUksc0JBQXNCLDhEQUN2RDs7Ozs7SUFDSCx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFpQixlQUFlLHlCQUF5QixJQUFJO2VBQUc7SUFBMEI7Ozs7O0dBQ3JHOzs7Ozs7Q0FDTjs7OztTQUVQOzs7OztBQUVOOzs7QUFFQSxlQUFlLFNBQVMsTUFBTTtDQUM1QixNQUFNLGFBQWEsT0FBTyxTQUFTLFNBQVMsTUFBTSxvQkFBb0IsQ0FBQyxHQUFHO0NBQzFFLElBQUksWUFBWSxPQUFPLHdCQUFDLHNCQUFELEVBQXNCLE9BQU8sbUJBQW1CLFVBQVUsRUFBSTs7Ozs7Q0FDckYsT0FBTyx3QkFBQyxVQUFELENBQVc7Ozs7O0FBQ3BCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJyb3dSaWdodCwgQmFyQ2hhcnQzLCBDaGVjaywgQ2hlY2tDaXJjbGUyLCBDaGV2cm9uUmlnaHQsIERhdGFiYXNlLCBGaWxlQ2hhcnRDb2x1bW4sIExvY2tLZXlob2xlLCBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBBdXRoUGFnZSB9IGZyb20gJy4vY29tcG9uZW50cy9BdXRoUGFnZSdcclxuaW1wb3J0IHsgQW5hbHlzaXNCYXIgfSBmcm9tICcuL2NvbXBvbmVudHMvQW5hbHlzaXNCYXInXHJcbmltcG9ydCB7IEFuYWx5c2lzUGFnZSB9IGZyb20gJy4vY29tcG9uZW50cy9BbmFseXNpc1BhZ2UnXHJcbmltcG9ydCB7IFNldHRpbmdzUGFnZSB9IGZyb20gJy4vY29tcG9uZW50cy9TZXR0aW5nc1BhZ2UnXHJcbmltcG9ydCB7IFNpZGViYXIgfSBmcm9tICcuL2NvbXBvbmVudHMvU2lkZWJhcidcclxuaW1wb3J0IHsgUHVibGljU2hhcmVkQW5hbHlzaXMgfSBmcm9tICcuL2NvbXBvbmVudHMvUHVibGljU2hhcmVkQW5hbHlzaXMnXHJcbmltcG9ydCB7IHVzZURlbW9EYXRhIH0gZnJvbSAnLi9ob29rcy91c2VEZW1vRGF0YSdcclxuaW1wb3J0IHsgZ2V0QXBpRXJyb3IgfSBmcm9tICcuL3NlcnZpY2VzL2FwaSdcclxuaW1wb3J0IHsgZ2V0UHJvZmlsZSwgbG9naW4sIGxvZ291dCwgcmVxdWVzdFBhc3N3b3JkUmVzZXQsIHJlc2VuZFZlcmlmaWNhdGlvbkNvZGUsIHJlc2V0UGFzc3dvcmQsIHNpZ251cCwgdmVyaWZ5RW1haWwgfSBmcm9tICcuL3NlcnZpY2VzL2F1dGhTZXJ2aWNlJ1xyXG5pbXBvcnQgeyB1cGxvYWRGaWxlcywgdHlwZSBEYXRhc2V0UHJldmlldyB9IGZyb20gJy4vc2VydmljZXMvZmlsZVNlcnZpY2UnXHJcblxyXG5mdW5jdGlvbiBMYW5kaW5nKHsgb25BdXRoIH06IHsgb25BdXRoOiAodHlwZTogJ3NpZ251cCcgfCAnbG9naW4nKSA9PiB2b2lkIH0pIHtcclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nXCI+PGhlYWRlciBjbGFzc05hbWU9XCJsYW5kaW5nLWhlYWRlclwiPjxkaXYgY2xhc3NOYW1lPVwiYnJhbmRcIj48c3BhbiBjbGFzc05hbWU9XCJicmFuZC1tYXJrXCI+PEJhckNoYXJ0MyBzaXplPXsxOH0gLz48L3NwYW4+PHNwYW4+QUkgRGF0YSA8Yj5BbmFseXN0PC9iPjwvc3Bhbj48L2Rpdj48bmF2PjxidXR0b24gY2xhc3NOYW1lPVwibmF2LWxvZ2luXCIgb25DbGljaz17KCkgPT4gb25BdXRoKCdsb2dpbicpfT5Mb2cgSW48L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cIm5hdi1zaWdudXBcIiBvbkNsaWNrPXsoKSA9PiBvbkF1dGgoJ3NpZ251cCcpfT5TaWduIFVwIDxBcnJvd1JpZ2h0IHNpemU9ezE1fSAvPjwvYnV0dG9uPjwvbmF2PjwvaGVhZGVyPjxtYWluIGNsYXNzTmFtZT1cImhlcm9cIj48ZGl2IGNsYXNzTmFtZT1cImhlcm8tY29weVwiPjxkaXYgY2xhc3NOYW1lPVwiZXllYnJvd1wiPjxzcGFuIGNsYXNzTmFtZT1cImV5ZWJyb3ctbGluZVwiIC8+IEFOQUxZU0VaIEFWRUMgQ0xBUlTDiTwvZGl2PjxoMT5Wb3MgZG9ubsOpZXMuPGJyIC8+PGVtPkRlcyByw6lwb25zZXM8L2VtPjxiciAvPnF1aSBjb21wdGVudC48L2gxPjxwPkltcG9ydGV6IHZvcyBkb25uw6llcywgcG9zZXogdm9zIHF1ZXN0aW9ucywgb2J0ZW5leiBkZXMgYW5hbHlzZXMgaW5zdGFudGFuw6llcyBncsOiY2Ugw6AgbOKAmUlBLjwvcD48ZGl2IGNsYXNzTmFtZT1cInRydXN0LWxpbmVcIj48c3Bhbj48Q2hlY2sgc2l6ZT17MTR9IC8+IFNhbnMgY2FydGUgYmFuY2FpcmU8L3NwYW4+PHNwYW4+PExvY2tLZXlob2xlIHNpemU9ezE0fSAvPiBEb25uw6llcyBzw6ljdXJpc8OpZXM8L3NwYW4+PC9kaXY+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJoZXJvLXZpc3VhbFwiPjxkaXYgY2xhc3NOYW1lPVwidmlzdWFsLWdyaWRcIiAvPjxkaXYgY2xhc3NOYW1lPVwiZmxvYXRpbmctY2FyZCBjYXJkLW1haW5cIj48ZGl2IGNsYXNzTmFtZT1cImNhcmQtbGFiZWxcIj48c3BhbiBjbGFzc05hbWU9XCJsaXZlLWRvdFwiIC8+IEFOQUxZU0UgRU4gQ09VUlM8L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInZpc3VhbC10aXRsZVwiPlBlcmZvcm1hbmNlPGJyIC8+PGI+w6l0dWRpYW50czwvYj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cIm1pbmktY2hhcnRcIj48c3BhbiBzdHlsZT17eyBoZWlnaHQ6ICczNCUnIH19IC8+PHNwYW4gc3R5bGU9e3sgaGVpZ2h0OiAnNDglJyB9fSAvPjxzcGFuIHN0eWxlPXt7IGhlaWdodDogJzQzJScgfX0gLz48c3BhbiBzdHlsZT17eyBoZWlnaHQ6ICc2OCUnIH19IC8+PHNwYW4gc3R5bGU9e3sgaGVpZ2h0OiAnNTglJyB9fSAvPjxzcGFuIHN0eWxlPXt7IGhlaWdodDogJzg2JScgfX0gLz48c3BhbiBzdHlsZT17eyBoZWlnaHQ6ICc3NiUnIH19IC8+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJjaGFydC1jYXB0aW9uXCI+PHNwYW4+SmFuPC9zcGFuPjxzcGFuPkp1aWw8L3NwYW4+PHN0cm9uZz4rMjQuOCU8L3N0cm9uZz48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImZsb2F0aW5nLWNhcmQgY2FyZC1zdGF0XCI+PHNwYW4gY2xhc3NOYW1lPVwic3RhdC1pY29uXCI+PFNwYXJrbGVzIHNpemU9ezE1fSAvPjwvc3Bhbj48c3Ryb25nPjEsMjA0PC9zdHJvbmc+PHNtYWxsPmxpZ25lcyBhbmFseXPDqWVzPC9zbWFsbD48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImZsb2F0aW5nLWNhcmQgY2FyZC1xdWVzdGlvblwiPjxzcGFuIGNsYXNzTmFtZT1cInF1ZXN0aW9uLW1hcmtcIj4/PC9zcGFuPjxzcGFuPlBvdXJxdW9pIGNlIHBpYzxiciAvPmVuIGp1aW4gPzwvc3Bhbj48Q2hldnJvblJpZ2h0IHNpemU9ezE0fSAvPjwvZGl2PjwvZGl2PjwvbWFpbj48c2VjdGlvbiBjbGFzc05hbWU9XCJsYW5kaW5nLWJvdHRvbVwiPjxkaXY+PERhdGFiYXNlIHNpemU9ezE4fSAvPjxzcGFuPjxiPlVuIGVzcGFjZSB1bmlxdWU8L2I+IHBvdXIgY29tcHJlbmRyZSB2b3MgZG9ubsOpZXM8L3NwYW4+PC9kaXY+PGRpdj48RmlsZUNoYXJ0Q29sdW1uIHNpemU9ezE4fSAvPjxzcGFuPjxiPkRlcyByw6lwb25zZXMgdmlzdWVsbGVzPC9iPiBlbiBxdWVscXVlcyBzZWNvbmRlczwvc3Bhbj48L2Rpdj48ZGl2PjxCYXJDaGFydDMgc2l6ZT17MTh9IC8+PHNwYW4+PGI+RGVzIGTDqWNpc2lvbnMgw6ljbGFpcsOpZXM8L2I+IHBhciBkZXMgZmFpdHM8L3NwYW4+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PlxyXG59XHJcblxyXG5mdW5jdGlvbiBBbmFseXN0KHsgdXNlck5hbWUsIHByb2ZpbGVQaG90bywgb25TZXR0aW5ncywgb25Mb2dvdXQgfTogeyB1c2VyTmFtZTogc3RyaW5nOyBwcm9maWxlUGhvdG86IHN0cmluZzsgb25TZXR0aW5nczogKCkgPT4gdm9pZDsgb25Mb2dvdXQ6ICgpID0+IHZvaWQgfSkge1xyXG4gIGNvbnN0IHtcclxuICAgIGhpc3RvcnksXHJcbiAgICBtZXNzYWdlcyxcclxuICAgIGlzQW5hbHl6aW5nLFxyXG4gICAgYWN0aXZlQ29udmVyc2F0aW9uSWQsXHJcbiAgICBoaXN0b3J5RXJyb3IsXHJcbiAgICBhc2tRdWVzdGlvbixcclxuICAgIGNyZWF0ZU5ld0NvbnZlcnNhdGlvbixcclxuICAgIHVwZGF0ZUNvbnZlcnNhdGlvbkRhdGFzZXRzLFxyXG4gICAgbG9hZEhpc3RvcnlFbnRyeSxcclxuICAgIHJlZnJlc2hIaXN0b3J5LFxyXG4gICAgcmVtb3ZlLFxyXG4gICAgcmVuYW1lLFxyXG4gICAgdG9nZ2xlRmF2b3JpdGUsXHJcbiAgfSA9IHVzZURlbW9EYXRhKClcclxuICBjb25zdCBbYW5hbHlzaXMsIHNldEFuYWx5c2lzXSA9IHVzZVN0YXRlPHsgZGF0YXNldHM6IERhdGFzZXRQcmV2aWV3W107IHF1ZXN0aW9uOiBzdHJpbmc7IGNoYXJ0Q29uZmlnOiBzdHJpbmcgfCBudWxsIH0gfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IGluaXRpYWxzID0gdXNlck5hbWUuc3BsaXQoL1xccysvKS5maWx0ZXIoQm9vbGVhbikuc2xpY2UoMCwgMikubWFwKChwYXJ0KSA9PiBwYXJ0WzBdKS5qb2luKCcnKS50b1VwcGVyQ2FzZSgpIHx8ICdVJ1xyXG4gIGNvbnN0IHN0YXJ0TmV3Q29udmVyc2F0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0QW5hbHlzaXMobnVsbClcclxuICAgIGF3YWl0IGNyZWF0ZU5ld0NvbnZlcnNhdGlvbigpXHJcbiAgfVxyXG4gIGNvbnN0IG9wZW5IaXN0b3J5ID0gYXN5bmMgKGlkOiBudW1iZXIpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkID0gYXdhaXQgbG9hZEhpc3RvcnlFbnRyeShpZClcclxuICAgICAgaWYgKHNlbGVjdGVkKSB7XHJcbiAgICAgICAgc2V0QW5hbHlzaXMoeyBkYXRhc2V0czogc2VsZWN0ZWQuZGF0YXNldHMsIHF1ZXN0aW9uOiBzZWxlY3RlZC5xdWVzdGlvbiwgY2hhcnRDb25maWc6IHNlbGVjdGVkLmNoYXJ0Q29uZmlnIH0pXHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuICB9XHJcbiAgY29uc3QgYXNrRnJvbUFuYWx5c2lzID0gYXN5bmMgKHF1ZXN0aW9uOiBzdHJpbmcsIGRhdGFzZXRJZHM/OiBudW1iZXJbXSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWREYXRhc2V0SWRzID0gZGF0YXNldElkcyA/PyBhbmFseXNpcz8uZGF0YXNldHMubWFwKChkYXRhc2V0KSA9PiBkYXRhc2V0LmRhdGFzZXRfaWQpID8/IFtdXHJcbiAgICBsZXQgY29udmVyc2F0aW9uSWQgPSBhY3RpdmVDb252ZXJzYXRpb25JZFxyXG4gICAgaWYgKGNvbnZlcnNhdGlvbklkID09PSBudWxsKSB7XHJcbiAgICAgIGNvbnZlcnNhdGlvbklkID0gYXdhaXQgY3JlYXRlTmV3Q29udmVyc2F0aW9uKHNlbGVjdGVkRGF0YXNldElkcylcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnREYXRhc2V0SWRzID0gYW5hbHlzaXM/LmRhdGFzZXRzLm1hcCgoZGF0YXNldCkgPT4gZGF0YXNldC5kYXRhc2V0X2lkKSA/PyBbXVxyXG4gICAgICBhd2FpdCB1cGRhdGVDb252ZXJzYXRpb25EYXRhc2V0cyhjb252ZXJzYXRpb25JZCwgWy4uLm5ldyBTZXQoWy4uLmN1cnJlbnREYXRhc2V0SWRzLCAuLi5zZWxlY3RlZERhdGFzZXRJZHNdKV0pXHJcbiAgICB9XHJcbiAgICBjb25zdCBhbnN3ZXIgPSBhd2FpdCBhc2tRdWVzdGlvbihxdWVzdGlvbiwgc2VsZWN0ZWREYXRhc2V0SWRzLCBjb252ZXJzYXRpb25JZClcclxuICAgIGlmIChhbnN3ZXI/LmNoYXJ0X2NvbmZpZykgc2V0QW5hbHlzaXMoKGN1cnJlbnQpID0+IGN1cnJlbnQgPyB7IC4uLmN1cnJlbnQsIGNoYXJ0Q29uZmlnOiBhbnN3ZXIuY2hhcnRfY29uZmlnIH0gOiBjdXJyZW50KVxyXG4gIH1cclxuICBjb25zdCBhZGRGaWxlc1RvQW5hbHlzaXMgPSBhc3luYyAoZmlsZXM6IEZpbGVbXSkgPT4ge1xyXG4gICAgY29uc3QgYWRkZWREYXRhc2V0cyA9IGF3YWl0IHVwbG9hZEZpbGVzKGZpbGVzKVxyXG4gICAgY29uc3QgdXBkYXRlZERhdGFzZXRzID0gWy4uLihhbmFseXNpcz8uZGF0YXNldHMgPz8gW10pLCAuLi5hZGRlZERhdGFzZXRzXVxyXG4gICAgaWYgKGFjdGl2ZUNvbnZlcnNhdGlvbklkICE9PSBudWxsKSB7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZUNvbnZlcnNhdGlvbkRhdGFzZXRzKGFjdGl2ZUNvbnZlcnNhdGlvbklkLCB1cGRhdGVkRGF0YXNldHMubWFwKChkYXRhc2V0KSA9PiBkYXRhc2V0LmRhdGFzZXRfaWQpKVxyXG4gICAgfVxyXG4gICAgc2V0QW5hbHlzaXMoKGN1cnJlbnQpID0+IGN1cnJlbnQgPyB7IC4uLmN1cnJlbnQsIGRhdGFzZXRzOiBbLi4uY3VycmVudC5kYXRhc2V0cywgLi4uYWRkZWREYXRhc2V0c10gfSA6IGN1cnJlbnQpXHJcbiAgICBhd2FpdCByZWZyZXNoSGlzdG9yeSgpXHJcbiAgfVxyXG4gIGNvbnN0IHN0YXJ0QW5hbHlzaXMgPSBhc3luYyAoZGF0YXNldHM6IERhdGFzZXRQcmV2aWV3W10sIHF1ZXN0aW9uOiBzdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IGRhdGFzZXRJZHMgPSBkYXRhc2V0cy5tYXAoKGRhdGFzZXQpID0+IGRhdGFzZXQuZGF0YXNldF9pZClcclxuICAgIGNvbnN0IGNvbnZlcnNhdGlvbklkID0gYWN0aXZlQ29udmVyc2F0aW9uSWQgPT09IG51bGxcclxuICAgICAgPyBhd2FpdCBjcmVhdGVOZXdDb252ZXJzYXRpb24oZGF0YXNldElkcylcclxuICAgICAgOiBhY3RpdmVDb252ZXJzYXRpb25JZFxyXG4gICAgaWYgKGFjdGl2ZUNvbnZlcnNhdGlvbklkICE9PSBudWxsKSBhd2FpdCB1cGRhdGVDb252ZXJzYXRpb25EYXRhc2V0cyhjb252ZXJzYXRpb25JZCwgZGF0YXNldElkcylcclxuICAgIHNldEFuYWx5c2lzKHsgZGF0YXNldHMsIHF1ZXN0aW9uLCBjaGFydENvbmZpZzogbnVsbCB9KVxyXG4gICAgaWYgKCFxdWVzdGlvbi50cmltKCkpIHJldHVyblxyXG4gICAgY29uc3QgYW5zd2VyID0gYXdhaXQgYXNrUXVlc3Rpb24ocXVlc3Rpb24sIGRhdGFzZXRJZHMsIGNvbnZlcnNhdGlvbklkKVxyXG4gICAgaWYgKGFuc3dlcj8uY2hhcnRfY29uZmlnKSBzZXRBbmFseXNpcygoY3VycmVudCkgPT4gY3VycmVudCA/IHsgLi4uY3VycmVudCwgY2hhcnRDb25maWc6IGFuc3dlci5jaGFydF9jb25maWcgfSA6IGN1cnJlbnQpXHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1zaGVsbFwiPlxyXG4gICAgICA8U2lkZWJhclxyXG4gICAgICAgIHVzZXJOYW1lPXt1c2VyTmFtZX1cclxuICAgICAgICBwcm9maWxlUGhvdG89e3Byb2ZpbGVQaG90b31cclxuICAgICAgICBoaXN0b3J5PXtoaXN0b3J5fVxyXG4gICAgICAgIGFjdGl2ZUlkPXthY3RpdmVDb252ZXJzYXRpb25JZCA/PyAwfVxyXG4gICAgICAgIGVycm9yPXtoaXN0b3J5RXJyb3J9XHJcbiAgICAgICAgb25SZXRyeT17KCkgPT4gdm9pZCByZWZyZXNoSGlzdG9yeSgpfVxyXG4gICAgICAgIG9uTmV3PXsoKSA9PiB2b2lkIHN0YXJ0TmV3Q29udmVyc2F0aW9uKCkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKX1cclxuICAgICAgICBvbkhpc3Rvcnk9eyhpZCkgPT4gdm9pZCBvcGVuSGlzdG9yeShpZCl9XHJcbiAgICAgICAgb25TZXR0aW5ncz17b25TZXR0aW5nc31cclxuICAgICAgICBvbkxvZ291dD17b25Mb2dvdXR9XHJcbiAgICAgICAgb25SZW5hbWU9e3JlbmFtZX1cclxuICAgICAgICBvblRvZ2dsZUZhdm9yaXRlPXt0b2dnbGVGYXZvcml0ZX1cclxuICAgICAgICBvblJlbW92ZT17cmVtb3ZlfVxyXG4gICAgICAvPlxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJ3b3Jrc3BhY2VcIj5cclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cIndvcmtzcGFjZS1oZWFkZXJcIj5cclxuICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwid29ya3NwYWNlLWtpY2tlclwiPkVTUEFDRSBE4oCZQU5BTFlTRTwvc3Bhbj48aDE+e2FuYWx5c2lzID8gJ0FuYWx5c2UgZMOpdGFpbGzDqWUnIDogYEJvbmpvdXIsICR7dXNlck5hbWV9YH0gPHNwYW4+e2FuYWx5c2lzID8gJ/Cfk4onIDogJ/CfkYsnfTwvc3Bhbj48L2gxPjwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ1c2VyLWNoaXBcIiBvbkNsaWNrPXtvblNldHRpbmdzfT5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdXNlci1jaGlwLWF2YXRhciAke3Byb2ZpbGVQaG90byA/ICd1c2VyLWNoaXAtYXZhdGFyLWltYWdlJyA6ICcnfWB9Pntwcm9maWxlUGhvdG8gPyA8aW1nIHNyYz17cHJvZmlsZVBob3RvfSBhbHQ9XCJQaG90byBkZSBwcm9maWxcIiAvPiA6IGluaXRpYWxzfTwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdj48c3Ryb25nPnt1c2VyTmFtZX08L3N0cm9uZz48L2Rpdj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid29ya3NwYWNlLWNvbnRlbnRcIj5cclxuICAgICAgICAgIHthbmFseXNpc1xyXG4gICAgICAgICAgICA/IDxBbmFseXNpc1BhZ2UgZGF0YXNldHM9e2FuYWx5c2lzLmRhdGFzZXRzfSBmaXJzdFF1ZXN0aW9uPXthbmFseXNpcy5xdWVzdGlvbn0gbWVzc2FnZXM9e21lc3NhZ2VzfSBpc0FuYWx5emluZz17aXNBbmFseXppbmd9IGNoYXJ0Q29uZmlnPXthbmFseXNpcy5jaGFydENvbmZpZ30gb25Bc2s9eyhxdWVzdGlvbiwgZGF0YXNldElkcykgPT4gdm9pZCBhc2tGcm9tQW5hbHlzaXMocXVlc3Rpb24sIGRhdGFzZXRJZHMpfSBvbkFkZEZpbGVzPXthZGRGaWxlc1RvQW5hbHlzaXN9IC8+XHJcbiAgICAgICAgICAgIDogPD48ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaW50cm9cIj48ZGl2PjxoMj5Ob3V2ZWxsZSBhbmFseXNlPC9oMj48cD5UcmFuc2Zvcm1leiB1bmUgcXVlc3Rpb24gZW4gZMOpY2lzaW9uLjwvcD48L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJ1c2FnZS1waWxsXCI+MTIgLyA1MCBhbmFseXNlcyBjZSBtb2lzPC9zcGFuPjwvZGl2PjxBbmFseXNpc0JhciBvbkFuYWx5emU9eyhkYXRhc2V0LCBxdWVzdGlvbikgPT4gdm9pZCBzdGFydEFuYWx5c2lzKGRhdGFzZXQsIHF1ZXN0aW9uKX0gLz48Lz59XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gQXBwU2hlbGwoKSB7XHJcbiAgY29uc3QgW2lzTG9nZ2VkSW4sIHNldElzTG9nZ2VkSW5dID0gdXNlU3RhdGUoQm9vbGVhbihsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYWNjZXNzX3Rva2VuJykpKVxyXG4gIGNvbnN0IFt1c2VyTmFtZSwgc2V0VXNlck5hbWVdID0gdXNlU3RhdGUoJ1V0aWxpc2F0ZXVyJylcclxuICBjb25zdCBbcHJvZmlsZVBob3RvLCBzZXRQcm9maWxlUGhvdG9dID0gdXNlU3RhdGUobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzZXJfcGhvdG8nKSB8fCAnJylcclxuICBjb25zdCBbYXV0aFBhZ2UsIHNldEF1dGhQYWdlXSA9IHVzZVN0YXRlPCdzaWdudXAnIHwgJ2xvZ2luJyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW3NldHRpbmdzUGFnZSwgc2V0U2V0dGluZ3NQYWdlXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFthY2NvdW50RGVsZXRpb25Ob3RpY2UsIHNldEFjY291bnREZWxldGlvbk5vdGljZV0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3Qgb25FeHBpcmVkID0gKCkgPT4ge1xyXG4gICAgICBzZXRJc0xvZ2dlZEluKGZhbHNlKVxyXG4gICAgICBzZXRTZXR0aW5nc1BhZ2UoZmFsc2UpXHJcbiAgICAgIHNldFByb2ZpbGVQaG90bygnJylcclxuICAgIH1cclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYXV0aDpleHBpcmVkJywgb25FeHBpcmVkKVxyXG4gICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhY2Nlc3NfdG9rZW4nKSkge1xyXG4gICAgICBnZXRQcm9maWxlKClcclxuICAgICAgICAudGhlbigocHJvZmlsZSkgPT4ge1xyXG4gICAgICAgICAgc2V0VXNlck5hbWUocHJvZmlsZS5uYW1lKVxyXG4gICAgICAgICAgc2V0UHJvZmlsZVBob3RvKHByb2ZpbGUucHJvZmlsZV9waG90byB8fCAnJylcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5jYXRjaChvbkV4cGlyZWQpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2F1dGg6ZXhwaXJlZCcsIG9uRXhwaXJlZClcclxuICB9LCBbXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChwcm9maWxlUGhvdG8pIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd1c2VyX3Bob3RvJywgcHJvZmlsZVBob3RvKVxyXG4gICAgZWxzZSBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcl9waG90bycpXHJcbiAgfSwgW3Byb2ZpbGVQaG90b10pXHJcblxyXG4gIGNvbnN0IHN1Ym1pdEF1dGggPSBhc3luYyAobmFtZTogc3RyaW5nLCBlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoYXV0aFBhZ2UgPT09ICdzaWdudXAnKSB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHNpZ251cCh7IG5hbWU6IG5hbWUudHJpbSgpLCBlbWFpbCwgcGFzc3dvcmQgfSlcclxuICAgICAgfVxyXG4gICAgICBhd2FpdCBsb2dpbih7IGVtYWlsLCBwYXNzd29yZCB9KVxyXG4gICAgICBjb25zdCBwcm9maWxlID0gYXdhaXQgZ2V0UHJvZmlsZSgpXHJcbiAgICAgIHNldFVzZXJOYW1lKHByb2ZpbGUubmFtZSlcclxuICAgICAgc2V0UHJvZmlsZVBob3RvKHByb2ZpbGUucHJvZmlsZV9waG90byB8fCAnJylcclxuICAgICAgc2V0SXNMb2dnZWRJbih0cnVlKVxyXG4gICAgICBzZXRBdXRoUGFnZShudWxsKVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKGdldEFwaUVycm9yKGVycm9yKSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IHNpZ25PdXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCBsb2dvdXQoKVxyXG4gICAgc2V0SXNMb2dnZWRJbihmYWxzZSlcclxuICAgIHNldFNldHRpbmdzUGFnZShmYWxzZSlcclxuICAgIHNldFByb2ZpbGVQaG90bygnJylcclxuICB9XHJcblxyXG4gIGlmIChpc0xvZ2dlZEluICYmIHNldHRpbmdzUGFnZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPFNldHRpbmdzUGFnZVxyXG4gICAgICAgIGluaXRpYWxOYW1lPXt1c2VyTmFtZX1cclxuICAgICAgICBwcm9maWxlUGhvdG89e3Byb2ZpbGVQaG90b31cclxuICAgICAgICBvbkJhY2s9eygpID0+IHNldFNldHRpbmdzUGFnZShmYWxzZSl9XHJcbiAgICAgICAgb25TYXZlTmFtZT17KG5hbWUpID0+IHtcclxuICAgICAgICAgIHNldFVzZXJOYW1lKG5hbWUpXHJcbiAgICAgICAgICBzZXRTZXR0aW5nc1BhZ2UoZmFsc2UpXHJcbiAgICAgICAgfX1cclxuICAgICAgICBvblNhdmVQaG90bz17c2V0UHJvZmlsZVBob3RvfVxyXG4gICAgICAgIG9uQWNjb3VudERlbGV0ZWQ9eyhmaWxlc0NsZWFudXBQZW5kaW5nKSA9PiB7XHJcbiAgICAgICAgICBzZXRJc0xvZ2dlZEluKGZhbHNlKVxyXG4gICAgICAgICAgc2V0U2V0dGluZ3NQYWdlKGZhbHNlKVxyXG4gICAgICAgICAgc2V0VXNlck5hbWUoJ1V0aWxpc2F0ZXVyJylcclxuICAgICAgICAgIHNldFByb2ZpbGVQaG90bygnJylcclxuICAgICAgICAgIHNldEFjY291bnREZWxldGlvbk5vdGljZShmaWxlc0NsZWFudXBQZW5kaW5nKVxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBpZiAoaXNMb2dnZWRJbikge1xyXG4gICAgcmV0dXJuIDxBbmFseXN0IHVzZXJOYW1lPXt1c2VyTmFtZX0gcHJvZmlsZVBob3RvPXtwcm9maWxlUGhvdG99IG9uU2V0dGluZ3M9eygpID0+IHNldFNldHRpbmdzUGFnZSh0cnVlKX0gb25Mb2dvdXQ9e3NpZ25PdXR9IC8+XHJcbiAgfVxyXG4gIGlmIChhdXRoUGFnZSkge1xyXG4gICAgcmV0dXJuIDxBdXRoUGFnZVxyXG4gICAgICB0eXBlPXthdXRoUGFnZX1cclxuICAgICAgb25CYWNrPXsoKSA9PiBzZXRBdXRoUGFnZShudWxsKX1cclxuICAgICAgb25TdWJtaXQ9e3N1Ym1pdEF1dGh9XHJcbiAgICAgIG9uVmVyaWZ5RW1haWw9e2FzeW5jIChlbWFpbCwgY29kZSkgPT4ge1xyXG4gICAgICAgIGF3YWl0IHZlcmlmeUVtYWlsKHsgZW1haWwsIGNvZGUgfSlcclxuICAgICAgICBjb25zdCBwcm9maWxlID0gYXdhaXQgZ2V0UHJvZmlsZSgpXHJcbiAgICAgICAgc2V0VXNlck5hbWUocHJvZmlsZS5uYW1lKVxyXG4gICAgICAgIHNldFByb2ZpbGVQaG90byhwcm9maWxlLnByb2ZpbGVfcGhvdG8gfHwgJycpXHJcbiAgICAgICAgc2V0SXNMb2dnZWRJbih0cnVlKVxyXG4gICAgICAgIHNldEF1dGhQYWdlKG51bGwpXHJcbiAgICAgIH19XHJcbiAgICAgIG9uUmVzZW5kQ29kZT17cmVzZW5kVmVyaWZpY2F0aW9uQ29kZX1cclxuICAgICAgb25Gb3Jnb3RQYXNzd29yZD17cmVxdWVzdFBhc3N3b3JkUmVzZXR9XHJcbiAgICAgIG9uUmVzZXRQYXNzd29yZD17YXN5bmMgKGVtYWlsLCBjb2RlLCBwYXNzd29yZCkgPT4geyBhd2FpdCByZXNldFBhc3N3b3JkKHsgZW1haWwsIGNvZGUsIG5ld19wYXNzd29yZDogcGFzc3dvcmQgfSkgfX1cclxuICAgICAgb25Td2l0Y2g9e3NldEF1dGhQYWdlfVxyXG4gICAgLz5cclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxMYW5kaW5nIG9uQXV0aD17c2V0QXV0aFBhZ2V9IC8+XHJcbiAgICAgIHthY2NvdW50RGVsZXRpb25Ob3RpY2UgIT09IG51bGwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VjY2Vzcy1tb2RhbC1iYWNrZHJvcFwiPlxyXG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3VjY2Vzcy1tb2RhbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWxsZWRieT1cImFjY291bnQtZGVsZXRlZC10aXRsZVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdWNjZXNzLW1vZGFsLWljb25cIj48Q2hlY2tDaXJjbGUyIHNpemU9ezI2fSAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgPGgyIGlkPVwiYWNjb3VudC1kZWxldGVkLXRpdGxlXCI+Q29tcHRlIHN1cHByaW3DqTwvaDI+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIFZvdHJlIGNvbXB0ZSBldCBzZXMgZG9ubsOpZXMgb250IMOpdMOpIHN1cHByaW3DqXMuIFZvdXMgYXZleiDDqXTDqSBkw6ljb25uZWN0w6kuXHJcbiAgICAgICAgICAgICAge2FjY291bnREZWxldGlvbk5vdGljZSA+IDAgJiYgYCAke2FjY291bnREZWxldGlvbk5vdGljZX0gZmljaGllcihzKSBpbXBvcnTDqShzKSBu4oCZb250IHBhcyBwdSDDqnRyZSBzdXBwcmltw6lzIGR1IGRpc3F1ZS5gfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRBY2NvdW50RGVsZXRpb25Ob3RpY2UobnVsbCl9PlJldG91ciDDoCBs4oCZYWNjdWVpbDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XHJcbiAgY29uc3Qgc2hhcmVUb2tlbiA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5tYXRjaCgvXlxcL3NoYXJlXFwvKFteL10rKSQvKT8uWzFdXHJcbiAgaWYgKHNoYXJlVG9rZW4pIHJldHVybiA8UHVibGljU2hhcmVkQW5hbHlzaXMgdG9rZW49e2RlY29kZVVSSUNvbXBvbmVudChzaGFyZVRva2VuKX0gLz5cclxuICByZXR1cm4gPEFwcFNoZWxsIC8+XHJcbn0iXX0=