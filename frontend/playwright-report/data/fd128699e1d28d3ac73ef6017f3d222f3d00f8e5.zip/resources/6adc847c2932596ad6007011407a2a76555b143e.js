import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UndoToast.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/UndoToast.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
export function UndoToast({ message, onUndo }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "history-undo-toast",
		role: "status",
		"aria-live": "polite",
		children: [/* @__PURE__ */ _jsxDEV("span", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			onClick: onUndo,
			children: "Annuler"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = UndoToast;
var _c;
$RefreshReg$(_c, "UndoToast");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/UndoToast.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/UndoToast.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/UndoToast.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/UndoToast.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFFQSxPQUFPLFNBQVMsVUFBVSxFQUFFLFNBQVMsVUFBaUI7Q0FDcEQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFxQixNQUFLO0VBQVMsYUFBVTtZQUE1RCxDQUNFLHdCQUFDLFFBQUQsWUFBTyxRQUFjOzs7O1lBQ3JCLHdCQUFDLFVBQUQ7R0FBUSxTQUFTO2FBQVE7RUFBZTs7OztVQUNyQzs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVW5kb1RvYXN0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJ0eXBlIFByb3BzID0geyBtZXNzYWdlOiBzdHJpbmc7IG9uVW5kbzogKCkgPT4gdm9pZCB9XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVW5kb1RvYXN0KHsgbWVzc2FnZSwgb25VbmRvIH06IFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS11bmRvLXRvYXN0XCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxyXG4gICAgICA8c3Bhbj57bWVzc2FnZX08L3NwYW4+XHJcbiAgICAgIDxidXR0b24gb25DbGljaz17b25VbmRvfT5Bbm51bGVyPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl19