import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ChartRenderer.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis } from "/node_modules/.vite/deps/recharts.js?v=5b99bddd";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChartRenderer.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$();
const COLORS = [
	"#2563EB",
	"#0B1F3A",
	"#1D4ED8",
	"#1E40AF",
	"#3B82F6",
	"#172554",
	"#1E3A8A",
	"#1E293B"
];
function normalizeChart(config) {
	if (!config || typeof config !== "object") return null;
	const labels = Array.isArray(config.labels) ? config.labels.map(String) : [];
	let series;
	if (Array.isArray(config.series)) {
		if (config.series.some((item) => !item || typeof item !== "object")) return null;
		series = config.series;
	} else if (Array.isArray(config.values)) {
		series = [{
			name: config.title || "Valeur",
			values: config.values
		}];
	} else {
		return null;
	}
	if (!labels.length || !series.length || series.some((item) => !Array.isArray(item.values) || item.values.length !== labels.length || item.values.some((value) => typeof value !== "number" || !Number.isFinite(value)))) return null;
	return {
		type: config.type ?? "bar",
		title: config.title || "Résultat",
		x_label: config.x_label ?? "",
		y_label: config.y_label ?? "",
		labels,
		series
	};
}
export function ChartRenderer({ config }) {
	_s();
	const chart = normalizeChart(config);
	const [selectedType, setSelectedType] = useState(chart?.type ?? "bar");
	if (!chart) return null;
	const numericLabels = chart.labels.every((label) => label.trim() !== "" && Number.isFinite(Number(label)));
	const pieAvailable = chart.labels.length <= 8 && chart.series.length === 1 && chart.series[0].values.every((value) => value >= 0);
	const availableTypes = [
		"bar",
		"line",
		...pieAvailable ? ["pie"] : [],
		...numericLabels ? ["scatter"] : []
	];
	const type = availableTypes.includes(selectedType) ? selectedType : availableTypes.includes(chart.type) ? chart.type : "bar";
	const rows = chart.labels.map((label, index) => ({
		label,
		...Object.fromEntries(chart.series.map((seriesItem) => [seriesItem.name, seriesItem.values[index]]))
	}));
	const scatterRows = chart.series.map((seriesItem) => ({
		name: seriesItem.name,
		data: chart.labels.map((label, index) => ({
			x: Number(label),
			y: seriesItem.values[index]
		}))
	}));
	const axisLabel = (value) => value ? {
		value,
		position: "insideBottom",
		offset: -3
	} : undefined;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "chart-renderer",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "chart-renderer-heading",
			children: [/* @__PURE__ */ _jsxDEV("strong", { children: chart.title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 5
			}, this), availableTypes.length > 1 && /* @__PURE__ */ _jsxDEV("label", { children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Type de graphique"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("select", {
				value: type,
				onChange: (event) => {
					const nextType = availableTypes.find((availableType) => availableType === event.target.value);
					if (nextType) setSelectedType(nextType);
				},
				children: availableTypes.map((availableType) => /* @__PURE__ */ _jsxDEV("option", {
					value: availableType,
					children: {
						bar: "Barres",
						line: "Lignes",
						pie: "Camembert",
						scatter: "Nuage de points"
					}[availableType]
				}, availableType, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 7
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 6
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 4
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "chart-renderer-canvas",
			children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: type === "pie" ? /* @__PURE__ */ _jsxDEV(PieChart, { children: [
					/* @__PURE__ */ _jsxDEV(Tooltip, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 8
					}, this),
					/* @__PURE__ */ _jsxDEV(Legend, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 8
					}, this),
					/* @__PURE__ */ _jsxDEV(Pie, {
						data: rows,
						dataKey: chart.series[0].name,
						nameKey: "label",
						cx: "50%",
						cy: "50%",
						outerRadius: "72%",
						label: true,
						children: rows.map((row, index) => /* @__PURE__ */ _jsxDEV(Cell, { fill: COLORS[index % COLORS.length] }, row.label, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 35
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 8
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 7
				}, this) : type === "scatter" ? /* @__PURE__ */ _jsxDEV(ScatterChart, {
					margin: {
						top: 12,
						right: 20,
						bottom: 24,
						left: 8
					},
					children: [
						/* @__PURE__ */ _jsxDEV(CartesianGrid, { stroke: "#DBEAFE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(XAxis, {
							type: "number",
							dataKey: "x",
							name: chart.x_label || "X",
							label: axisLabel(chart.x_label)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(YAxis, {
							type: "number",
							dataKey: "y",
							name: chart.y_label || "Valeur",
							label: chart.y_label ? {
								value: chart.y_label,
								angle: -90,
								position: "insideLeft"
							} : undefined
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(Tooltip, { cursor: { strokeDasharray: "3 3" } }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(Legend, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 8
						}, this),
						scatterRows.map((seriesItem, index) => /* @__PURE__ */ _jsxDEV(Scatter, {
							name: seriesItem.name,
							data: seriesItem.data,
							fill: COLORS[index % COLORS.length]
						}, seriesItem.name, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 9
						}, this))
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 7
				}, this) : type === "line" ? /* @__PURE__ */ _jsxDEV(LineChart, {
					data: rows,
					margin: {
						top: 12,
						right: 18,
						bottom: 24,
						left: 8
					},
					children: [
						/* @__PURE__ */ _jsxDEV(CartesianGrid, { stroke: "#DBEAFE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(XAxis, {
							dataKey: "label",
							label: axisLabel(chart.x_label)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(YAxis, { label: chart.y_label ? {
							value: chart.y_label,
							angle: -90,
							position: "insideLeft"
						} : undefined }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(Tooltip, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(Legend, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 8
						}, this),
						chart.series.map((seriesItem, index) => /* @__PURE__ */ _jsxDEV(Line, {
							type: "monotone",
							dataKey: seriesItem.name,
							name: seriesItem.name,
							stroke: COLORS[index % COLORS.length],
							strokeWidth: 2,
							dot: false
						}, seriesItem.name, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 9
						}, this))
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 7
				}, this) : /* @__PURE__ */ _jsxDEV(BarChart, {
					data: rows,
					margin: {
						top: 12,
						right: 18,
						bottom: 24,
						left: 8
					},
					children: [
						/* @__PURE__ */ _jsxDEV(CartesianGrid, {
							stroke: "#DBEAFE",
							vertical: false
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(XAxis, {
							dataKey: "label",
							label: axisLabel(chart.x_label)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(YAxis, { label: chart.y_label ? {
							value: chart.y_label,
							angle: -90,
							position: "insideLeft"
						} : undefined }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(Tooltip, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 8
						}, this),
						/* @__PURE__ */ _jsxDEV(Legend, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 8
						}, this),
						chart.series.map((seriesItem, index) => /* @__PURE__ */ _jsxDEV(Bar, {
							dataKey: seriesItem.name,
							name: seriesItem.name,
							fill: COLORS[index % COLORS.length],
							radius: [
								3,
								3,
								0,
								0
							]
						}, seriesItem.name, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 9
						}, this))
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 7
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 5
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 4
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 86,
		columnNumber: 3
	}, this);
}
_s(ChartRenderer, "oCFez41rp1NdYyuxJieiHfUcmFE=");
_c = ChartRenderer;
var _c;
$RefreshReg$(_c, "ChartRenderer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ChartRenderer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChartRenderer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChartRenderer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChartRenderer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FDQyxLQUNBLFVBQ0EsZUFDQSxNQUNBLFFBQ0EsTUFDQSxXQUNBLEtBQ0EsVUFDQSxxQkFDQSxTQUNBLGNBQ0EsU0FDQSxPQUNBLGFBQ007Ozs7QUFHUCxNQUFNLFNBQVM7Q0FBQztDQUFXO0NBQVc7Q0FBVztDQUFXO0NBQVc7Q0FBVztDQUFXO0FBQVM7QUFXdEcsU0FBUyxlQUFlLFFBQTZDO0NBQ3BFLElBQUksQ0FBQyxVQUFVLE9BQU8sV0FBVyxVQUFVLE9BQU87Q0FDbEQsTUFBTSxTQUFTLE1BQU0sUUFBUSxPQUFPLE1BQU0sSUFBSSxPQUFPLE9BQU8sSUFBSSxNQUFNLElBQUksQ0FBQztDQUMzRSxJQUFJO0NBQ0osSUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLEdBQUc7RUFDakMsSUFBSSxPQUFPLE9BQU8sTUFBTSxTQUFTLENBQUMsUUFBUSxPQUFPLFNBQVMsUUFBUSxHQUFHLE9BQU87RUFDNUUsU0FBUyxPQUFPO0NBQ2pCLE9BQU8sSUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLEdBQUc7RUFDeEMsU0FBUyxDQUFDO0dBQUUsTUFBTSxPQUFPLFNBQVM7R0FBVSxRQUFRLE9BQU87RUFBTyxDQUFDO0NBQ3BFLE9BQU87RUFDTixPQUFPO0NBQ1I7Q0FDQSxJQUFJLENBQUMsT0FBTyxVQUFVLENBQUMsT0FBTyxVQUFVLE9BQU8sTUFBTSxTQUNwRCxDQUFDLE1BQU0sUUFBUSxLQUFLLE1BQU0sS0FDdkIsS0FBSyxPQUFPLFdBQVcsT0FBTyxVQUM5QixLQUFLLE9BQU8sTUFBTSxVQUFVLE9BQU8sVUFBVSxZQUFZLENBQUMsT0FBTyxTQUFTLEtBQUssQ0FBQyxDQUNwRixHQUFHLE9BQU87Q0FDVixPQUFPO0VBQ04sTUFBTSxPQUFPLFFBQVE7RUFDckIsT0FBTyxPQUFPLFNBQVM7RUFDdkIsU0FBUyxPQUFPLFdBQVc7RUFDM0IsU0FBUyxPQUFPLFdBQVc7RUFDM0I7RUFDQTtDQUNEO0FBQ0Q7QUFFQSxPQUFPLFNBQVMsY0FBYyxFQUFFLFVBQW1DOztDQUNsRSxNQUFNLFFBQVEsZUFBZSxNQUFNO0NBQ25DLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFvQixPQUFPLFFBQVEsS0FBSztDQUNoRixJQUFJLENBQUMsT0FBTyxPQUFPO0NBRW5CLE1BQU0sZ0JBQWdCLE1BQU0sT0FBTyxPQUFPLFVBQVUsTUFBTSxLQUFLLE1BQU0sTUFBTSxPQUFPLFNBQVMsT0FBTyxLQUFLLENBQUMsQ0FBQztDQUN6RyxNQUFNLGVBQWUsTUFBTSxPQUFPLFVBQVUsS0FBSyxNQUFNLE9BQU8sV0FBVyxLQUFLLE1BQU0sT0FBTyxFQUFFLENBQUMsT0FBTyxPQUFPLFVBQVUsU0FBUyxDQUFDO0NBQ2hJLE1BQU0saUJBQThCO0VBQUM7RUFBTztFQUFRLEdBQUksZUFBZSxDQUFDLEtBQWMsSUFBSSxDQUFDO0VBQUksR0FBSSxnQkFBZ0IsQ0FBQyxTQUFrQixJQUFJLENBQUM7Q0FBRTtDQUM3SSxNQUFNLE9BQU8sZUFBZSxTQUFTLFlBQVksSUFDOUMsZUFDQSxlQUFlLFNBQVMsTUFBTSxJQUFJLElBQ2pDLE1BQU0sT0FDTjtDQUNKLE1BQU0sT0FBTyxNQUFNLE9BQU8sS0FBSyxPQUFPLFdBQVc7RUFDaEQ7RUFDQSxHQUFHLE9BQU8sWUFBWSxNQUFNLE9BQU8sS0FBSyxlQUFlLENBQUMsV0FBVyxNQUFNLFdBQVcsT0FBTyxNQUFNLENBQUMsQ0FBQztDQUNwRyxFQUFFO0NBQ0YsTUFBTSxjQUFjLE1BQU0sT0FBTyxLQUFLLGdCQUFnQjtFQUNyRCxNQUFNLFdBQVc7RUFDakIsTUFBTSxNQUFNLE9BQU8sS0FBSyxPQUFPLFdBQVc7R0FDekMsR0FBRyxPQUFPLEtBQUs7R0FDZixHQUFHLFdBQVcsT0FBTztFQUN0QixFQUFFO0NBQ0gsRUFBRTtDQUNGLE1BQU0sYUFBYSxVQUFrQixRQUFRO0VBQUU7RUFBTyxVQUFVO0VBQXlCLFFBQVEsQ0FBQztDQUFFLElBQUk7Q0FFeEcsT0FDQyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNDLHdCQUFDLFVBQUQsWUFBUyxNQUFNLE1BQWM7Ozs7YUFDNUIsZUFBZSxTQUFTLEtBQ3hCLHdCQUFDLFNBQUQsYUFDQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFVO0dBQXVCOzs7O2FBQ2pELHdCQUFDLFVBQUQ7SUFBUSxPQUFPO0lBQU0sV0FBVyxVQUFVO0tBQ3pDLE1BQU0sV0FBVyxlQUFlLE1BQU0sa0JBQWtCLGtCQUFrQixNQUFNLE9BQU8sS0FBSztLQUM1RixJQUFJLFVBQVUsZ0JBQWdCLFFBQVE7SUFDdkM7Y0FDRSxlQUFlLEtBQUssa0JBQ3BCLHdCQUFDLFVBQUQ7S0FBNEIsT0FBTztlQUNqQztNQUFFLEtBQUs7TUFBVSxNQUFNO01BQVUsS0FBSztNQUFhLFNBQVM7S0FBa0IsRUFBRTtJQUMxRSxHQUZLOzs7O1dBRUwsQ0FDUjtHQUNNOzs7O1dBQ0Y7Ozs7V0FFSjs7Ozs7WUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNkLHdCQUFDLHFCQUFEO0lBQXFCLE9BQU07SUFBTyxRQUFPO2NBQ3ZDLFNBQVMsUUFDVCx3QkFBQyxVQUFEO0tBQ0Msd0JBQUMsU0FBRCxDQUFVOzs7OztLQUNWLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7S0FDVCx3QkFBQyxLQUFEO01BQUssTUFBTTtNQUFNLFNBQVMsTUFBTSxPQUFPLEVBQUUsQ0FBQztNQUFNLFNBQVE7TUFBUSxJQUFHO01BQU0sSUFBRztNQUFNLGFBQVk7TUFBTTtnQkFDbEcsS0FBSyxLQUFLLEtBQUssVUFBVSx3QkFBQyxNQUFELEVBQXNCLE1BQU0sT0FBTyxRQUFRLE9BQU8sUUFBVSxHQUFqRCxJQUFJOzs7O2FBQTZDLENBQUM7S0FDbkY7Ozs7O0lBQ0k7Ozs7ZUFDUCxTQUFTLFlBQ1osd0JBQUMsY0FBRDtLQUFjLFFBQVE7TUFBRSxLQUFLO01BQUksT0FBTztNQUFJLFFBQVE7TUFBSSxNQUFNO0tBQUU7ZUFBaEU7TUFDQyx3QkFBQyxlQUFELEVBQWUsUUFBTyxVQUFXOzs7OztNQUNqQyx3QkFBQyxPQUFEO09BQU8sTUFBSztPQUFTLFNBQVE7T0FBSSxNQUFNLE1BQU0sV0FBVztPQUFLLE9BQU8sVUFBVSxNQUFNLE9BQU87TUFBSTs7Ozs7TUFDL0Ysd0JBQUMsT0FBRDtPQUFPLE1BQUs7T0FBUyxTQUFRO09BQUksTUFBTSxNQUFNLFdBQVc7T0FBVSxPQUFPLE1BQU0sVUFBVTtRQUFFLE9BQU8sTUFBTTtRQUFTLE9BQU8sQ0FBQztRQUFJLFVBQVU7T0FBYSxJQUFJO01BQVk7Ozs7O01BQ3BLLHdCQUFDLFNBQUQsRUFBUyxRQUFRLEVBQUUsaUJBQWlCLE1BQU0sRUFBSTs7Ozs7TUFDOUMsd0JBQUMsUUFBRCxDQUFTOzs7OztNQUNSLFlBQVksS0FBSyxZQUFZLFVBQzdCLHdCQUFDLFNBQUQ7T0FBK0IsTUFBTSxXQUFXO09BQU0sTUFBTSxXQUFXO09BQU0sTUFBTSxPQUFPLFFBQVEsT0FBTztNQUFVLEdBQXJHLFdBQVc7Ozs7YUFBMEYsQ0FDbkg7S0FDWTs7Ozs7ZUFDWCxTQUFTLFNBQ1osd0JBQUMsV0FBRDtLQUFXLE1BQU07S0FBTSxRQUFRO01BQUUsS0FBSztNQUFJLE9BQU87TUFBSSxRQUFRO01BQUksTUFBTTtLQUFFO2VBQXpFO01BQ0Msd0JBQUMsZUFBRCxFQUFlLFFBQU8sVUFBVzs7Ozs7TUFDakMsd0JBQUMsT0FBRDtPQUFPLFNBQVE7T0FBUSxPQUFPLFVBQVUsTUFBTSxPQUFPO01BQUk7Ozs7O01BQ3pELHdCQUFDLE9BQUQsRUFBTyxPQUFPLE1BQU0sVUFBVTtPQUFFLE9BQU8sTUFBTTtPQUFTLE9BQU8sQ0FBQztPQUFJLFVBQVU7TUFBYSxJQUFJLFVBQVk7Ozs7O01BQ3pHLHdCQUFDLFNBQUQsQ0FBVTs7Ozs7TUFDVix3QkFBQyxRQUFELENBQVM7Ozs7O01BQ1IsTUFBTSxPQUFPLEtBQUssWUFBWSxVQUM5Qix3QkFBQyxNQUFEO09BQTRCLE1BQUs7T0FBVyxTQUFTLFdBQVc7T0FBTSxNQUFNLFdBQVc7T0FBTSxRQUFRLE9BQU8sUUFBUSxPQUFPO09BQVMsYUFBYTtPQUFHLEtBQUs7TUFBUSxHQUF0SixXQUFXOzs7O2FBQTJJLENBQ2pLO0tBQ1M7Ozs7O2VBRVgsd0JBQUMsVUFBRDtLQUFVLE1BQU07S0FBTSxRQUFRO01BQUUsS0FBSztNQUFJLE9BQU87TUFBSSxRQUFRO01BQUksTUFBTTtLQUFFO2VBQXhFO01BQ0Msd0JBQUMsZUFBRDtPQUFlLFFBQU87T0FBVSxVQUFVO01BQVE7Ozs7O01BQ2xELHdCQUFDLE9BQUQ7T0FBTyxTQUFRO09BQVEsT0FBTyxVQUFVLE1BQU0sT0FBTztNQUFJOzs7OztNQUN6RCx3QkFBQyxPQUFELEVBQU8sT0FBTyxNQUFNLFVBQVU7T0FBRSxPQUFPLE1BQU07T0FBUyxPQUFPLENBQUM7T0FBSSxVQUFVO01BQWEsSUFBSSxVQUFZOzs7OztNQUN6Ryx3QkFBQyxTQUFELENBQVU7Ozs7O01BQ1Ysd0JBQUMsUUFBRCxDQUFTOzs7OztNQUNSLE1BQU0sT0FBTyxLQUFLLFlBQVksVUFDOUIsd0JBQUMsS0FBRDtPQUEyQixTQUFTLFdBQVc7T0FBTSxNQUFNLFdBQVc7T0FBTSxNQUFNLE9BQU8sUUFBUSxPQUFPO09BQVMsUUFBUTtRQUFDO1FBQUc7UUFBRztRQUFHO09BQUM7TUFBSSxHQUE5SCxXQUFXOzs7O2FBQW1ILENBQ3hJO0tBQ1E7Ozs7OztHQUVTOzs7OztFQUNqQjs7OztVQUNEOzs7Ozs7QUFFUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGFydFJlbmRlcmVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQge1xyXG5cdEJhcixcclxuXHRCYXJDaGFydCxcclxuXHRDYXJ0ZXNpYW5HcmlkLFxyXG5cdENlbGwsXHJcblx0TGVnZW5kLFxyXG5cdExpbmUsXHJcblx0TGluZUNoYXJ0LFxyXG5cdFBpZSxcclxuXHRQaWVDaGFydCxcclxuXHRSZXNwb25zaXZlQ29udGFpbmVyLFxyXG5cdFNjYXR0ZXIsXHJcblx0U2NhdHRlckNoYXJ0LFxyXG5cdFRvb2x0aXAsXHJcblx0WEF4aXMsXHJcblx0WUF4aXMsXHJcbn0gZnJvbSAncmVjaGFydHMnXHJcbmltcG9ydCB0eXBlIHsgQ2hhcnRDb25maWcsIENoYXJ0U2VyaWVzLCBDaGFydFR5cGUgfSBmcm9tICcuLi90eXBlcydcclxuXHJcbmNvbnN0IENPTE9SUyA9IFsnIzI1NjNFQicsICcjMEIxRjNBJywgJyMxRDRFRDgnLCAnIzFFNDBBRicsICcjM0I4MkY2JywgJyMxNzI1NTQnLCAnIzFFM0E4QScsICcjMUUyOTNCJ11cclxuXHJcbnR5cGUgTm9ybWFsaXplZENoYXJ0ID0ge1xyXG5cdHR5cGU6IENoYXJ0VHlwZVxyXG5cdHRpdGxlOiBzdHJpbmdcclxuXHR4X2xhYmVsOiBzdHJpbmdcclxuXHR5X2xhYmVsOiBzdHJpbmdcclxuXHRsYWJlbHM6IHN0cmluZ1tdXHJcblx0c2VyaWVzOiBDaGFydFNlcmllc1tdXHJcbn1cclxuXHJcbmZ1bmN0aW9uIG5vcm1hbGl6ZUNoYXJ0KGNvbmZpZzogQ2hhcnRDb25maWcpOiBOb3JtYWxpemVkQ2hhcnQgfCBudWxsIHtcclxuXHRpZiAoIWNvbmZpZyB8fCB0eXBlb2YgY29uZmlnICE9PSAnb2JqZWN0JykgcmV0dXJuIG51bGxcclxuXHRjb25zdCBsYWJlbHMgPSBBcnJheS5pc0FycmF5KGNvbmZpZy5sYWJlbHMpID8gY29uZmlnLmxhYmVscy5tYXAoU3RyaW5nKSA6IFtdXHJcblx0bGV0IHNlcmllczogQ2hhcnRTZXJpZXNbXVxyXG5cdGlmIChBcnJheS5pc0FycmF5KGNvbmZpZy5zZXJpZXMpKSB7XHJcblx0XHRpZiAoY29uZmlnLnNlcmllcy5zb21lKChpdGVtKSA9PiAhaXRlbSB8fCB0eXBlb2YgaXRlbSAhPT0gJ29iamVjdCcpKSByZXR1cm4gbnVsbFxyXG5cdFx0c2VyaWVzID0gY29uZmlnLnNlcmllc1xyXG5cdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjb25maWcudmFsdWVzKSkge1xyXG5cdFx0c2VyaWVzID0gW3sgbmFtZTogY29uZmlnLnRpdGxlIHx8ICdWYWxldXInLCB2YWx1ZXM6IGNvbmZpZy52YWx1ZXMgfV1cclxuXHR9IGVsc2Uge1xyXG5cdFx0cmV0dXJuIG51bGxcclxuXHR9XHJcblx0aWYgKCFsYWJlbHMubGVuZ3RoIHx8ICFzZXJpZXMubGVuZ3RoIHx8IHNlcmllcy5zb21lKChpdGVtKSA9PlxyXG5cdFx0IUFycmF5LmlzQXJyYXkoaXRlbS52YWx1ZXMpXHJcblx0XHR8fCBpdGVtLnZhbHVlcy5sZW5ndGggIT09IGxhYmVscy5sZW5ndGhcclxuXHRcdHx8IGl0ZW0udmFsdWVzLnNvbWUoKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgIT09ICdudW1iZXInIHx8ICFOdW1iZXIuaXNGaW5pdGUodmFsdWUpKVxyXG5cdCkpIHJldHVybiBudWxsXHJcblx0cmV0dXJuIHtcclxuXHRcdHR5cGU6IGNvbmZpZy50eXBlID8/ICdiYXInLFxyXG5cdFx0dGl0bGU6IGNvbmZpZy50aXRsZSB8fCAnUsOpc3VsdGF0JyxcclxuXHRcdHhfbGFiZWw6IGNvbmZpZy54X2xhYmVsID8/ICcnLFxyXG5cdFx0eV9sYWJlbDogY29uZmlnLnlfbGFiZWwgPz8gJycsXHJcblx0XHRsYWJlbHMsXHJcblx0XHRzZXJpZXMsXHJcblx0fVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ2hhcnRSZW5kZXJlcih7IGNvbmZpZyB9OiB7IGNvbmZpZzogQ2hhcnRDb25maWcgfSkge1xyXG5cdGNvbnN0IGNoYXJ0ID0gbm9ybWFsaXplQ2hhcnQoY29uZmlnKVxyXG5cdGNvbnN0IFtzZWxlY3RlZFR5cGUsIHNldFNlbGVjdGVkVHlwZV0gPSB1c2VTdGF0ZTxDaGFydFR5cGU+KGNoYXJ0Py50eXBlID8/ICdiYXInKVxyXG5cdGlmICghY2hhcnQpIHJldHVybiBudWxsXHJcblxyXG5cdGNvbnN0IG51bWVyaWNMYWJlbHMgPSBjaGFydC5sYWJlbHMuZXZlcnkoKGxhYmVsKSA9PiBsYWJlbC50cmltKCkgIT09ICcnICYmIE51bWJlci5pc0Zpbml0ZShOdW1iZXIobGFiZWwpKSlcclxuXHRjb25zdCBwaWVBdmFpbGFibGUgPSBjaGFydC5sYWJlbHMubGVuZ3RoIDw9IDggJiYgY2hhcnQuc2VyaWVzLmxlbmd0aCA9PT0gMSAmJiBjaGFydC5zZXJpZXNbMF0udmFsdWVzLmV2ZXJ5KCh2YWx1ZSkgPT4gdmFsdWUgPj0gMClcclxuXHRjb25zdCBhdmFpbGFibGVUeXBlczogQ2hhcnRUeXBlW10gPSBbJ2JhcicsICdsaW5lJywgLi4uKHBpZUF2YWlsYWJsZSA/IFsncGllJyBhcyBjb25zdF0gOiBbXSksIC4uLihudW1lcmljTGFiZWxzID8gWydzY2F0dGVyJyBhcyBjb25zdF0gOiBbXSldXHJcblx0Y29uc3QgdHlwZSA9IGF2YWlsYWJsZVR5cGVzLmluY2x1ZGVzKHNlbGVjdGVkVHlwZSlcclxuXHRcdD8gc2VsZWN0ZWRUeXBlXHJcblx0XHQ6IGF2YWlsYWJsZVR5cGVzLmluY2x1ZGVzKGNoYXJ0LnR5cGUpXHJcblx0XHRcdD8gY2hhcnQudHlwZVxyXG5cdFx0XHQ6ICdiYXInXHJcblx0Y29uc3Qgcm93cyA9IGNoYXJ0LmxhYmVscy5tYXAoKGxhYmVsLCBpbmRleCkgPT4gKHtcclxuXHRcdGxhYmVsLFxyXG5cdFx0Li4uT2JqZWN0LmZyb21FbnRyaWVzKGNoYXJ0LnNlcmllcy5tYXAoKHNlcmllc0l0ZW0pID0+IFtzZXJpZXNJdGVtLm5hbWUsIHNlcmllc0l0ZW0udmFsdWVzW2luZGV4XV0pKSxcclxuXHR9KSlcclxuXHRjb25zdCBzY2F0dGVyUm93cyA9IGNoYXJ0LnNlcmllcy5tYXAoKHNlcmllc0l0ZW0pID0+ICh7XHJcblx0XHRuYW1lOiBzZXJpZXNJdGVtLm5hbWUsXHJcblx0XHRkYXRhOiBjaGFydC5sYWJlbHMubWFwKChsYWJlbCwgaW5kZXgpID0+ICh7XHJcblx0XHRcdHg6IE51bWJlcihsYWJlbCksXHJcblx0XHRcdHk6IHNlcmllc0l0ZW0udmFsdWVzW2luZGV4XSxcclxuXHRcdH0pKSxcclxuXHR9KSlcclxuXHRjb25zdCBheGlzTGFiZWwgPSAodmFsdWU6IHN0cmluZykgPT4gdmFsdWUgPyB7IHZhbHVlLCBwb3NpdGlvbjogJ2luc2lkZUJvdHRvbScgYXMgY29uc3QsIG9mZnNldDogLTMgfSA6IHVuZGVmaW5lZFxyXG5cclxuXHRyZXR1cm4gKFxyXG5cdFx0PGRpdiBjbGFzc05hbWU9XCJjaGFydC1yZW5kZXJlclwiPlxyXG5cdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cImNoYXJ0LXJlbmRlcmVyLWhlYWRpbmdcIj5cclxuXHRcdFx0XHQ8c3Ryb25nPntjaGFydC50aXRsZX08L3N0cm9uZz5cclxuXHRcdFx0XHR7YXZhaWxhYmxlVHlwZXMubGVuZ3RoID4gMSAmJiAoXHJcblx0XHRcdFx0XHQ8bGFiZWw+XHJcblx0XHRcdFx0XHRcdDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5UeXBlIGRlIGdyYXBoaXF1ZTwvc3Bhbj5cclxuXHRcdFx0XHRcdFx0PHNlbGVjdCB2YWx1ZT17dHlwZX0gb25DaGFuZ2U9eyhldmVudCkgPT4ge1xyXG5cdFx0XHRcdFx0XHRcdGNvbnN0IG5leHRUeXBlID0gYXZhaWxhYmxlVHlwZXMuZmluZCgoYXZhaWxhYmxlVHlwZSkgPT4gYXZhaWxhYmxlVHlwZSA9PT0gZXZlbnQudGFyZ2V0LnZhbHVlKVxyXG5cdFx0XHRcdFx0XHRcdGlmIChuZXh0VHlwZSkgc2V0U2VsZWN0ZWRUeXBlKG5leHRUeXBlKVxyXG5cdFx0XHRcdFx0XHR9fT5cclxuXHRcdFx0XHRcdFx0XHR7YXZhaWxhYmxlVHlwZXMubWFwKChhdmFpbGFibGVUeXBlKSA9PiAoXHJcblx0XHRcdFx0XHRcdFx0XHQ8b3B0aW9uIGtleT17YXZhaWxhYmxlVHlwZX0gdmFsdWU9e2F2YWlsYWJsZVR5cGV9PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHR7eyBiYXI6ICdCYXJyZXMnLCBsaW5lOiAnTGlnbmVzJywgcGllOiAnQ2FtZW1iZXJ0Jywgc2NhdHRlcjogJ051YWdlIGRlIHBvaW50cycgfVthdmFpbGFibGVUeXBlXX1cclxuXHRcdFx0XHRcdFx0XHRcdDwvb3B0aW9uPlxyXG5cdFx0XHRcdFx0XHRcdCkpfVxyXG5cdFx0XHRcdFx0XHQ8L3NlbGVjdD5cclxuXHRcdFx0XHRcdDwvbGFiZWw+XHJcblx0XHRcdFx0KX1cclxuXHRcdFx0PC9kaXY+XHJcblx0XHRcdDxkaXYgY2xhc3NOYW1lPVwiY2hhcnQtcmVuZGVyZXItY2FudmFzXCI+XHJcblx0XHRcdFx0PFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxyXG5cdFx0XHRcdFx0e3R5cGUgPT09ICdwaWUnID8gKFxyXG5cdFx0XHRcdFx0XHQ8UGllQ2hhcnQ+XHJcblx0XHRcdFx0XHRcdFx0PFRvb2x0aXAgLz5cclxuXHRcdFx0XHRcdFx0XHQ8TGVnZW5kIC8+XHJcblx0XHRcdFx0XHRcdFx0PFBpZSBkYXRhPXtyb3dzfSBkYXRhS2V5PXtjaGFydC5zZXJpZXNbMF0ubmFtZX0gbmFtZUtleT1cImxhYmVsXCIgY3g9XCI1MCVcIiBjeT1cIjUwJVwiIG91dGVyUmFkaXVzPVwiNzIlXCIgbGFiZWw+XHJcblx0XHRcdFx0XHRcdFx0XHR7cm93cy5tYXAoKHJvdywgaW5kZXgpID0+IDxDZWxsIGtleT17cm93LmxhYmVsfSBmaWxsPXtDT0xPUlNbaW5kZXggJSBDT0xPUlMubGVuZ3RoXX0gLz4pfVxyXG5cdFx0XHRcdFx0XHRcdDwvUGllPlxyXG5cdFx0XHRcdFx0XHQ8L1BpZUNoYXJ0PlxyXG5cdFx0XHRcdFx0KSA6IHR5cGUgPT09ICdzY2F0dGVyJyA/IChcclxuXHRcdFx0XHRcdFx0PFNjYXR0ZXJDaGFydCBtYXJnaW49e3sgdG9wOiAxMiwgcmlnaHQ6IDIwLCBib3R0b206IDI0LCBsZWZ0OiA4IH19PlxyXG5cdFx0XHRcdFx0XHRcdDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZT1cIiNEQkVBRkVcIiAvPlxyXG5cdFx0XHRcdFx0XHRcdDxYQXhpcyB0eXBlPVwibnVtYmVyXCIgZGF0YUtleT1cInhcIiBuYW1lPXtjaGFydC54X2xhYmVsIHx8ICdYJ30gbGFiZWw9e2F4aXNMYWJlbChjaGFydC54X2xhYmVsKX0gLz5cclxuXHRcdFx0XHRcdFx0XHQ8WUF4aXMgdHlwZT1cIm51bWJlclwiIGRhdGFLZXk9XCJ5XCIgbmFtZT17Y2hhcnQueV9sYWJlbCB8fCAnVmFsZXVyJ30gbGFiZWw9e2NoYXJ0LnlfbGFiZWwgPyB7IHZhbHVlOiBjaGFydC55X2xhYmVsLCBhbmdsZTogLTkwLCBwb3NpdGlvbjogJ2luc2lkZUxlZnQnIH0gOiB1bmRlZmluZWR9IC8+XHJcblx0XHRcdFx0XHRcdFx0PFRvb2x0aXAgY3Vyc29yPXt7IHN0cm9rZURhc2hhcnJheTogJzMgMycgfX0gLz5cclxuXHRcdFx0XHRcdFx0XHQ8TGVnZW5kIC8+XHJcblx0XHRcdFx0XHRcdFx0e3NjYXR0ZXJSb3dzLm1hcCgoc2VyaWVzSXRlbSwgaW5kZXgpID0+IChcclxuXHRcdFx0XHRcdFx0XHRcdDxTY2F0dGVyIGtleT17c2VyaWVzSXRlbS5uYW1lfSBuYW1lPXtzZXJpZXNJdGVtLm5hbWV9IGRhdGE9e3Nlcmllc0l0ZW0uZGF0YX0gZmlsbD17Q09MT1JTW2luZGV4ICUgQ09MT1JTLmxlbmd0aF19IC8+XHJcblx0XHRcdFx0XHRcdFx0KSl9XHJcblx0XHRcdFx0XHRcdDwvU2NhdHRlckNoYXJ0PlxyXG5cdFx0XHRcdFx0KSA6IHR5cGUgPT09ICdsaW5lJyA/IChcclxuXHRcdFx0XHRcdFx0PExpbmVDaGFydCBkYXRhPXtyb3dzfSBtYXJnaW49e3sgdG9wOiAxMiwgcmlnaHQ6IDE4LCBib3R0b206IDI0LCBsZWZ0OiA4IH19PlxyXG5cdFx0XHRcdFx0XHRcdDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZT1cIiNEQkVBRkVcIiAvPlxyXG5cdFx0XHRcdFx0XHRcdDxYQXhpcyBkYXRhS2V5PVwibGFiZWxcIiBsYWJlbD17YXhpc0xhYmVsKGNoYXJ0LnhfbGFiZWwpfSAvPlxyXG5cdFx0XHRcdFx0XHRcdDxZQXhpcyBsYWJlbD17Y2hhcnQueV9sYWJlbCA/IHsgdmFsdWU6IGNoYXJ0LnlfbGFiZWwsIGFuZ2xlOiAtOTAsIHBvc2l0aW9uOiAnaW5zaWRlTGVmdCcgfSA6IHVuZGVmaW5lZH0gLz5cclxuXHRcdFx0XHRcdFx0XHQ8VG9vbHRpcCAvPlxyXG5cdFx0XHRcdFx0XHRcdDxMZWdlbmQgLz5cclxuXHRcdFx0XHRcdFx0XHR7Y2hhcnQuc2VyaWVzLm1hcCgoc2VyaWVzSXRlbSwgaW5kZXgpID0+IChcclxuXHRcdFx0XHRcdFx0XHRcdDxMaW5lIGtleT17c2VyaWVzSXRlbS5uYW1lfSB0eXBlPVwibW9ub3RvbmVcIiBkYXRhS2V5PXtzZXJpZXNJdGVtLm5hbWV9IG5hbWU9e3Nlcmllc0l0ZW0ubmFtZX0gc3Ryb2tlPXtDT0xPUlNbaW5kZXggJSBDT0xPUlMubGVuZ3RoXX0gc3Ryb2tlV2lkdGg9ezJ9IGRvdD17ZmFsc2V9IC8+XHJcblx0XHRcdFx0XHRcdFx0KSl9XHJcblx0XHRcdFx0XHRcdDwvTGluZUNoYXJ0PlxyXG5cdFx0XHRcdFx0KSA6IChcclxuXHRcdFx0XHRcdFx0PEJhckNoYXJ0IGRhdGE9e3Jvd3N9IG1hcmdpbj17eyB0b3A6IDEyLCByaWdodDogMTgsIGJvdHRvbTogMjQsIGxlZnQ6IDggfX0+XHJcblx0XHRcdFx0XHRcdFx0PENhcnRlc2lhbkdyaWQgc3Ryb2tlPVwiI0RCRUFGRVwiIHZlcnRpY2FsPXtmYWxzZX0gLz5cclxuXHRcdFx0XHRcdFx0XHQ8WEF4aXMgZGF0YUtleT1cImxhYmVsXCIgbGFiZWw9e2F4aXNMYWJlbChjaGFydC54X2xhYmVsKX0gLz5cclxuXHRcdFx0XHRcdFx0XHQ8WUF4aXMgbGFiZWw9e2NoYXJ0LnlfbGFiZWwgPyB7IHZhbHVlOiBjaGFydC55X2xhYmVsLCBhbmdsZTogLTkwLCBwb3NpdGlvbjogJ2luc2lkZUxlZnQnIH0gOiB1bmRlZmluZWR9IC8+XHJcblx0XHRcdFx0XHRcdFx0PFRvb2x0aXAgLz5cclxuXHRcdFx0XHRcdFx0XHQ8TGVnZW5kIC8+XHJcblx0XHRcdFx0XHRcdFx0e2NoYXJ0LnNlcmllcy5tYXAoKHNlcmllc0l0ZW0sIGluZGV4KSA9PiAoXHJcblx0XHRcdFx0XHRcdFx0XHQ8QmFyIGtleT17c2VyaWVzSXRlbS5uYW1lfSBkYXRhS2V5PXtzZXJpZXNJdGVtLm5hbWV9IG5hbWU9e3Nlcmllc0l0ZW0ubmFtZX0gZmlsbD17Q09MT1JTW2luZGV4ICUgQ09MT1JTLmxlbmd0aF19IHJhZGl1cz17WzMsIDMsIDAsIDBdfSAvPlxyXG5cdFx0XHRcdFx0XHRcdCkpfVxyXG5cdFx0XHRcdFx0XHQ8L0JhckNoYXJ0PlxyXG5cdFx0XHRcdFx0KX1cclxuXHRcdFx0XHQ8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcblx0XHRcdDwvZGl2PlxyXG5cdFx0PC9kaXY+XHJcblx0KVxyXG59XHJcbiJdfQ==