import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HistoryGroup.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { HistoryItem } from "/src/components/HistoryItem.tsx";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryGroup.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
export function HistoryGroup(props) {
	if (!props.items.length) return null;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "history-group",
		"aria-label": props.title,
		children: [
			/* @__PURE__ */ _jsxDEV("h3", { children: props.title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				role: "listbox",
				"aria-label": props.title,
				children: props.items.map((item) => /* @__PURE__ */ _jsxDEV(HistoryItem, {
					item,
					active: props.activeId === item.id,
					query: props.query,
					editing: props.editingId === item.id,
					onClick: () => props.onHistory(item.id),
					onStartRename: () => props.onStartRename(item.id),
					onRename: (title) => props.onRename(item, title),
					onCancelRename: props.onCancelRename,
					onToggleFavorite: () => props.onToggleFavorite(item),
					onRemove: () => props.onRemove(item)
				}, `${item.kind}-${item.id}`, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			props.sentinelRef && /* @__PURE__ */ _jsxDEV("div", {
				ref: props.sentinelRef,
				className: "history-pagination-sentinel",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 29
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_c = HistoryGroup;
var _c;
$RefreshReg$(_c, "HistoryGroup");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/HistoryGroup.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryGroup.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryGroup.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryGroup.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxtQkFBbUI7OztBQWlCNUIsT0FBTyxTQUFTLGFBQWEsT0FBYztDQUN6QyxJQUFJLENBQUMsTUFBTSxNQUFNLFFBQVEsT0FBTztDQUNoQyxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQWdCLGNBQVksTUFBTTtZQUFyRDtHQUNFLHdCQUFDLE1BQUQsWUFBSyxNQUFNLE1BQVU7Ozs7O0dBQ3JCLHdCQUFDLE9BQUQ7SUFBSyxNQUFLO0lBQVUsY0FBWSxNQUFNO2NBQ25DLE1BQU0sTUFBTSxLQUFLLFNBQ2hCLHdCQUFDLGFBQUQ7S0FFUTtLQUNOLFFBQVEsTUFBTSxhQUFhLEtBQUs7S0FDaEMsT0FBTyxNQUFNO0tBQ2IsU0FBUyxNQUFNLGNBQWMsS0FBSztLQUNsQyxlQUFlLE1BQU0sVUFBVSxLQUFLLEVBQUU7S0FDdEMscUJBQXFCLE1BQU0sY0FBYyxLQUFLLEVBQUU7S0FDaEQsV0FBVyxVQUFVLE1BQU0sU0FBUyxNQUFNLEtBQUs7S0FDL0MsZ0JBQWdCLE1BQU07S0FDdEIsd0JBQXdCLE1BQU0saUJBQWlCLElBQUk7S0FDbkQsZ0JBQWdCLE1BQU0sU0FBUyxJQUFJO0lBQ3BDLEdBWE0sR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLOzs7O1dBVzNCLENBQ0Y7R0FDRTs7Ozs7R0FDSixNQUFNLGVBQWUsd0JBQUMsT0FBRDtJQUFLLEtBQUssTUFBTTtJQUFhLFdBQVU7SUFBOEIsZUFBWTtHQUFROzs7OztFQUN4Rzs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGlzdG9yeUdyb3VwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEhpc3RvcnlFbnRyeSB9IGZyb20gJy4uL3R5cGVzJ1xyXG5pbXBvcnQgeyBIaXN0b3J5SXRlbSB9IGZyb20gJy4vSGlzdG9yeUl0ZW0nXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIHRpdGxlOiBzdHJpbmdcclxuICBpdGVtczogSGlzdG9yeUVudHJ5W11cclxuICBhY3RpdmVJZDogbnVtYmVyXHJcbiAgcXVlcnk6IHN0cmluZ1xyXG4gIGVkaXRpbmdJZDogbnVtYmVyIHwgbnVsbFxyXG4gIG9uSGlzdG9yeTogKGlkOiBudW1iZXIpID0+IHZvaWRcclxuICBvblN0YXJ0UmVuYW1lOiAoaWQ6IG51bWJlcikgPT4gdm9pZFxyXG4gIG9uUmVuYW1lOiAoaXRlbTogSGlzdG9yeUVudHJ5LCB0aXRsZTogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+XHJcbiAgb25DYW5jZWxSZW5hbWU6ICgpID0+IHZvaWRcclxuICBvblRvZ2dsZUZhdm9yaXRlOiAoaXRlbTogSGlzdG9yeUVudHJ5KSA9PiBQcm9taXNlPHZvaWQ+XHJcbiAgb25SZW1vdmU6IChpdGVtOiBIaXN0b3J5RW50cnkpID0+IFByb21pc2U8dm9pZD5cclxuICBzZW50aW5lbFJlZj86IChub2RlOiBIVE1MRGl2RWxlbWVudCB8IG51bGwpID0+IHZvaWRcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEhpc3RvcnlHcm91cChwcm9wczogUHJvcHMpIHtcclxuICBpZiAoIXByb3BzLml0ZW1zLmxlbmd0aCkgcmV0dXJuIG51bGxcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiaGlzdG9yeS1ncm91cFwiIGFyaWEtbGFiZWw9e3Byb3BzLnRpdGxlfT5cclxuICAgICAgPGgzPntwcm9wcy50aXRsZX08L2gzPlxyXG4gICAgICA8ZGl2IHJvbGU9XCJsaXN0Ym94XCIgYXJpYS1sYWJlbD17cHJvcHMudGl0bGV9PlxyXG4gICAgICAgIHtwcm9wcy5pdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgIDxIaXN0b3J5SXRlbVxyXG4gICAgICAgICAgICBrZXk9e2Ake2l0ZW0ua2luZH0tJHtpdGVtLmlkfWB9XHJcbiAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgIGFjdGl2ZT17cHJvcHMuYWN0aXZlSWQgPT09IGl0ZW0uaWR9XHJcbiAgICAgICAgICAgIHF1ZXJ5PXtwcm9wcy5xdWVyeX1cclxuICAgICAgICAgICAgZWRpdGluZz17cHJvcHMuZWRpdGluZ0lkID09PSBpdGVtLmlkfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwcm9wcy5vbkhpc3RvcnkoaXRlbS5pZCl9XHJcbiAgICAgICAgICAgIG9uU3RhcnRSZW5hbWU9eygpID0+IHByb3BzLm9uU3RhcnRSZW5hbWUoaXRlbS5pZCl9XHJcbiAgICAgICAgICAgIG9uUmVuYW1lPXsodGl0bGUpID0+IHByb3BzLm9uUmVuYW1lKGl0ZW0sIHRpdGxlKX1cclxuICAgICAgICAgICAgb25DYW5jZWxSZW5hbWU9e3Byb3BzLm9uQ2FuY2VsUmVuYW1lfVxyXG4gICAgICAgICAgICBvblRvZ2dsZUZhdm9yaXRlPXsoKSA9PiBwcm9wcy5vblRvZ2dsZUZhdm9yaXRlKGl0ZW0pfVxyXG4gICAgICAgICAgICBvblJlbW92ZT17KCkgPT4gcHJvcHMub25SZW1vdmUoaXRlbSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAge3Byb3BzLnNlbnRpbmVsUmVmICYmIDxkaXYgcmVmPXtwcm9wcy5zZW50aW5lbFJlZn0gY2xhc3NOYW1lPVwiaGlzdG9yeS1wYWdpbmF0aW9uLXNlbnRpbmVsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz59XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcbiJdfQ==