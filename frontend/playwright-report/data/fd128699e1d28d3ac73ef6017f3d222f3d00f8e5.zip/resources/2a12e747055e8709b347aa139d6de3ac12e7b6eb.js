import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HistoryItem.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import { FileImage, FileSpreadsheet, FileText, MessageSquare, Star, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryItem.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$();
export function HistoryItem({ item, active, query = "", editing = false, onClick, onStartRename, onRename, onCancelRename, onToggleFavorite, onRemove }) {
	_s();
	const [title, setTitle] = useState(item.title ?? item.question);
	const inputRef = useRef(null);
	const extension = item.file.split(".").pop()?.toLowerCase();
	const Icon = item.kind === "discussion" ? MessageSquare : extension === "pdf" || extension === "doc" || extension === "docx" ? FileText : extension === "png" || extension === "jpg" || extension === "jpeg" ? FileImage : FileSpreadsheet;
	useEffect(() => {
		if (editing) {
			setTitle(item.title ?? item.question);
			inputRef.current?.focus();
			inputRef.current?.select();
		}
	}, [
		editing,
		item.question,
		item.title
	]);
	const saveTitle = () => {
		const nextTitle = title.trim();
		if (nextTitle && nextTitle !== (item.title ?? item.question)) void onRename?.(nextTitle);
		onCancelRename?.();
	};
	const highlightedTitle = item.title ?? item.question;
	const queryIndex = query ? highlightedTitle.toLocaleLowerCase().indexOf(query.toLocaleLowerCase()) : -1;
	const formattedDate = Number.isFinite(Date.parse(item.date)) ? new Date(item.date).toLocaleString("fr-FR", {
		dateStyle: "short",
		timeStyle: "short"
	}) : item.date;
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "option",
		"aria-selected": Boolean(active),
		tabIndex: 0,
		className: `history-item-wrap ${active ? "history-item-active" : ""}`,
		onKeyDown: (event) => {
			if (event.key === "F2") {
				event.preventDefault();
				onStartRename?.();
			}
			if (event.key === "Delete") {
				event.preventDefault();
				void onRemove?.();
			}
		},
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: `history-item ${active ? "history-item-active" : ""}`,
			onClick,
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "history-file-icon",
				children: /* @__PURE__ */ _jsxDEV(Icon, { size: 15 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 40
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 4
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "min-w-0 text-left",
				children: [/* @__PURE__ */ _jsxDEV("strong", { children: editing ? /* @__PURE__ */ _jsxDEV("input", {
					ref: inputRef,
					"aria-label": "Nouveau titre",
					value: title,
					onChange: (event) => setTitle(event.target.value),
					onClick: (event) => event.stopPropagation(),
					onKeyDown: (event) => {
						event.stopPropagation();
						if (event.key === "Enter") saveTitle();
						if (event.key === "Escape") onCancelRename?.();
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 6
				}, this) : item.kind === "discussion" && query && queryIndex >= 0 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					"Discussion · ",
					highlightedTitle.slice(0, queryIndex),
					/* @__PURE__ */ _jsxDEV("mark", { children: highlightedTitle.slice(queryIndex, queryIndex + query.length) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 60
					}, this),
					highlightedTitle.slice(queryIndex + query.length)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 6
				}, this) : item.kind === "discussion" ? highlightedTitle : item.file }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 5
				}, this), /* @__PURE__ */ _jsxDEV("small", { children: formattedDate }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 5
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 4
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 4
		}, this), !editing && (onToggleFavorite || onRemove) && /* @__PURE__ */ _jsxDEV("span", {
			className: "history-item-actions",
			children: [onToggleFavorite && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": item.isFavorite ? "Retirer des favoris" : "Ajouter aux favoris",
				onClick: () => void onToggleFavorite(),
				children: /* @__PURE__ */ _jsxDEV(Star, {
					size: 14,
					fill: item.isFavorite ? "currentColor" : "none"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 165
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 26
			}, this), onRemove && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": "Supprimer de l’historique",
				onClick: () => void onRemove(),
				children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 111
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 18
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 51
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 3
	}, this);
}
_s(HistoryItem, "wgh0SS6ApRayt1pS1zw0nyc6gdE=");
_c = HistoryItem;
var _c;
$RefreshReg$(_c, "HistoryItem");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/HistoryItem.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryItem.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/HistoryItem.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGlCQUFpQixVQUFVLGVBQWUsTUFBTSxjQUFjO0FBQ2xGLFNBQVMsV0FBVyxRQUFRLGdCQUFnQjs7OztBQWU1QyxPQUFPLFNBQVMsWUFBWSxFQUFFLE1BQU0sUUFBUSxRQUFRLElBQUksVUFBVSxPQUFPLFNBQVMsZUFBZSxVQUFVLGdCQUFnQixrQkFBa0IsWUFBbUI7O0NBQy9KLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxLQUFLLFNBQVMsS0FBSyxRQUFRO0NBQzlELE1BQU0sV0FBVyxPQUF5QixJQUFJO0NBQzlDLE1BQU0sWUFBWSxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxZQUFZO0NBQzFELE1BQU0sT0FBTyxLQUFLLFNBQVMsZUFDeEIsZ0JBQ0EsY0FBYyxTQUFTLGNBQWMsU0FBUyxjQUFjLFNBQzNELFdBQ0EsY0FBYyxTQUFTLGNBQWMsU0FBUyxjQUFjLFNBQzNELFlBQ0E7Q0FFTCxnQkFBZ0I7RUFDZixJQUFJLFNBQVM7R0FDWixTQUFTLEtBQUssU0FBUyxLQUFLLFFBQVE7R0FDcEMsU0FBUyxTQUFTLE1BQU07R0FDeEIsU0FBUyxTQUFTLE9BQU87RUFDMUI7Q0FDRCxHQUFHO0VBQUM7RUFBUyxLQUFLO0VBQVUsS0FBSztDQUFLLENBQUM7Q0FFdkMsTUFBTSxrQkFBa0I7RUFDdkIsTUFBTSxZQUFZLE1BQU0sS0FBSztFQUM3QixJQUFJLGFBQWEsZUFBZSxLQUFLLFNBQVMsS0FBSyxXQUFXLEtBQUssV0FBVyxTQUFTO0VBQ3ZGLGlCQUFpQjtDQUNsQjtDQUNBLE1BQU0sbUJBQW1CLEtBQUssU0FBUyxLQUFLO0NBQzVDLE1BQU0sYUFBYSxRQUFRLGlCQUFpQixrQkFBa0IsQ0FBQyxDQUFDLFFBQVEsTUFBTSxrQkFBa0IsQ0FBQyxJQUFJLENBQUM7Q0FDdEcsTUFBTSxnQkFBZ0IsT0FBTyxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksQ0FBQyxJQUN4RCxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxlQUFlLFNBQVM7RUFBRSxXQUFXO0VBQVMsV0FBVztDQUFRLENBQUMsSUFDdEYsS0FBSztDQUVSLE9BQ0Msd0JBQUMsT0FBRDtFQUFLLE1BQUs7RUFBUyxpQkFBZSxRQUFRLE1BQU07RUFBRyxVQUFVO0VBQUcsV0FBVyxxQkFBcUIsU0FBUyx3QkFBd0I7RUFBTSxZQUFZLFVBQVU7R0FDNUosSUFBSSxNQUFNLFFBQVEsTUFBTTtJQUFFLE1BQU0sZUFBZTtJQUFHLGdCQUFnQjtHQUFFO0dBQ3BFLElBQUksTUFBTSxRQUFRLFVBQVU7SUFBRSxNQUFNLGVBQWU7SUFBRyxLQUFLLFdBQVc7R0FBRTtFQUN6RTtZQUhBLENBSUMsd0JBQUMsVUFBRDtHQUFRLE1BQUs7R0FBUyxXQUFXLGdCQUFnQixTQUFTLHdCQUF3QjtHQUFlO2FBQWpHLENBQ0Esd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBb0Isd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7R0FBTzs7OzthQUM1RCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUNDLHdCQUFDLFVBQUQsWUFBUyxVQUNSLHdCQUFDLFNBQUQ7S0FDQyxLQUFLO0tBQ0wsY0FBVztLQUNYLE9BQU87S0FDUCxXQUFXLFVBQVUsU0FBUyxNQUFNLE9BQU8sS0FBSztLQUNoRCxVQUFVLFVBQVUsTUFBTSxnQkFBZ0I7S0FDMUMsWUFBWSxVQUFVO01BQ3JCLE1BQU0sZ0JBQWdCO01BQ3RCLElBQUksTUFBTSxRQUFRLFNBQVMsVUFBVTtNQUNyQyxJQUFJLE1BQU0sUUFBUSxVQUFVLGlCQUFpQjtLQUM5QztJQUNBOzs7O2VBQ0UsS0FBSyxTQUFTLGdCQUFnQixTQUFTLGNBQWMsSUFDeEQ7S0FBRTtLQUFjLGlCQUFpQixNQUFNLEdBQUcsVUFBVTtLQUFFLHdCQUFDLFFBQUQsWUFBTyxpQkFBaUIsTUFBTSxZQUFZLGFBQWEsTUFBTSxNQUFNLEVBQVE7Ozs7O0tBQUUsaUJBQWlCLE1BQU0sYUFBYSxNQUFNLE1BQU07SUFBSTs7OztlQUNwTCxLQUFLLFNBQVMsZUFBZSxtQkFBbUIsS0FBSyxLQUFhOzs7O2NBQ3RFLHdCQUFDLFNBQUQsWUFBUSxjQUFxQjs7OztZQUN4Qjs7Ozs7V0FDRTs7Ozs7WUFDUCxDQUFDLFlBQVksb0JBQW9CLGFBQWEsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FDN0Msb0JBQW9CLHdCQUFDLFVBQUQ7SUFBUSxNQUFLO0lBQVMsY0FBWSxLQUFLLGFBQWEsd0JBQXdCO0lBQXVCLGVBQWUsS0FBSyxpQkFBaUI7Y0FBRyx3QkFBQyxNQUFEO0tBQU0sTUFBTTtLQUFJLE1BQU0sS0FBSyxhQUFhLGlCQUFpQjtJQUFTOzs7OztHQUFTOzs7O2FBQzFPLFlBQVksd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxjQUFXO0lBQTRCLGVBQWUsS0FBSyxTQUFTO2NBQUcsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7R0FBUzs7OztXQUNqSTs7Ozs7VUFDRjs7Ozs7O0FBRVAiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGlzdG9yeUl0ZW0udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZpbGVJbWFnZSwgRmlsZVNwcmVhZHNoZWV0LCBGaWxlVGV4dCwgTWVzc2FnZVNxdWFyZSwgU3RhciwgVHJhc2gyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBIaXN0b3J5RW50cnkgfSBmcm9tICcuLi90eXBlcydcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcblx0aXRlbTogSGlzdG9yeUVudHJ5XHJcblx0YWN0aXZlPzogYm9vbGVhblxyXG5cdHF1ZXJ5Pzogc3RyaW5nXHJcblx0ZWRpdGluZz86IGJvb2xlYW5cclxuXHRvbkNsaWNrOiAoKSA9PiB2b2lkXHJcblx0b25TdGFydFJlbmFtZT86ICgpID0+IHZvaWRcclxuXHRvblJlbmFtZT86ICh0aXRsZTogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+XHJcblx0b25DYW5jZWxSZW5hbWU/OiAoKSA9PiB2b2lkXHJcblx0b25Ub2dnbGVGYXZvcml0ZT86ICgpID0+IFByb21pc2U8dm9pZD5cclxuXHRvblJlbW92ZT86ICgpID0+IFByb21pc2U8dm9pZD5cclxufVxyXG5leHBvcnQgZnVuY3Rpb24gSGlzdG9yeUl0ZW0oeyBpdGVtLCBhY3RpdmUsIHF1ZXJ5ID0gJycsIGVkaXRpbmcgPSBmYWxzZSwgb25DbGljaywgb25TdGFydFJlbmFtZSwgb25SZW5hbWUsIG9uQ2FuY2VsUmVuYW1lLCBvblRvZ2dsZUZhdm9yaXRlLCBvblJlbW92ZSB9OiBQcm9wcykge1xyXG5cdGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoaXRlbS50aXRsZSA/PyBpdGVtLnF1ZXN0aW9uKVxyXG5cdGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpXHJcblx0Y29uc3QgZXh0ZW5zaW9uID0gaXRlbS5maWxlLnNwbGl0KCcuJykucG9wKCk/LnRvTG93ZXJDYXNlKClcclxuXHRjb25zdCBJY29uID0gaXRlbS5raW5kID09PSAnZGlzY3Vzc2lvbidcclxuXHRcdD8gTWVzc2FnZVNxdWFyZVxyXG5cdFx0OiBleHRlbnNpb24gPT09ICdwZGYnIHx8IGV4dGVuc2lvbiA9PT0gJ2RvYycgfHwgZXh0ZW5zaW9uID09PSAnZG9jeCdcclxuXHRcdFx0PyBGaWxlVGV4dFxyXG5cdFx0XHQ6IGV4dGVuc2lvbiA9PT0gJ3BuZycgfHwgZXh0ZW5zaW9uID09PSAnanBnJyB8fCBleHRlbnNpb24gPT09ICdqcGVnJ1xyXG5cdFx0XHRcdD8gRmlsZUltYWdlXHJcblx0XHRcdFx0OiBGaWxlU3ByZWFkc2hlZXRcclxuXHJcblx0dXNlRWZmZWN0KCgpID0+IHtcclxuXHRcdGlmIChlZGl0aW5nKSB7XHJcblx0XHRcdHNldFRpdGxlKGl0ZW0udGl0bGUgPz8gaXRlbS5xdWVzdGlvbilcclxuXHRcdFx0aW5wdXRSZWYuY3VycmVudD8uZm9jdXMoKVxyXG5cdFx0XHRpbnB1dFJlZi5jdXJyZW50Py5zZWxlY3QoKVxyXG5cdFx0fVxyXG5cdH0sIFtlZGl0aW5nLCBpdGVtLnF1ZXN0aW9uLCBpdGVtLnRpdGxlXSlcclxuXHJcblx0Y29uc3Qgc2F2ZVRpdGxlID0gKCkgPT4ge1xyXG5cdFx0Y29uc3QgbmV4dFRpdGxlID0gdGl0bGUudHJpbSgpXHJcblx0XHRpZiAobmV4dFRpdGxlICYmIG5leHRUaXRsZSAhPT0gKGl0ZW0udGl0bGUgPz8gaXRlbS5xdWVzdGlvbikpIHZvaWQgb25SZW5hbWU/LihuZXh0VGl0bGUpXHJcblx0XHRvbkNhbmNlbFJlbmFtZT8uKClcclxuXHR9XHJcblx0Y29uc3QgaGlnaGxpZ2h0ZWRUaXRsZSA9IGl0ZW0udGl0bGUgPz8gaXRlbS5xdWVzdGlvblxyXG5cdGNvbnN0IHF1ZXJ5SW5kZXggPSBxdWVyeSA/IGhpZ2hsaWdodGVkVGl0bGUudG9Mb2NhbGVMb3dlckNhc2UoKS5pbmRleE9mKHF1ZXJ5LnRvTG9jYWxlTG93ZXJDYXNlKCkpIDogLTFcclxuXHRjb25zdCBmb3JtYXR0ZWREYXRlID0gTnVtYmVyLmlzRmluaXRlKERhdGUucGFyc2UoaXRlbS5kYXRlKSlcclxuXHRcdD8gbmV3IERhdGUoaXRlbS5kYXRlKS50b0xvY2FsZVN0cmluZygnZnItRlInLCB7IGRhdGVTdHlsZTogJ3Nob3J0JywgdGltZVN0eWxlOiAnc2hvcnQnIH0pXHJcblx0XHQ6IGl0ZW0uZGF0ZVxyXG5cclxuXHRyZXR1cm4gKFxyXG5cdFx0PGRpdiByb2xlPVwib3B0aW9uXCIgYXJpYS1zZWxlY3RlZD17Qm9vbGVhbihhY3RpdmUpfSB0YWJJbmRleD17MH0gY2xhc3NOYW1lPXtgaGlzdG9yeS1pdGVtLXdyYXAgJHthY3RpdmUgPyAnaGlzdG9yeS1pdGVtLWFjdGl2ZScgOiAnJ31gfSBvbktleURvd249eyhldmVudCkgPT4ge1xyXG5cdFx0XHRpZiAoZXZlbnQua2V5ID09PSAnRjInKSB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IG9uU3RhcnRSZW5hbWU/LigpIH1cclxuXHRcdFx0aWYgKGV2ZW50LmtleSA9PT0gJ0RlbGV0ZScpIHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgdm9pZCBvblJlbW92ZT8uKCkgfVxyXG5cdFx0fX0+XHJcblx0XHRcdDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17YGhpc3RvcnktaXRlbSAke2FjdGl2ZSA/ICdoaXN0b3J5LWl0ZW0tYWN0aXZlJyA6ICcnfWB9IG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG5cdFx0XHQ8c3BhbiBjbGFzc05hbWU9XCJoaXN0b3J5LWZpbGUtaWNvblwiPjxJY29uIHNpemU9ezE1fSAvPjwvc3Bhbj5cclxuXHRcdFx0PHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCB0ZXh0LWxlZnRcIj5cclxuXHRcdFx0XHQ8c3Ryb25nPntlZGl0aW5nID8gKFxyXG5cdFx0XHRcdFx0PGlucHV0XHJcblx0XHRcdFx0XHRcdHJlZj17aW5wdXRSZWZ9XHJcblx0XHRcdFx0XHRcdGFyaWEtbGFiZWw9XCJOb3V2ZWF1IHRpdHJlXCJcclxuXHRcdFx0XHRcdFx0dmFsdWU9e3RpdGxlfVxyXG5cdFx0XHRcdFx0XHRvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRUaXRsZShldmVudC50YXJnZXQudmFsdWUpfVxyXG5cdFx0XHRcdFx0XHRvbkNsaWNrPXsoZXZlbnQpID0+IGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpfVxyXG5cdFx0XHRcdFx0XHRvbktleURvd249eyhldmVudCkgPT4ge1xyXG5cdFx0XHRcdFx0XHRcdGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpXHJcblx0XHRcdFx0XHRcdFx0aWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJykgc2F2ZVRpdGxlKClcclxuXHRcdFx0XHRcdFx0XHRpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykgb25DYW5jZWxSZW5hbWU/LigpXHJcblx0XHRcdFx0XHRcdH19XHJcblx0XHRcdFx0XHQvPlxyXG5cdFx0XHRcdCkgOiBpdGVtLmtpbmQgPT09ICdkaXNjdXNzaW9uJyAmJiBxdWVyeSAmJiBxdWVyeUluZGV4ID49IDAgPyAoXHJcblx0XHRcdFx0XHQ8PkRpc2N1c3Npb24gwrcge2hpZ2hsaWdodGVkVGl0bGUuc2xpY2UoMCwgcXVlcnlJbmRleCl9PG1hcms+e2hpZ2hsaWdodGVkVGl0bGUuc2xpY2UocXVlcnlJbmRleCwgcXVlcnlJbmRleCArIHF1ZXJ5Lmxlbmd0aCl9PC9tYXJrPntoaWdobGlnaHRlZFRpdGxlLnNsaWNlKHF1ZXJ5SW5kZXggKyBxdWVyeS5sZW5ndGgpfTwvPlxyXG5cdFx0XHRcdCkgOiBpdGVtLmtpbmQgPT09ICdkaXNjdXNzaW9uJyA/IGhpZ2hsaWdodGVkVGl0bGUgOiBpdGVtLmZpbGV9PC9zdHJvbmc+XHJcblx0XHRcdFx0PHNtYWxsPntmb3JtYXR0ZWREYXRlfTwvc21hbGw+XHJcblx0XHRcdDwvc3Bhbj5cclxuXHRcdFx0PC9idXR0b24+XHJcblx0XHRcdHshZWRpdGluZyAmJiAob25Ub2dnbGVGYXZvcml0ZSB8fCBvblJlbW92ZSkgJiYgPHNwYW4gY2xhc3NOYW1lPVwiaGlzdG9yeS1pdGVtLWFjdGlvbnNcIj5cclxuXHRcdFx0XHR7b25Ub2dnbGVGYXZvcml0ZSAmJiA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBhcmlhLWxhYmVsPXtpdGVtLmlzRmF2b3JpdGUgPyAnUmV0aXJlciBkZXMgZmF2b3JpcycgOiAnQWpvdXRlciBhdXggZmF2b3Jpcyd9IG9uQ2xpY2s9eygpID0+IHZvaWQgb25Ub2dnbGVGYXZvcml0ZSgpfT48U3RhciBzaXplPXsxNH0gZmlsbD17aXRlbS5pc0Zhdm9yaXRlID8gJ2N1cnJlbnRDb2xvcicgOiAnbm9uZSd9IC8+PC9idXR0b24+fVxyXG5cdFx0XHRcdHtvblJlbW92ZSAmJiA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBhcmlhLWxhYmVsPVwiU3VwcHJpbWVyIGRlIGzigJloaXN0b3JpcXVlXCIgb25DbGljaz17KCkgPT4gdm9pZCBvblJlbW92ZSgpfT48VHJhc2gyIHNpemU9ezE0fSAvPjwvYnV0dG9uPn1cclxuXHRcdFx0PC9zcGFuPn1cclxuXHRcdDwvZGl2PlxyXG5cdClcclxufSJdfQ==