import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ChatWindow.tsx");const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { ArrowDownUp, Bot, Check, Copy, LoaderCircle, MessageCircle, Paperclip, Send, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import { getApiError } from "/src/services/api.ts";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChatWindow.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const splitTableRow = (line) => line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((cell) => cell.trim());
function parseMarkdownTable(content) {
	const lines = content.split(/\r?\n/);
	for (let index = 1; index < lines.length; index += 1) {
		const divider = splitTableRow(lines[index]);
		if (divider.length < 2 || !divider.every((cell) => /^:?-{3,}:?$/.test(cell))) continue;
		if (!lines[index - 1].includes("|")) continue;
		const headers = splitTableRow(lines[index - 1]);
		const rows = [];
		let end = index + 1;
		while (end < lines.length && lines[end].includes("|")) {
			rows.push(splitTableRow(lines[end]));
			end += 1;
		}
		return {
			headers,
			rows,
			before: lines.slice(0, index - 1).join("\n").trim(),
			after: lines.slice(end).join("\n").trim()
		};
	}
	return null;
}
function AnswerText({ content }) {
	const lines = content.split(/\r?\n/);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "answer-text",
		children: lines.map((line, index) => {
			if (!line.trim()) return /* @__PURE__ */ _jsxDEV("div", { className: "answer-line-spacer" }, index, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 34
			}, this);
			const isListItem = /^\s*(?:[-*•]|\d+[.)])\s+/.test(line);
			const text = line.replace(/^\s*(?:[-*•]|\d+[.)])\s+/, "");
			const fragments = text.split(/(\*\*[^*]+\*\*|\b\d+(?:[.,]\d+)?(?:\s?(?:%|€|\$))?)/g);
			const formatted = fragments.map((fragment, fragmentIndex) => {
				if (fragment.startsWith("**") && fragment.endsWith("**")) {
					return /* @__PURE__ */ _jsxDEV("strong", { children: fragment.slice(2, -2) }, fragmentIndex, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 20
					}, this);
				}
				if (/^\d/.test(fragment)) {
					return /* @__PURE__ */ _jsxDEV("strong", {
						className: "answer-highlight",
						children: fragment
					}, fragmentIndex, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 20
					}, this);
				}
				return /* @__PURE__ */ _jsxDEV("span", { children: fragment }, fragmentIndex, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 18
				}, this);
			});
			return isListItem ? /* @__PURE__ */ _jsxDEV("div", {
				className: "answer-list-item",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": "true",
					children: "•"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 59
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: formatted }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 92
				}, this)]
			}, index, true, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV("p", { children: formatted }, index, false, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 13
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 5
	}, this);
}
_c = AnswerText;
function AssistantResponse({ message, onAsk }) {
	_s();
	const [sort, setSort] = useState(null);
	const [copied, setCopied] = useState(false);
	const table = parseMarkdownTable(message.content) ?? (message.resultTable ? {
		headers: message.resultTable.headers,
		rows: message.resultTable.rows,
		before: message.content,
		after: ""
	} : null);
	let chartConfig = null;
	try {
		chartConfig = message.chartConfig ? JSON.parse(message.chartConfig) : null;
	} catch {
		chartConfig = null;
	}
	const chartLabels = chartConfig && Array.isArray(chartConfig.labels) ? chartConfig.labels : [];
	const chartValues = chartConfig && Array.isArray(chartConfig.values) ? chartConfig.values : chartConfig?.series?.[0]?.values ?? [];
	const hasChart = Boolean(chartConfig && chartLabels.length > 0 && chartLabels.length === chartValues.length && chartValues.every((value) => Number.isFinite(value)));
	const maxChartValue = Math.max(...chartValues, 1);
	const rows = table ? [...table.rows] : [];
	if (table && sort) {
		rows.sort((left, right) => {
			const a = left[sort.column] ?? "";
			const b = right[sort.column] ?? "";
			const aNumber = Number(a.replace(/[\s,%€$]/g, "").replace(",", "."));
			const bNumber = Number(b.replace(/[\s,%€$]/g, "").replace(",", "."));
			const comparison = Number.isFinite(aNumber) && Number.isFinite(bNumber) ? aNumber - bNumber : a.localeCompare(b, "fr", {
				numeric: true,
				sensitivity: "base"
			});
			return sort.direction === "asc" ? comparison : -comparison;
		});
	}
	const copyAnswer = async () => {
		try {
			await navigator.clipboard.writeText(message.content);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1800);
		} catch {
			setCopied(false);
		}
	};
	const askFollowUp = () => {
		const excerpt = message.content.replace(/\s+/g, " ").slice(0, 350);
		onAsk(`Peux-tu approfondir ce résultat et expliquer les chiffres qui le justifient ? Réponse précédente : ${excerpt}`);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "assistant-response",
		children: [
			table ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				table.before && /* @__PURE__ */ _jsxDEV(AnswerText, { content: table.before }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 28
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "answer-table-scroll",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "answer-table",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: table.headers.map((header, index) => /* @__PURE__ */ _jsxDEV("th", {
							"aria-sort": sort?.column === index ? sort.direction === "asc" ? "ascending" : "descending" : "none",
							children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSort((current) => ({
									column: index,
									direction: current?.column === index && current.direction === "asc" ? "desc" : "asc"
								})),
								children: [header, /* @__PURE__ */ _jsxDEV(ArrowDownUp, { size: 13 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 23
							}, this)
						}, `${header}-${index}`, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 21
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: rows.map((row, rowIndex) => /* @__PURE__ */ _jsxDEV("tr", { children: table.headers.map((_, columnIndex) => /* @__PURE__ */ _jsxDEV("td", { children: row[columnIndex] ?? "" }, columnIndex, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 77
						}, this)) }, rowIndex, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 19
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 11
				}, this),
				table.after && /* @__PURE__ */ _jsxDEV(AnswerText, { content: table.after }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 27
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(AnswerText, { content: message.content }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 9
			}, this),
			hasChart && chartConfig && /* @__PURE__ */ _jsxDEV("div", {
				className: "message-chart",
				children: [/* @__PURE__ */ _jsxDEV("strong", { children: chartConfig.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 163,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "saved-chart",
					"aria-label": `Graphique de ${chartConfig.title}`,
					children: chartValues.map((value, index) => /* @__PURE__ */ _jsxDEV("div", {
						className: "saved-chart-bar",
						children: [/* @__PURE__ */ _jsxDEV("span", { style: { height: `${Math.max(value / maxChartValue * 100, 4)}%` } }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("small", { children: chartLabels[index] }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 17
						}, this)]
					}, `${chartLabels[index]}-${index}`, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 164,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 162,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "answer-actions",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void copyAnswer(),
					title: "Copier la réponse",
					children: [copied ? /* @__PURE__ */ _jsxDEV(Check, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 21
					}, this) : /* @__PURE__ */ _jsxDEV(Copy, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 43
					}, this), copied ? "Copié" : "Copier"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: askFollowUp,
					title: "Poser une question de suivi",
					children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 180,
						columnNumber: 11
					}, this), "Question de suivi"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 179,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 174,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 132,
		columnNumber: 5
	}, this);
}
_s(AssistantResponse, "3DBo8OGRz7GSOH5CDgcU61Mxb/w=");
_c2 = AssistantResponse;
export function ChatWindow({ messages, isAnalyzing, onAsk, onAddFiles }) {
	_s2();
	const fileInputRef = useRef(null);
	const [question, setQuestion] = useState("");
	const [addingFiles, setAddingFiles] = useState(false);
	const [fileError, setFileError] = useState("");
	const submit = () => {
		if (!question.trim() || isAnalyzing) return;
		onAsk(question.trim());
		setQuestion("");
	};
	const handleFiles = async (event) => {
		const files = Array.from(event.currentTarget.files ?? []);
		event.currentTarget.value = "";
		if (!files.length) return;
		setAddingFiles(true);
		setFileError("");
		try {
			await onAddFiles(files);
		} catch (error) {
			setFileError(getApiError(error));
		} finally {
			setAddingFiles(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "chat-section",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "chat-heading",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "section-kicker",
					children: "ÉTAPE 02"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Posez votre question" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 221,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "online-dot",
					children: "IA en ligne"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 223,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 218,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "messages",
				role: "log",
				"aria-live": "polite",
				children: [messages.map((message) => /* @__PURE__ */ _jsxDEV("div", {
					className: `message-row ${message.role === "user" ? "message-user" : ""}`,
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: `avatar ${message.role === "user" ? "avatar-user" : "avatar-ai"}`,
						children: message.role === "user" ? /* @__PURE__ */ _jsxDEV(UserRound, { size: 15 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 42
						}, this) : /* @__PURE__ */ _jsxDEV(Bot, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 68
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 228,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "message-content",
						children: [message.role === "assistant" ? /* @__PURE__ */ _jsxDEV(AssistantResponse, {
							message,
							onAsk
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "font-chat",
							children: message.content
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("time", { children: message.timestamp }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 235,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 231,
						columnNumber: 13
					}, this)]
				}, message.id, true, {
					fileName: _jsxFileName,
					lineNumber: 227,
					columnNumber: 11
				}, this)), isAnalyzing && /* @__PURE__ */ _jsxDEV("div", {
					className: "message-row analysis-loading-row",
					role: "status",
					"aria-label": "Analyse en cours",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "avatar avatar-ai",
						children: /* @__PURE__ */ _jsxDEV(LoaderCircle, {
							className: "analysis-spinner",
							size: 17
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 48
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 241,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "analysis-skeleton",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 225,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "prompt-box",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "icon-button chat-import-button",
						onClick: () => fileInputRef.current?.click(),
						disabled: addingFiles || isAnalyzing,
						"aria-label": "Importer un fichier dans cette analyse",
						title: "Importer CSV ou Excel dans cette analyse",
						children: /* @__PURE__ */ _jsxDEV(Paperclip, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						ref: fileInputRef,
						type: "file",
						accept: ".csv,.xls,.xlsx",
						multiple: true,
						hidden: true,
						onChange: (event) => void handleFiles(event)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						value: question,
						disabled: isAnalyzing,
						onChange: (event) => setQuestion(event.target.value),
						onKeyDown: (event) => {
							if (event.key === "Enter" && !event.shiftKey) {
								event.preventDefault();
								submit();
							}
						},
						placeholder: addingFiles ? "Import du fichier en cours..." : "Ex : Compare les performances par groupe...",
						rows: 1
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "send-button",
						"aria-label": "Analyser",
						onClick: submit,
						disabled: isAnalyzing || !question.trim(),
						children: /* @__PURE__ */ _jsxDEV(Send, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 276,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 250,
				columnNumber: 7
			}, this),
			fileError && /* @__PURE__ */ _jsxDEV("div", {
				className: "error-banner",
				children: fileError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 279,
				columnNumber: 21
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "prompt-hint",
				children: "Appuyez sur Entrée pour envoyer · Les analyses sont générées à partir de vos données"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 217,
		columnNumber: 5
	}, this);
}
_s2(ChatWindow, "vB8iFfTgrHFoXKmktD36zwUkZQQ=");
_c3 = ChatWindow;
var _c, _c2, _c3;
$RefreshReg$(_c, "AnswerText");
$RefreshReg$(_c2, "AssistantResponse");
$RefreshReg$(_c3, "ChatWindow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ChatWindow.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChatWindow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChatWindow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/ChatWindow.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLEtBQUssT0FBTyxNQUFNLGNBQWMsZUFBZSxXQUFXLE1BQU0saUJBQWlCO0FBQ3ZHLFNBQVMsUUFBUSxnQkFBa0M7QUFDbkQsU0FBUyxtQkFBbUI7Ozs7QUFpQjVCLE1BQU0saUJBQWlCLFNBQ3JCLEtBQUssS0FBSyxDQUFDLENBQUMsUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFFBQVEsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssU0FBUyxLQUFLLEtBQUssQ0FBQztBQUV4RixTQUFTLG1CQUFtQixTQUFxQztDQUMvRCxNQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU87Q0FDbkMsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLE1BQU0sUUFBUSxTQUFTLEdBQUc7RUFDcEQsTUFBTSxVQUFVLGNBQWMsTUFBTSxNQUFNO0VBQzFDLElBQUksUUFBUSxTQUFTLEtBQUssQ0FBQyxRQUFRLE9BQU8sU0FBUyxjQUFjLEtBQUssSUFBSSxDQUFDLEdBQUc7RUFDOUUsSUFBSSxDQUFDLE1BQU0sUUFBUSxFQUFFLENBQUMsU0FBUyxHQUFHLEdBQUc7RUFFckMsTUFBTSxVQUFVLGNBQWMsTUFBTSxRQUFRLEVBQUU7RUFDOUMsTUFBTSxPQUFtQixDQUFDO0VBQzFCLElBQUksTUFBTSxRQUFRO0VBQ2xCLE9BQU8sTUFBTSxNQUFNLFVBQVUsTUFBTSxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUc7R0FDckQsS0FBSyxLQUFLLGNBQWMsTUFBTSxJQUFJLENBQUM7R0FDbkMsT0FBTztFQUNUO0VBQ0EsT0FBTztHQUNMO0dBQ0E7R0FDQSxRQUFRLE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLO0dBQ2xELE9BQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSztFQUMxQztDQUNGO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEVBQUUsV0FBZ0M7Q0FDcEQsTUFBTSxRQUFRLFFBQVEsTUFBTSxPQUFPO0NBQ25DLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDWixNQUFNLEtBQUssTUFBTSxVQUFVO0dBQzFCLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRyxPQUFPLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFCQUFrQyxHQUFSOzs7O1VBQVE7R0FDMUUsTUFBTSxhQUFhLDJCQUEyQixLQUFLLElBQUk7R0FDdkQsTUFBTSxPQUFPLEtBQUssUUFBUSw0QkFBNEIsRUFBRTtHQUN4RCxNQUFNLFlBQVksS0FBSyxNQUFNLHNEQUFzRDtHQUNuRixNQUFNLFlBQVksVUFBVSxLQUFLLFVBQVUsa0JBQWtCO0lBQzNELElBQUksU0FBUyxXQUFXLElBQUksS0FBSyxTQUFTLFNBQVMsSUFBSSxHQUFHO0tBQ3hELE9BQU8sd0JBQUMsVUFBRCxZQUE2QixTQUFTLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBVSxHQUE5Qzs7OztZQUE4QztJQUNwRTtJQUNBLElBQUksTUFBTSxLQUFLLFFBQVEsR0FBRztLQUN4QixPQUFPLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO2dCQUF3QztLQUFpQixHQUFqQzs7OztZQUFpQztJQUNwRjtJQUNBLE9BQU8sd0JBQUMsUUFBRCxZQUEyQixTQUFlLEdBQS9COzs7O1dBQStCO0dBQ25ELENBQUM7R0FDRCxPQUFPLGFBQ0gsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUE4Qyx3QkFBQyxRQUFEO0tBQU0sZUFBWTtlQUFPO0lBQU87Ozs7Y0FBQyx3QkFBQyxPQUFELFlBQU0sVUFBZTs7OztZQUFNO01BQW5FOzs7O1VBQW1FLElBQzFHLHdCQUFDLEtBQUQsWUFBZ0IsVUFBYSxHQUFyQjs7OztVQUFxQjtFQUNuQyxDQUFDO0NBQ0U7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxrQkFBa0IsRUFBRSxTQUFTLFNBQWtFOztDQUN0RyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQStELElBQUk7Q0FDM0YsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxRQUFRLG1CQUFtQixRQUFRLE9BQU8sTUFBTSxRQUFRLGNBQzFEO0VBQ0UsU0FBUyxRQUFRLFlBQVk7RUFDN0IsTUFBTSxRQUFRLFlBQVk7RUFDMUIsUUFBUSxRQUFRO0VBQ2hCLE9BQU87Q0FDVCxJQUNBO0NBQ0osSUFBSSxjQUFrQztDQUN0QyxJQUFJO0VBQ0YsY0FBYyxRQUFRLGNBQWMsS0FBSyxNQUFNLFFBQVEsV0FBVyxJQUFtQjtDQUN2RixRQUFRO0VBQ04sY0FBYztDQUNoQjtDQUNBLE1BQU0sY0FBYyxlQUFlLE1BQU0sUUFBUSxZQUFZLE1BQU0sSUFBSSxZQUFZLFNBQVMsQ0FBQztDQUM3RixNQUFNLGNBQWMsZUFBZSxNQUFNLFFBQVEsWUFBWSxNQUFNLElBQy9ELFlBQVksU0FDWixhQUFhLFNBQVMsRUFBRSxFQUFFLFVBQVUsQ0FBQztDQUN6QyxNQUFNLFdBQVcsUUFDZixlQUNHLFlBQVksU0FBUyxLQUNyQixZQUFZLFdBQVcsWUFBWSxVQUNuQyxZQUFZLE9BQU8sVUFBVSxPQUFPLFNBQVMsS0FBSyxDQUFDLENBQ3hEO0NBQ0EsTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLEdBQUcsYUFBYSxDQUFDO0NBQ2hELE1BQU0sT0FBTyxRQUFRLENBQUMsR0FBRyxNQUFNLElBQUksSUFBSSxDQUFDO0NBRXhDLElBQUksU0FBUyxNQUFNO0VBQ2pCLEtBQUssTUFBTSxNQUFNLFVBQVU7R0FDekIsTUFBTSxJQUFJLEtBQUssS0FBSyxXQUFXO0dBQy9CLE1BQU0sSUFBSSxNQUFNLEtBQUssV0FBVztHQUNoQyxNQUFNLFVBQVUsT0FBTyxFQUFFLFFBQVEsYUFBYSxFQUFFLENBQUMsQ0FBQyxRQUFRLEtBQUssR0FBRyxDQUFDO0dBQ25FLE1BQU0sVUFBVSxPQUFPLEVBQUUsUUFBUSxhQUFhLEVBQUUsQ0FBQyxDQUFDLFFBQVEsS0FBSyxHQUFHLENBQUM7R0FDbkUsTUFBTSxhQUFhLE9BQU8sU0FBUyxPQUFPLEtBQUssT0FBTyxTQUFTLE9BQU8sSUFDbEUsVUFBVSxVQUNWLEVBQUUsY0FBYyxHQUFHLE1BQU07SUFBRSxTQUFTO0lBQU0sYUFBYTtHQUFPLENBQUM7R0FDbkUsT0FBTyxLQUFLLGNBQWMsUUFBUSxhQUFhLENBQUM7RUFDbEQsQ0FBQztDQUNIO0NBRUEsTUFBTSxhQUFhLFlBQVk7RUFDN0IsSUFBSTtHQUNGLE1BQU0sVUFBVSxVQUFVLFVBQVUsUUFBUSxPQUFPO0dBQ25ELFVBQVUsSUFBSTtHQUNkLE9BQU8saUJBQWlCLFVBQVUsS0FBSyxHQUFHLElBQUk7RUFDaEQsUUFBUTtHQUNOLFVBQVUsS0FBSztFQUNqQjtDQUNGO0NBRUEsTUFBTSxvQkFBb0I7RUFDeEIsTUFBTSxVQUFVLFFBQVEsUUFBUSxRQUFRLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUc7RUFDakUsTUFBTSxzR0FBc0csU0FBUztDQUN2SDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNHLFFBQ0M7SUFDRyxNQUFNLFVBQVUsd0JBQUMsWUFBRCxFQUFZLFNBQVMsTUFBTSxPQUFTOzs7OztJQUNyRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFELFlBQ0csTUFBTSxRQUFRLEtBQUssUUFBUSxVQUMxQix3QkFBQyxNQUFEO09BQStCLGFBQVcsTUFBTSxXQUFXLFFBQVMsS0FBSyxjQUFjLFFBQVEsY0FBYyxlQUFnQjtpQkFDM0gsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxlQUFlLFNBQVMsYUFBYTtTQUFFLFFBQVE7U0FBTyxXQUFXLFNBQVMsV0FBVyxTQUFTLFFBQVEsY0FBYyxRQUFRLFNBQVM7UUFBTSxFQUFFO2tCQUFuSyxDQUNHLFFBQU8sd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztnQkFDMUI7Ozs7OztNQUNOLEdBSkssR0FBRyxPQUFPLEdBQUc7Ozs7YUFJbEIsQ0FDTCxFQUNDOzs7O2VBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRCxZQUNHLEtBQUssS0FBSyxLQUFLLGFBQ2Qsd0JBQUMsTUFBRCxZQUFvQixNQUFNLFFBQVEsS0FBSyxHQUFHLGdCQUFnQix3QkFBQyxNQUFELFlBQXVCLElBQUksZ0JBQWdCLEdBQU8sR0FBekM7Ozs7YUFBeUMsQ0FBQyxFQUFNLEdBQTFHOzs7O2FBQTBHLENBQ3BILEVBQ0k7Ozs7Y0FDRjs7Ozs7O0lBQ0o7Ozs7O0lBQ0osTUFBTSxTQUFTLHdCQUFDLFlBQUQsRUFBWSxTQUFTLE1BQU0sTUFBUTs7Ozs7R0FDbkQ7Ozs7Y0FFRix3QkFBQyxZQUFELEVBQVksU0FBUyxRQUFRLFFBQVU7Ozs7O0dBRXhDLFlBQVksZUFDWCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRCxZQUFTLFlBQVksTUFBYzs7OztjQUNuQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFjLGNBQVksZ0JBQWdCLFlBQVk7ZUFDbEUsWUFBWSxLQUFLLE9BQU8sVUFDdkIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sT0FBTyxFQUFFLFFBQVEsR0FBRyxLQUFLLElBQUssUUFBUSxnQkFBaUIsS0FBSyxDQUFDLEVBQUUsR0FBRyxFQUFJOzs7O2dCQUM1RSx3QkFBQyxTQUFELFlBQVEsWUFBWSxPQUFjOzs7O2NBQy9CO1FBSGlDLEdBQUcsWUFBWSxPQUFPLEdBQUc7Ozs7WUFHMUQsQ0FDTjtJQUNFOzs7O1lBQ0Y7Ozs7OztHQUVQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLGVBQWUsS0FBSyxXQUFXO0tBQUcsT0FBTTtlQUE5RCxDQUNHLFNBQVMsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztnQkFBSSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2VBQ2hELFNBQVMsVUFBVSxRQUNkOzs7OztjQUNSLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsU0FBUztLQUFhLE9BQU07ZUFBbEQsQ0FDRSx3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7O2VBQUMsbUJBRXJCOzs7OztZQUNMOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7OztBQUVBLE9BQU8sU0FBUyxXQUFXLEVBQUUsVUFBVSxhQUFhLE9BQU8sY0FBcUI7O0NBQzlFLE1BQU0sZUFBZSxPQUF5QixJQUFJO0NBQ2xELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUU3QyxNQUFNLGVBQWU7RUFDbkIsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLGFBQWE7RUFDckMsTUFBTSxTQUFTLEtBQUssQ0FBQztFQUNyQixZQUFZLEVBQUU7Q0FDaEI7Q0FFQSxNQUFNLGNBQWMsT0FBTyxVQUF5QztFQUNsRSxNQUFNLFFBQVEsTUFBTSxLQUFLLE1BQU0sY0FBYyxTQUFTLENBQUMsQ0FBQztFQUN4RCxNQUFNLGNBQWMsUUFBUTtFQUM1QixJQUFJLENBQUMsTUFBTSxRQUFRO0VBRW5CLGVBQWUsSUFBSTtFQUNuQixhQUFhLEVBQUU7RUFDZixJQUFJO0dBQ0YsTUFBTSxXQUFXLEtBQUs7RUFDeEIsU0FBUyxPQUFPO0dBQ2QsYUFBYSxZQUFZLEtBQUssQ0FBQztFQUNqQyxVQUFVO0dBQ1IsZUFBZSxLQUFLO0VBQ3RCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFpQjtJQUFjOzs7O2NBQy9DLHdCQUFDLE1BQUQsWUFBSSx1QkFBd0I7Ozs7WUFDekI7Ozs7Y0FDTCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhO0lBQWlCOzs7O1lBQzNDOzs7Ozs7R0FDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFXLE1BQUs7SUFBTSxhQUFVO2NBQS9DLENBQ0csU0FBUyxLQUFLLFlBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVcsZUFBZSxRQUFRLFNBQVMsU0FBUyxpQkFBaUI7ZUFBMUUsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVyxVQUFVLFFBQVEsU0FBUyxTQUFTLGdCQUFnQjtnQkFDbEUsUUFBUSxTQUFTLFNBQVMsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztpQkFBSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7OztLQUNqRTs7OztlQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0csUUFBUSxTQUFTLGNBQ2Qsd0JBQUMsbUJBQUQ7T0FBNEI7T0FBZ0I7TUFBUTs7OztpQkFDcEQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWEsUUFBUTtNQUFXOzs7O2dCQUNqRCx3QkFBQyxRQUFELFlBQU8sUUFBUSxVQUFnQjs7OztjQUM1Qjs7Ozs7YUFDRjtPQVZnRixRQUFROzs7O1dBVXhGLENBQ04sR0FDQSxlQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQW1DLE1BQUs7S0FBUyxjQUFXO2VBQTNFLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1CLHdCQUFDLGNBQUQ7T0FBYyxXQUFVO09BQW1CLE1BQU07TUFBSzs7Ozs7S0FBTzs7OztlQUNoRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQsQ0FBTzs7Ozs7T0FDUCx3QkFBQyxRQUFELENBQU87Ozs7O09BQ1Asd0JBQUMsUUFBRCxDQUFPOzs7OztNQUNKOzs7OzthQUNGOzs7OztZQUVKOzs7Ozs7R0FDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFBZSxhQUFhLFNBQVMsTUFBTTtNQUMzQyxVQUFVLGVBQWU7TUFDekIsY0FBVztNQUNYLE9BQU07Z0JBRU4sd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7S0FDaEI7Ozs7O0tBQ1Isd0JBQUMsU0FBRDtNQUFPLEtBQUs7TUFBYyxNQUFLO01BQU8sUUFBTztNQUFrQjtNQUFTO01BQU8sV0FBVyxVQUFVLEtBQUssWUFBWSxLQUFLO0tBQUk7Ozs7O0tBQzlILHdCQUFDLFlBQUQ7TUFDRSxPQUFPO01BQ1AsVUFBVTtNQUNWLFdBQVcsVUFBVSxZQUFZLE1BQU0sT0FBTyxLQUFLO01BQ25ELFlBQVksVUFBVTtPQUNwQixJQUFJLE1BQU0sUUFBUSxXQUFXLENBQUMsTUFBTSxVQUFVO1FBQzVDLE1BQU0sZUFBZTtRQUNyQixPQUFPO09BQ1Q7TUFDRjtNQUNBLGFBQWEsY0FBYyxrQ0FBa0M7TUFDN0QsTUFBTTtLQUNQOzs7OztLQUNELHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQWMsY0FBVztNQUFXLFNBQVM7TUFBUSxVQUFVLGVBQWUsQ0FBQyxTQUFTLEtBQUs7Z0JBQzdHLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O0tBQ1g7Ozs7O0lBQ0w7Ozs7OztHQUNKLGFBQWEsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZ0I7R0FBZTs7Ozs7R0FDNUQsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYztHQUF1Rjs7Ozs7RUFDM0c7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoYXRXaW5kb3cudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFycm93RG93blVwLCBCb3QsIENoZWNrLCBDb3B5LCBMb2FkZXJDaXJjbGUsIE1lc3NhZ2VDaXJjbGUsIFBhcGVyY2xpcCwgU2VuZCwgVXNlclJvdW5kIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlLCB0eXBlIENoYW5nZUV2ZW50IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGdldEFwaUVycm9yIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpJ1xyXG5pbXBvcnQgdHlwZSB7IENoYXJ0Q29uZmlnLCBNZXNzYWdlIH0gZnJvbSAnLi4vdHlwZXMnXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIG1lc3NhZ2VzOiBNZXNzYWdlW11cclxuICBpc0FuYWx5emluZzogYm9vbGVhblxyXG4gIG9uQXNrOiAocXVlc3Rpb246IHN0cmluZykgPT4gdm9pZFxyXG4gIG9uQWRkRmlsZXM6IChmaWxlczogRmlsZVtdKSA9PiBQcm9taXNlPHZvaWQ+XHJcbn1cclxuXHJcbnR5cGUgUGFyc2VkVGFibGUgPSB7XHJcbiAgaGVhZGVyczogc3RyaW5nW11cclxuICByb3dzOiBzdHJpbmdbXVtdXHJcbiAgYmVmb3JlOiBzdHJpbmdcclxuICBhZnRlcjogc3RyaW5nXHJcbn1cclxuXHJcbmNvbnN0IHNwbGl0VGFibGVSb3cgPSAobGluZTogc3RyaW5nKSA9PlxyXG4gIGxpbmUudHJpbSgpLnJlcGxhY2UoL15cXHwvLCAnJykucmVwbGFjZSgvXFx8JC8sICcnKS5zcGxpdCgnfCcpLm1hcCgoY2VsbCkgPT4gY2VsbC50cmltKCkpXHJcblxyXG5mdW5jdGlvbiBwYXJzZU1hcmtkb3duVGFibGUoY29udGVudDogc3RyaW5nKTogUGFyc2VkVGFibGUgfCBudWxsIHtcclxuICBjb25zdCBsaW5lcyA9IGNvbnRlbnQuc3BsaXQoL1xccj9cXG4vKVxyXG4gIGZvciAobGV0IGluZGV4ID0gMTsgaW5kZXggPCBsaW5lcy5sZW5ndGg7IGluZGV4ICs9IDEpIHtcclxuICAgIGNvbnN0IGRpdmlkZXIgPSBzcGxpdFRhYmxlUm93KGxpbmVzW2luZGV4XSlcclxuICAgIGlmIChkaXZpZGVyLmxlbmd0aCA8IDIgfHwgIWRpdmlkZXIuZXZlcnkoKGNlbGwpID0+IC9eOj8tezMsfTo/JC8udGVzdChjZWxsKSkpIGNvbnRpbnVlXHJcbiAgICBpZiAoIWxpbmVzW2luZGV4IC0gMV0uaW5jbHVkZXMoJ3wnKSkgY29udGludWVcclxuXHJcbiAgICBjb25zdCBoZWFkZXJzID0gc3BsaXRUYWJsZVJvdyhsaW5lc1tpbmRleCAtIDFdKVxyXG4gICAgY29uc3Qgcm93czogc3RyaW5nW11bXSA9IFtdXHJcbiAgICBsZXQgZW5kID0gaW5kZXggKyAxXHJcbiAgICB3aGlsZSAoZW5kIDwgbGluZXMubGVuZ3RoICYmIGxpbmVzW2VuZF0uaW5jbHVkZXMoJ3wnKSkge1xyXG4gICAgICByb3dzLnB1c2goc3BsaXRUYWJsZVJvdyhsaW5lc1tlbmRdKSlcclxuICAgICAgZW5kICs9IDFcclxuICAgIH1cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGhlYWRlcnMsXHJcbiAgICAgIHJvd3MsXHJcbiAgICAgIGJlZm9yZTogbGluZXMuc2xpY2UoMCwgaW5kZXggLSAxKS5qb2luKCdcXG4nKS50cmltKCksXHJcbiAgICAgIGFmdGVyOiBsaW5lcy5zbGljZShlbmQpLmpvaW4oJ1xcbicpLnRyaW0oKSxcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG51bGxcclxufVxyXG5cclxuZnVuY3Rpb24gQW5zd2VyVGV4dCh7IGNvbnRlbnQgfTogeyBjb250ZW50OiBzdHJpbmcgfSkge1xyXG4gIGNvbnN0IGxpbmVzID0gY29udGVudC5zcGxpdCgvXFxyP1xcbi8pXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5zd2VyLXRleHRcIj5cclxuICAgICAge2xpbmVzLm1hcCgobGluZSwgaW5kZXgpID0+IHtcclxuICAgICAgICBpZiAoIWxpbmUudHJpbSgpKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJhbnN3ZXItbGluZS1zcGFjZXJcIiBrZXk9e2luZGV4fSAvPlxyXG4gICAgICAgIGNvbnN0IGlzTGlzdEl0ZW0gPSAvXlxccyooPzpbLSrigKJdfFxcZCtbLildKVxccysvLnRlc3QobGluZSlcclxuICAgICAgICBjb25zdCB0ZXh0ID0gbGluZS5yZXBsYWNlKC9eXFxzKig/OlstKuKAol18XFxkK1suKV0pXFxzKy8sICcnKVxyXG4gICAgICAgIGNvbnN0IGZyYWdtZW50cyA9IHRleHQuc3BsaXQoLyhcXCpcXCpbXipdK1xcKlxcKnxcXGJcXGQrKD86Wy4sXVxcZCspPyg/Olxccz8oPzolfOKCrHxcXCQpKT8pL2cpXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gZnJhZ21lbnRzLm1hcCgoZnJhZ21lbnQsIGZyYWdtZW50SW5kZXgpID0+IHtcclxuICAgICAgICAgIGlmIChmcmFnbWVudC5zdGFydHNXaXRoKCcqKicpICYmIGZyYWdtZW50LmVuZHNXaXRoKCcqKicpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiA8c3Ryb25nIGtleT17ZnJhZ21lbnRJbmRleH0+e2ZyYWdtZW50LnNsaWNlKDIsIC0yKX08L3N0cm9uZz5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmICgvXlxcZC8udGVzdChmcmFnbWVudCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIDxzdHJvbmcgY2xhc3NOYW1lPVwiYW5zd2VyLWhpZ2hsaWdodFwiIGtleT17ZnJhZ21lbnRJbmRleH0+e2ZyYWdtZW50fTwvc3Ryb25nPlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIDxzcGFuIGtleT17ZnJhZ21lbnRJbmRleH0+e2ZyYWdtZW50fTwvc3Bhbj5cclxuICAgICAgICB9KVxyXG4gICAgICAgIHJldHVybiBpc0xpc3RJdGVtXHJcbiAgICAgICAgICA/IDxkaXYgY2xhc3NOYW1lPVwiYW5zd2VyLWxpc3QtaXRlbVwiIGtleT17aW5kZXh9PjxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKAojwvc3Bhbj48ZGl2Pntmb3JtYXR0ZWR9PC9kaXY+PC9kaXY+XHJcbiAgICAgICAgICA6IDxwIGtleT17aW5kZXh9Pntmb3JtYXR0ZWR9PC9wPlxyXG4gICAgICB9KX1cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gQXNzaXN0YW50UmVzcG9uc2UoeyBtZXNzYWdlLCBvbkFzayB9OiB7IG1lc3NhZ2U6IE1lc3NhZ2U7IG9uQXNrOiAocXVlc3Rpb246IHN0cmluZykgPT4gdm9pZCB9KSB7XHJcbiAgY29uc3QgW3NvcnQsIHNldFNvcnRdID0gdXNlU3RhdGU8eyBjb2x1bW46IG51bWJlcjsgZGlyZWN0aW9uOiAnYXNjJyB8ICdkZXNjJyB9IHwgbnVsbD4obnVsbClcclxuICBjb25zdCBbY29waWVkLCBzZXRDb3BpZWRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgdGFibGUgPSBwYXJzZU1hcmtkb3duVGFibGUobWVzc2FnZS5jb250ZW50KSA/PyAobWVzc2FnZS5yZXN1bHRUYWJsZVxyXG4gICAgPyB7XHJcbiAgICAgICAgaGVhZGVyczogbWVzc2FnZS5yZXN1bHRUYWJsZS5oZWFkZXJzLFxyXG4gICAgICAgIHJvd3M6IG1lc3NhZ2UucmVzdWx0VGFibGUucm93cyxcclxuICAgICAgICBiZWZvcmU6IG1lc3NhZ2UuY29udGVudCxcclxuICAgICAgICBhZnRlcjogJycsXHJcbiAgICAgIH1cclxuICAgIDogbnVsbClcclxuICBsZXQgY2hhcnRDb25maWc6IENoYXJ0Q29uZmlnIHwgbnVsbCA9IG51bGxcclxuICB0cnkge1xyXG4gICAgY2hhcnRDb25maWcgPSBtZXNzYWdlLmNoYXJ0Q29uZmlnID8gSlNPTi5wYXJzZShtZXNzYWdlLmNoYXJ0Q29uZmlnKSBhcyBDaGFydENvbmZpZyA6IG51bGxcclxuICB9IGNhdGNoIHtcclxuICAgIGNoYXJ0Q29uZmlnID0gbnVsbFxyXG4gIH1cclxuICBjb25zdCBjaGFydExhYmVscyA9IGNoYXJ0Q29uZmlnICYmIEFycmF5LmlzQXJyYXkoY2hhcnRDb25maWcubGFiZWxzKSA/IGNoYXJ0Q29uZmlnLmxhYmVscyA6IFtdXHJcbiAgY29uc3QgY2hhcnRWYWx1ZXMgPSBjaGFydENvbmZpZyAmJiBBcnJheS5pc0FycmF5KGNoYXJ0Q29uZmlnLnZhbHVlcylcclxuICAgID8gY2hhcnRDb25maWcudmFsdWVzXHJcbiAgICA6IGNoYXJ0Q29uZmlnPy5zZXJpZXM/LlswXT8udmFsdWVzID8/IFtdXHJcbiAgY29uc3QgaGFzQ2hhcnQgPSBCb29sZWFuKFxyXG4gICAgY2hhcnRDb25maWdcclxuICAgICYmIGNoYXJ0TGFiZWxzLmxlbmd0aCA+IDBcclxuICAgICYmIGNoYXJ0TGFiZWxzLmxlbmd0aCA9PT0gY2hhcnRWYWx1ZXMubGVuZ3RoXHJcbiAgICAmJiBjaGFydFZhbHVlcy5ldmVyeSgodmFsdWUpID0+IE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkpLFxyXG4gIClcclxuICBjb25zdCBtYXhDaGFydFZhbHVlID0gTWF0aC5tYXgoLi4uY2hhcnRWYWx1ZXMsIDEpXHJcbiAgY29uc3Qgcm93cyA9IHRhYmxlID8gWy4uLnRhYmxlLnJvd3NdIDogW11cclxuXHJcbiAgaWYgKHRhYmxlICYmIHNvcnQpIHtcclxuICAgIHJvd3Muc29ydCgobGVmdCwgcmlnaHQpID0+IHtcclxuICAgICAgY29uc3QgYSA9IGxlZnRbc29ydC5jb2x1bW5dID8/ICcnXHJcbiAgICAgIGNvbnN0IGIgPSByaWdodFtzb3J0LmNvbHVtbl0gPz8gJydcclxuICAgICAgY29uc3QgYU51bWJlciA9IE51bWJlcihhLnJlcGxhY2UoL1tcXHMsJeKCrCRdL2csICcnKS5yZXBsYWNlKCcsJywgJy4nKSlcclxuICAgICAgY29uc3QgYk51bWJlciA9IE51bWJlcihiLnJlcGxhY2UoL1tcXHMsJeKCrCRdL2csICcnKS5yZXBsYWNlKCcsJywgJy4nKSlcclxuICAgICAgY29uc3QgY29tcGFyaXNvbiA9IE51bWJlci5pc0Zpbml0ZShhTnVtYmVyKSAmJiBOdW1iZXIuaXNGaW5pdGUoYk51bWJlcilcclxuICAgICAgICA/IGFOdW1iZXIgLSBiTnVtYmVyXHJcbiAgICAgICAgOiBhLmxvY2FsZUNvbXBhcmUoYiwgJ2ZyJywgeyBudW1lcmljOiB0cnVlLCBzZW5zaXRpdml0eTogJ2Jhc2UnIH0pXHJcbiAgICAgIHJldHVybiBzb3J0LmRpcmVjdGlvbiA9PT0gJ2FzYycgPyBjb21wYXJpc29uIDogLWNvbXBhcmlzb25cclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBjb25zdCBjb3B5QW5zd2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQobWVzc2FnZS5jb250ZW50KVxyXG4gICAgICBzZXRDb3BpZWQodHJ1ZSlcclxuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkKGZhbHNlKSwgMTgwMClcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBzZXRDb3BpZWQoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBhc2tGb2xsb3dVcCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGV4Y2VycHQgPSBtZXNzYWdlLmNvbnRlbnQucmVwbGFjZSgvXFxzKy9nLCAnICcpLnNsaWNlKDAsIDM1MClcclxuICAgIG9uQXNrKGBQZXV4LXR1IGFwcHJvZm9uZGlyIGNlIHLDqXN1bHRhdCBldCBleHBsaXF1ZXIgbGVzIGNoaWZmcmVzIHF1aSBsZSBqdXN0aWZpZW50ID8gUsOpcG9uc2UgcHLDqWPDqWRlbnRlIDogJHtleGNlcnB0fWApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhc3Npc3RhbnQtcmVzcG9uc2VcIj5cclxuICAgICAge3RhYmxlID8gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7dGFibGUuYmVmb3JlICYmIDxBbnN3ZXJUZXh0IGNvbnRlbnQ9e3RhYmxlLmJlZm9yZX0gLz59XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuc3dlci10YWJsZS1zY3JvbGxcIj5cclxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cImFuc3dlci10YWJsZVwiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAge3RhYmxlLmhlYWRlcnMubWFwKChoZWFkZXIsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17YCR7aGVhZGVyfS0ke2luZGV4fWB9IGFyaWEtc29ydD17c29ydD8uY29sdW1uID09PSBpbmRleCA/IChzb3J0LmRpcmVjdGlvbiA9PT0gJ2FzYycgPyAnYXNjZW5kaW5nJyA6ICdkZXNjZW5kaW5nJykgOiAnbm9uZSd9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U29ydCgoY3VycmVudCkgPT4gKHsgY29sdW1uOiBpbmRleCwgZGlyZWN0aW9uOiBjdXJyZW50Py5jb2x1bW4gPT09IGluZGV4ICYmIGN1cnJlbnQuZGlyZWN0aW9uID09PSAnYXNjJyA/ICdkZXNjJyA6ICdhc2MnIH0pKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWFkZXJ9PEFycm93RG93blVwIHNpemU9ezEzfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAge3Jvd3MubWFwKChyb3csIHJvd0luZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT57dGFibGUuaGVhZGVycy5tYXAoKF8sIGNvbHVtbkluZGV4KSA9PiA8dGQga2V5PXtjb2x1bW5JbmRleH0+e3Jvd1tjb2x1bW5JbmRleF0gPz8gJyd9PC90ZD4pfTwvdHI+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7dGFibGUuYWZ0ZXIgJiYgPEFuc3dlclRleHQgY29udGVudD17dGFibGUuYWZ0ZXJ9IC8+fVxyXG4gICAgICAgIDwvPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxBbnN3ZXJUZXh0IGNvbnRlbnQ9e21lc3NhZ2UuY29udGVudH0gLz5cclxuICAgICAgKX1cclxuICAgICAge2hhc0NoYXJ0ICYmIGNoYXJ0Q29uZmlnICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2UtY2hhcnRcIj5cclxuICAgICAgICAgIDxzdHJvbmc+e2NoYXJ0Q29uZmlnLnRpdGxlfTwvc3Ryb25nPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1jaGFydFwiIGFyaWEtbGFiZWw9e2BHcmFwaGlxdWUgZGUgJHtjaGFydENvbmZpZy50aXRsZX1gfT5cclxuICAgICAgICAgICAge2NoYXJ0VmFsdWVzLm1hcCgodmFsdWUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYXZlZC1jaGFydC1iYXJcIiBrZXk9e2Ake2NoYXJ0TGFiZWxzW2luZGV4XX0tJHtpbmRleH1gfT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGhlaWdodDogYCR7TWF0aC5tYXgoKHZhbHVlIC8gbWF4Q2hhcnRWYWx1ZSkgKiAxMDAsIDQpfSVgIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8c21hbGw+e2NoYXJ0TGFiZWxzW2luZGV4XX08L3NtYWxsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuc3dlci1hY3Rpb25zXCI+XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCBjb3B5QW5zd2VyKCl9IHRpdGxlPVwiQ29waWVyIGxhIHLDqXBvbnNlXCI+XHJcbiAgICAgICAgICB7Y29waWVkID8gPENoZWNrIHNpemU9ezE0fSAvPiA6IDxDb3B5IHNpemU9ezE0fSAvPn1cclxuICAgICAgICAgIHtjb3BpZWQgPyAnQ29wacOpJyA6ICdDb3BpZXInfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2Fza0ZvbGxvd1VwfSB0aXRsZT1cIlBvc2VyIHVuZSBxdWVzdGlvbiBkZSBzdWl2aVwiPlxyXG4gICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICBRdWVzdGlvbiBkZSBzdWl2aVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIENoYXRXaW5kb3coeyBtZXNzYWdlcywgaXNBbmFseXppbmcsIG9uQXNrLCBvbkFkZEZpbGVzIH06IFByb3BzKSB7XHJcbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpXHJcbiAgY29uc3QgW3F1ZXN0aW9uLCBzZXRRdWVzdGlvbl0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbYWRkaW5nRmlsZXMsIHNldEFkZGluZ0ZpbGVzXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtmaWxlRXJyb3IsIHNldEZpbGVFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gKCkgPT4ge1xyXG4gICAgaWYgKCFxdWVzdGlvbi50cmltKCkgfHwgaXNBbmFseXppbmcpIHJldHVyblxyXG4gICAgb25Bc2socXVlc3Rpb24udHJpbSgpKVxyXG4gICAgc2V0UXVlc3Rpb24oJycpXHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlcyA9IGFzeW5jIChldmVudDogQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcclxuICAgIGNvbnN0IGZpbGVzID0gQXJyYXkuZnJvbShldmVudC5jdXJyZW50VGFyZ2V0LmZpbGVzID8/IFtdKVxyXG4gICAgZXZlbnQuY3VycmVudFRhcmdldC52YWx1ZSA9ICcnXHJcbiAgICBpZiAoIWZpbGVzLmxlbmd0aCkgcmV0dXJuXHJcblxyXG4gICAgc2V0QWRkaW5nRmlsZXModHJ1ZSlcclxuICAgIHNldEZpbGVFcnJvcignJylcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IG9uQWRkRmlsZXMoZmlsZXMpXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRGaWxlRXJyb3IoZ2V0QXBpRXJyb3IoZXJyb3IpKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0QWRkaW5nRmlsZXMoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2hhdC1zZWN0aW9uXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhdC1oZWFkaW5nXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlY3Rpb24ta2lja2VyXCI+w4lUQVBFIDAyPC9zcGFuPlxyXG4gICAgICAgICAgPGgyPlBvc2V6IHZvdHJlIHF1ZXN0aW9uPC9oMj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJvbmxpbmUtZG90XCI+SUEgZW4gbGlnbmU8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2VzXCIgcm9sZT1cImxvZ1wiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxyXG4gICAgICAgIHttZXNzYWdlcy5tYXAoKG1lc3NhZ2UpID0+IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgbWVzc2FnZS1yb3cgJHttZXNzYWdlLnJvbGUgPT09ICd1c2VyJyA/ICdtZXNzYWdlLXVzZXInIDogJyd9YH0ga2V5PXttZXNzYWdlLmlkfT5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgYXZhdGFyICR7bWVzc2FnZS5yb2xlID09PSAndXNlcicgPyAnYXZhdGFyLXVzZXInIDogJ2F2YXRhci1haSd9YH0+XHJcbiAgICAgICAgICAgICAge21lc3NhZ2Uucm9sZSA9PT0gJ3VzZXInID8gPFVzZXJSb3VuZCBzaXplPXsxNX0gLz4gOiA8Qm90IHNpemU9ezE3fSAvPn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2UtY29udGVudFwiPlxyXG4gICAgICAgICAgICAgIHttZXNzYWdlLnJvbGUgPT09ICdhc3Npc3RhbnQnXHJcbiAgICAgICAgICAgICAgICA/IDxBc3Npc3RhbnRSZXNwb25zZSBtZXNzYWdlPXttZXNzYWdlfSBvbkFzaz17b25Bc2t9IC8+XHJcbiAgICAgICAgICAgICAgICA6IDxwIGNsYXNzTmFtZT1cImZvbnQtY2hhdFwiPnttZXNzYWdlLmNvbnRlbnR9PC9wPn1cclxuICAgICAgICAgICAgICA8dGltZT57bWVzc2FnZS50aW1lc3RhbXB9PC90aW1lPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIHtpc0FuYWx5emluZyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2Utcm93IGFuYWx5c2lzLWxvYWRpbmctcm93XCIgcm9sZT1cInN0YXR1c1wiIGFyaWEtbGFiZWw9XCJBbmFseXNlIGVuIGNvdXJzXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImF2YXRhciBhdmF0YXItYWlcIj48TG9hZGVyQ2lyY2xlIGNsYXNzTmFtZT1cImFuYWx5c2lzLXNwaW5uZXJcIiBzaXplPXsxN30gLz48L3NwYW4+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5hbHlzaXMtc2tlbGV0b25cIj5cclxuICAgICAgICAgICAgICA8c3BhbiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9tcHQtYm94XCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpY29uLWJ1dHRvbiBjaGF0LWltcG9ydC1idXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XHJcbiAgICAgICAgICBkaXNhYmxlZD17YWRkaW5nRmlsZXMgfHwgaXNBbmFseXppbmd9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiSW1wb3J0ZXIgdW4gZmljaGllciBkYW5zIGNldHRlIGFuYWx5c2VcIlxyXG4gICAgICAgICAgdGl0bGU9XCJJbXBvcnRlciBDU1Ygb3UgRXhjZWwgZGFucyBjZXR0ZSBhbmFseXNlXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8UGFwZXJjbGlwIHNpemU9ezE3fSAvPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxpbnB1dCByZWY9e2ZpbGVJbnB1dFJlZn0gdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCIuY3N2LC54bHMsLnhsc3hcIiBtdWx0aXBsZSBoaWRkZW4gb25DaGFuZ2U9eyhldmVudCkgPT4gdm9pZCBoYW5kbGVGaWxlcyhldmVudCl9IC8+XHJcbiAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICB2YWx1ZT17cXVlc3Rpb259XHJcbiAgICAgICAgICBkaXNhYmxlZD17aXNBbmFseXppbmd9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRRdWVzdGlvbihldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgb25LZXlEb3duPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJyAmJiAhZXZlbnQuc2hpZnRLZXkpIHtcclxuICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgICAgICAgc3VibWl0KClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIHBsYWNlaG9sZGVyPXthZGRpbmdGaWxlcyA/ICdJbXBvcnQgZHUgZmljaGllciBlbiBjb3Vycy4uLicgOiAnRXggOiBDb21wYXJlIGxlcyBwZXJmb3JtYW5jZXMgcGFyIGdyb3VwZS4uLid9XHJcbiAgICAgICAgICByb3dzPXsxfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJzZW5kLWJ1dHRvblwiIGFyaWEtbGFiZWw9XCJBbmFseXNlclwiIG9uQ2xpY2s9e3N1Ym1pdH0gZGlzYWJsZWQ9e2lzQW5hbHl6aW5nIHx8ICFxdWVzdGlvbi50cmltKCl9PlxyXG4gICAgICAgICAgPFNlbmQgc2l6ZT17MTd9IC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7ZmlsZUVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3ItYmFubmVyXCI+e2ZpbGVFcnJvcn08L2Rpdj59XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInByb21wdC1oaW50XCI+QXBwdXlleiBzdXIgRW50csOpZSBwb3VyIGVudm95ZXIgwrcgTGVzIGFuYWx5c2VzIHNvbnQgZ8OpbsOpcsOpZXMgw6AgcGFydGlyIGRlIHZvcyBkb25uw6llczwvcD5cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn0iXX0=