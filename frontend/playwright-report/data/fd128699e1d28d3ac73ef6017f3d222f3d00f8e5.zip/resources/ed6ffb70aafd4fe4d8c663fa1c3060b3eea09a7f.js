import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SettingsPage.tsx");const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const useEffect = __vite__cjsImport2_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import { ArrowLeft, Camera, Check, LockKeyhole, Save, Trash2, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import { getApiError } from "/src/services/api.ts";
import { deleteAccount as deleteAccountRequest, getProfile, updateProfile } from "/src/services/authService.ts";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/SettingsPage.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$();
const MAX_FILE_SIZE = 2 * 1024 * 1024;
export function SettingsPage({ initialName, profilePhoto, onBack, onSaveName, onSavePhoto, onAccountDeleted }) {
	_s();
	const photoInput = useRef(null);
	const [name, setName] = useState(initialName);
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [passwordConfirmation, setPasswordConfirmation] = useState("");
	const [photo, setPhoto] = useState(profilePhoto);
	const [saved, setSaved] = useState(false);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [photoError, setPhotoError] = useState("");
	const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
	const [deletePassword, setDeletePassword] = useState("");
	const [deleteConfirmation, setDeleteConfirmation] = useState("");
	const [deletingAccount, setDeletingAccount] = useState(false);
	useEffect(() => {
		getProfile().then((profile) => {
			setName(profile.name);
			setEmail(profile.email);
			if (profilePhoto) setPhoto(profilePhoto);
		}).catch((profileError) => setError(getApiError(profileError))).finally(() => setLoading(false));
	}, [profilePhoto]);
	const choosePhoto = (file) => {
		setPhotoError("");
		if (!file) return;
		const allowedTypes = ["image/jpeg", "image/png"];
		if (!allowedTypes.includes(file.type)) {
			setPhotoError("Le fichier doit être une image au format JPG ou PNG.");
			return;
		}
		if (file.size > MAX_FILE_SIZE) {
			setPhotoError("La photo doit faire 2 Mo maximum.");
			return;
		}
		const reader = new FileReader();
		reader.onload = () => {
			const result = typeof reader.result === "string" ? reader.result : "";
			setPhoto(result);
			setSaved(false);
		};
		reader.readAsDataURL(file);
	};
	const save = async () => {
		setError("");
		setPhotoError("");
		if (password && password !== passwordConfirmation) {
			setError("Les mots de passe ne correspondent pas.");
			return;
		}
		try {
			const profile = await updateProfile({
				name: name.trim() || initialName,
				email,
				profile_photo: photo,
				...password ? { password } : {}
			});
			onSaveName(profile.name);
			onSavePhoto(profile.profile_photo ?? "");
			setName(profile.name);
			setPassword("");
			setPasswordConfirmation("");
			setSaved(true);
			setTimeout(() => setSaved(false), 2500);
		} catch (saveError) {
			setError(getApiError(saveError));
		}
	};
	const confirmDeleteAccount = async () => {
		setError("");
		if (deleteConfirmation !== "SUPPRIMER") {
			setError("Saisissez SUPPRIMER pour confirmer la suppression définitive.");
			return;
		}
		if (!deletePassword) {
			setError("Saisissez votre mot de passe actuel pour confirmer.");
			return;
		}
		setDeletingAccount(true);
		try {
			const result = await deleteAccountRequest(deletePassword);
			onAccountDeleted(result.files_cleanup_pending);
		} catch (deleteError) {
			setError(getApiError(deleteError));
		} finally {
			setDeletingAccount(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "settings-page",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "settings-page-inner",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					className: "settings-back",
					onClick: onBack,
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 60
					}, this), " Retour à l’analyse"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "settings-heading",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "workspace-kicker",
							children: "COMPTE UTILISATEUR"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 16
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", { children: "Paramètres du profil" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 76
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Gérez vos informations personnelles et vos préférences." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 105
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "primary-button save-top",
						onClick: () => void save(),
						disabled: loading || deletingAccount,
						children: saved ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 24
						}, this), " Enregistré"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 22
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
							/* @__PURE__ */ _jsxDEV(Save, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 62
							}, this),
							" ",
							loading ? "Chargement..." : "Enregistrer"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 60
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("div", {
					className: "error-banner settings-error",
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 19
				}, this),
				photoError && /* @__PURE__ */ _jsxDEV("div", {
					className: "error-banner settings-error",
					role: "alert",
					children: photoError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 24
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "settings-layout",
					children: [/* @__PURE__ */ _jsxDEV("section", {
						className: "settings-card profile-card",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "settings-card-heading",
								children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "section-kicker",
									children: "VOTRE PROFIL"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 57
								}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Informations personnelles" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 109
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 52
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "profile-photo-row",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `profile-photo ${photo ? "profile-photo-filled" : ""}`,
									children: photo ? /* @__PURE__ */ _jsxDEV("img", {
										src: photo,
										alt: "Photo de profil"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 96
									}, this) : /* @__PURE__ */ _jsxDEV(UserRound, { size: 30 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 140
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: "Photo de profil" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "JPG ou PNG, 2 Mo maximum." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 49
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										ref: photoInput,
										type: "file",
										accept: "image/png,image/jpeg",
										hidden: true,
										onChange: (event) => {
											const file = event.target.files?.[0];
											choosePhoto(file);
											if (event.target) event.target.value = "";
										}
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "photo-button",
										onClick: () => photoInput.current?.click(),
										children: [/* @__PURE__ */ _jsxDEV(Camera, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 140,
											columnNumber: 94
										}, this), " Changer la photo"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Nom complet", /* @__PURE__ */ _jsxDEV("input", {
								value: name,
								onChange: (event) => {
									setName(event.target.value);
									setSaved(false);
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 31
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Email professionnel", /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								value: email,
								onChange: (event) => {
									setEmail(event.target.value);
									setSaved(false);
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 39
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("section", {
						className: "settings-card",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "settings-card-heading",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "section-kicker",
									children: "SÉCURITÉ"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 57
								}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Modifier le mot de passe" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 105
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 52
								}, this), /* @__PURE__ */ _jsxDEV(LockKeyhole, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 144
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Mot de passe actuel", /* @__PURE__ */ _jsxDEV("input", {
								type: "password",
								placeholder: "••••••••"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 39
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Nouveau mot de passe", /* @__PURE__ */ _jsxDEV("input", {
								type: "password",
								value: password,
								onChange: (event) => setPassword(event.target.value),
								placeholder: "••••••••"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 40
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Confirmer le nouveau mot de passe", /* @__PURE__ */ _jsxDEV("input", {
								type: "password",
								value: passwordConfirmation,
								onChange: (event) => setPasswordConfirmation(event.target.value),
								placeholder: "••••••••"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 53
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "password-hint",
								children: "Utilisez au moins 8 caractères avec un mélange de lettres et de chiffres."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "settings-card danger-zone",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "settings-card-heading",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "section-kicker danger-kicker",
								children: "ZONE DANGEREUSE"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 55
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Supprimer mon compte" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 124
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 50
							}, this), /* @__PURE__ */ _jsxDEV(Trash2, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 159
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "La suppression est définitive. Votre profil, vos analyses, votre historique et tous vos fichiers importés seront supprimés." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 11
						}, this),
						!showDeleteConfirmation ? /* @__PURE__ */ _jsxDEV("button", {
							className: "danger-button",
							type: "button",
							onClick: () => {
								setError("");
								setShowDeleteConfirmation(true);
							},
							children: [/* @__PURE__ */ _jsxDEV(Trash2, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 15
							}, this), " Supprimer mon compte"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "delete-account-confirmation",
							children: [
								/* @__PURE__ */ _jsxDEV("label", { children: ["Mot de passe actuel", /* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									value: deletePassword,
									onChange: (event) => setDeletePassword(event.target.value),
									autoComplete: "current-password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 41
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("label", { children: ["Saisissez SUPPRIMER pour confirmer", /* @__PURE__ */ _jsxDEV("input", {
									value: deleteConfirmation,
									onChange: (event) => setDeleteConfirmation(event.target.value),
									autoComplete: "off"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 56
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "delete-account-actions",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										className: "settings-back",
										type: "button",
										onClick: () => {
											setShowDeleteConfirmation(false);
											setDeletePassword("");
											setDeleteConfirmation("");
											setError("");
										},
										disabled: deletingAccount,
										children: "Annuler"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										className: "danger-button",
										type: "button",
										onClick: () => void confirmDeleteAccount(),
										disabled: deletingAccount || loading,
										children: [
											/* @__PURE__ */ _jsxDEV(Trash2, { size: 16 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 168,
												columnNumber: 19
											}, this),
											" ",
											deletingAccount ? "Suppression..." : "Confirmer la suppression"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 122,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 121,
		columnNumber: 5
	}, this);
}
_s(SettingsPage, "ugXWBXhZtd5eXZxZw9KjUGbyUGQ=");
_c = SettingsPage;
var _c;
$RefreshReg$(_c, "SettingsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SettingsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/SettingsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/SettingsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/SettingsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsT0FBTyxhQUFhLE1BQU0sUUFBUSxpQkFBaUI7QUFDL0UsU0FBUyxRQUFRLGdCQUFnQjtBQUNqQyxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGlCQUFpQixzQkFBc0IsWUFBWSxxQkFBcUI7Ozs7QUFXakYsTUFBTSxnQkFBZ0IsSUFBSSxPQUFPO0FBRWpDLE9BQU8sU0FBUyxhQUFhLEVBQUUsYUFBYSxjQUFjLFFBQVEsWUFBWSxhQUFhLG9CQUEyQjs7Q0FDcEgsTUFBTSxhQUFhLE9BQXlCLElBQUk7Q0FDaEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLFdBQVc7Q0FDNUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFO0NBQ25FLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxZQUFZO0NBQy9DLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxLQUFLO0NBQ3hDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxLQUFLO0NBQzFFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBRTVELGdCQUFnQjtFQUNkLFdBQVcsQ0FBQyxDQUNULE1BQU0sWUFBWTtHQUNqQixRQUFRLFFBQVEsSUFBSTtHQUNwQixTQUFTLFFBQVEsS0FBSztHQUN0QixJQUFJLGNBQWMsU0FBUyxZQUFZO0VBQ3pDLENBQUMsQ0FBQyxDQUNELE9BQU8saUJBQWlCLFNBQVMsWUFBWSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQzVELGNBQWMsV0FBVyxLQUFLLENBQUM7Q0FDcEMsR0FBRyxDQUFDLFlBQVksQ0FBQztDQUVqQixNQUFNLGVBQWUsU0FBZ0I7RUFDbkMsY0FBYyxFQUFFO0VBQ2hCLElBQUksQ0FBQyxNQUFNO0VBRVgsTUFBTSxlQUFlLENBQUMsY0FBYyxXQUFXO0VBQy9DLElBQUksQ0FBQyxhQUFhLFNBQVMsS0FBSyxJQUFJLEdBQUc7R0FDckMsY0FBYyxzREFBc0Q7R0FDcEU7RUFDRjtFQUVBLElBQUksS0FBSyxPQUFPLGVBQWU7R0FDN0IsY0FBYyxtQ0FBbUM7R0FDakQ7RUFDRjtFQUVBLE1BQU0sU0FBUyxJQUFJLFdBQVc7RUFDOUIsT0FBTyxlQUFlO0dBQ3BCLE1BQU0sU0FBUyxPQUFPLE9BQU8sV0FBVyxXQUFXLE9BQU8sU0FBUztHQUNuRSxTQUFTLE1BQU07R0FDZixTQUFTLEtBQUs7RUFDaEI7RUFDQSxPQUFPLGNBQWMsSUFBSTtDQUMzQjtDQUVBLE1BQU0sT0FBTyxZQUFZO0VBQ3ZCLFNBQVMsRUFBRTtFQUNYLGNBQWMsRUFBRTtFQUVoQixJQUFJLFlBQVksYUFBYSxzQkFBc0I7R0FDakQsU0FBUyx5Q0FBeUM7R0FDbEQ7RUFDRjtFQUVBLElBQUk7R0FDRixNQUFNLFVBQVUsTUFBTSxjQUFjO0lBQ2xDLE1BQU0sS0FBSyxLQUFLLEtBQUs7SUFDckI7SUFDQSxlQUFlO0lBQ2YsR0FBSSxXQUFXLEVBQUUsU0FBUyxJQUFJLENBQUM7R0FDakMsQ0FBQztHQUVELFdBQVcsUUFBUSxJQUFJO0dBQ3ZCLFlBQVksUUFBUSxpQkFBaUIsRUFBRTtHQUN2QyxRQUFRLFFBQVEsSUFBSTtHQUNwQixZQUFZLEVBQUU7R0FDZCx3QkFBd0IsRUFBRTtHQUMxQixTQUFTLElBQUk7R0FDYixpQkFBaUIsU0FBUyxLQUFLLEdBQUcsSUFBSTtFQUN4QyxTQUFTLFdBQVc7R0FDbEIsU0FBUyxZQUFZLFNBQVMsQ0FBQztFQUNqQztDQUNGO0NBRUEsTUFBTSx1QkFBdUIsWUFBWTtFQUN2QyxTQUFTLEVBQUU7RUFDWCxJQUFJLHVCQUF1QixhQUFhO0dBQ3RDLFNBQVMsK0RBQStEO0dBQ3hFO0VBQ0Y7RUFDQSxJQUFJLENBQUMsZ0JBQWdCO0dBQ25CLFNBQVMscURBQXFEO0dBQzlEO0VBQ0Y7RUFFQSxtQkFBbUIsSUFBSTtFQUN2QixJQUFJO0dBQ0YsTUFBTSxTQUFTLE1BQU0scUJBQXFCLGNBQWM7R0FDeEQsaUJBQWlCLE9BQU8scUJBQXFCO0VBQy9DLFNBQVMsYUFBYTtHQUNwQixTQUFTLFlBQVksV0FBVyxDQUFDO0VBQ25DLFVBQVU7R0FDUixtQkFBbUIsS0FBSztFQUMxQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFnQixTQUFTO2VBQTNDLENBQW1ELHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7ZUFBQyxxQkFBMkI7Ozs7OztJQUNyRyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQjtNQUF3Qjs7Ozs7TUFBQyx3QkFBQyxNQUFELFlBQUksdUJBQXdCOzs7OztNQUFDLHdCQUFDLEtBQUQsWUFBRywwREFBMEQ7Ozs7O0tBQU07Ozs7ZUFDakssd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBMEIsZUFBZSxLQUFLLEtBQUs7TUFBRyxVQUFVLFdBQVc7Z0JBQzFGLFFBQVEsZ0RBQUUsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztnQkFBQyxhQUFhOzs7O2lCQUFJO09BQUUsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7T0FBQztPQUFFLFVBQVUsa0JBQWtCO01BQWdCOzs7OztLQUMzRzs7OzthQUNMOzs7Ozs7SUFDSixTQUFTLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQThCLE1BQUs7ZUFBUztJQUFXOzs7OztJQUMvRSxjQUFjLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQThCLE1BQUs7ZUFBUztJQUFnQjs7Ozs7SUFDMUYsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF3Qix3QkFBQyxPQUFELGFBQUssd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQWtCOzs7O2tCQUFDLHdCQUFDLE1BQUQsWUFBSSw0QkFBNkI7Ozs7Z0JBQU07Ozs7O09BQU07Ozs7O09BQzdJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVcsaUJBQWlCLFFBQVEseUJBQXlCO21CQUFPLFFBQVEsd0JBQUMsT0FBRDtVQUFLLEtBQUs7VUFBTyxLQUFJO1NBQW1COzs7O29CQUFJLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O1FBQU87Ozs7a0JBQzFKLHdCQUFDLE9BQUQ7U0FDRSx3QkFBQyxVQUFELFlBQVEsa0JBQXVCOzs7OztTQUFDLHdCQUFDLEtBQUQsWUFBRyw0QkFBNEI7Ozs7O1NBQy9ELHdCQUFDLFNBQUQ7VUFBTyxLQUFLO1VBQVksTUFBSztVQUFPLFFBQU87VUFBdUI7VUFBTyxXQUFXLFVBQVU7V0FBRSxNQUFNLE9BQU8sTUFBTSxPQUFPLFFBQVE7V0FBSSxZQUFZLElBQUk7V0FBRyxJQUFJLE1BQU0sUUFBUSxNQUFNLE9BQU8sUUFBUTtVQUFHO1NBQUk7Ozs7O1NBQ3ZNLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO1VBQWUsZUFBZSxXQUFXLFNBQVMsTUFBTTtvQkFBMUUsQ0FBNkUsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztvQkFBQyxtQkFBeUI7Ozs7OztRQUN2SDs7OztnQkFDRjs7Ozs7O09BQ0wsd0JBQUMsU0FBRCxhQUFPLGVBQVcsd0JBQUMsU0FBRDtRQUFPLE9BQU87UUFBTSxXQUFXLFVBQVU7U0FBRSxRQUFRLE1BQU0sT0FBTyxLQUFLO1NBQUcsU0FBUyxLQUFLO1FBQUU7T0FBSTs7OztlQUFROzs7OztPQUN0SCx3QkFBQyxTQUFELGFBQU8sdUJBQW1CLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQVEsT0FBTztRQUFPLFdBQVcsVUFBVTtTQUFFLFNBQVMsTUFBTSxPQUFPLEtBQUs7U0FBRyxTQUFTLEtBQUs7UUFBRTtPQUFJOzs7O2VBQVE7Ozs7O01BQ3RJOzs7OztlQUNULHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQXVDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBYzs7OztrQkFBQyx3QkFBQyxNQUFELFlBQUksMkJBQTRCOzs7O2dCQUFNOzs7O2tCQUFDLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7Z0JBQU07Ozs7OztPQUNqSyx3QkFBQyxTQUFELGFBQU8sdUJBQW1CLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQVcsYUFBWTtPQUFZOzs7O2VBQVE7Ozs7O09BQ2pGLHdCQUFDLFNBQUQsYUFBTyx3QkFBb0Isd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBVyxPQUFPO1FBQVUsV0FBVyxVQUFVLFlBQVksTUFBTSxPQUFPLEtBQUs7UUFBRyxhQUFZO09BQVk7Ozs7ZUFBUTs7Ozs7T0FDekosd0JBQUMsU0FBRCxhQUFPLHFDQUFpQyx3QkFBQyxTQUFEO1FBQU8sTUFBSztRQUFXLE9BQU87UUFBc0IsV0FBVyxVQUFVLHdCQUF3QixNQUFNLE9BQU8sS0FBSztRQUFHLGFBQVk7T0FBWTs7OztlQUFROzs7OztPQUM5TCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBZ0I7T0FBNEU7Ozs7O01BQ2xHOzs7OzthQUNOOzs7Ozs7SUFDTCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXVDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBK0I7T0FBcUI7Ozs7aUJBQUMsd0JBQUMsTUFBRCxZQUFJLHVCQUF3Qjs7OztlQUFNOzs7O2lCQUFDLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7ZUFBTTs7Ozs7O01BQzdLLHdCQUFDLEtBQUQsWUFBRyw4SEFBOEg7Ozs7O01BQ2hJLENBQUMseUJBQ0Esd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBZ0IsTUFBSztPQUFTLGVBQWU7UUFBRSxTQUFTLEVBQUU7UUFBRywwQkFBMEIsSUFBSTtPQUFFO2lCQUEvRyxDQUNFLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7aUJBQUMsdUJBQ2Q7Ozs7O2lCQUVSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsU0FBRCxhQUFPLHVCQUFtQix3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFXLE9BQU87U0FBZ0IsV0FBVyxVQUFVLGtCQUFrQixNQUFNLE9BQU8sS0FBSztTQUFHLGNBQWE7UUFBb0I7Ozs7Z0JBQVE7Ozs7O1FBQzdLLHdCQUFDLFNBQUQsYUFBTyxzQ0FBa0Msd0JBQUMsU0FBRDtTQUFPLE9BQU87U0FBb0IsV0FBVyxVQUFVLHNCQUFzQixNQUFNLE9BQU8sS0FBSztTQUFHLGNBQWE7UUFBTzs7OztnQkFBUTs7Ozs7UUFDdkssd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFnQixNQUFLO1VBQVMsZUFBZTtXQUFFLDBCQUEwQixLQUFLO1dBQUcsa0JBQWtCLEVBQUU7V0FBRyxzQkFBc0IsRUFBRTtXQUFHLFNBQVMsRUFBRTtVQUFFO1VBQUcsVUFBVTtvQkFBaUI7U0FBZTs7OzttQkFDL00sd0JBQUMsVUFBRDtVQUFRLFdBQVU7VUFBZ0IsTUFBSztVQUFTLGVBQWUsS0FBSyxxQkFBcUI7VUFBRyxVQUFVLG1CQUFtQjtvQkFBekg7V0FDRSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztXQUFDO1dBQUUsa0JBQWtCLG1CQUFtQjtVQUNyRDs7Ozs7aUJBQ0w7Ozs7OztPQUNGOzs7Ozs7S0FFQTs7Ozs7O0dBQ047Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNldHRpbmdzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJyb3dMZWZ0LCBDYW1lcmEsIENoZWNrLCBMb2NrS2V5aG9sZSwgU2F2ZSwgVHJhc2gyLCBVc2VyUm91bmQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGdldEFwaUVycm9yIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpJ1xyXG5pbXBvcnQgeyBkZWxldGVBY2NvdW50IGFzIGRlbGV0ZUFjY291bnRSZXF1ZXN0LCBnZXRQcm9maWxlLCB1cGRhdGVQcm9maWxlIH0gZnJvbSAnLi4vc2VydmljZXMvYXV0aFNlcnZpY2UnXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIGluaXRpYWxOYW1lOiBzdHJpbmdcclxuICBwcm9maWxlUGhvdG86IHN0cmluZ1xyXG4gIG9uQmFjazogKCkgPT4gdm9pZFxyXG4gIG9uU2F2ZU5hbWU6IChuYW1lOiBzdHJpbmcpID0+IHZvaWRcclxuICBvblNhdmVQaG90bzogKHBob3RvOiBzdHJpbmcpID0+IHZvaWRcclxuICBvbkFjY291bnREZWxldGVkOiAoZmlsZXNDbGVhbnVwUGVuZGluZzogbnVtYmVyKSA9PiB2b2lkXHJcbn1cclxuXHJcbmNvbnN0IE1BWF9GSUxFX1NJWkUgPSAyICogMTAyNCAqIDEwMjRcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTZXR0aW5nc1BhZ2UoeyBpbml0aWFsTmFtZSwgcHJvZmlsZVBob3RvLCBvbkJhY2ssIG9uU2F2ZU5hbWUsIG9uU2F2ZVBob3RvLCBvbkFjY291bnREZWxldGVkIH06IFByb3BzKSB7XHJcbiAgY29uc3QgcGhvdG9JbnB1dCA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKVxyXG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKGluaXRpYWxOYW1lKVxyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbcGFzc3dvcmRDb25maXJtYXRpb24sIHNldFBhc3N3b3JkQ29uZmlybWF0aW9uXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtwaG90bywgc2V0UGhvdG9dID0gdXNlU3RhdGUocHJvZmlsZVBob3RvKVxyXG4gIGNvbnN0IFtzYXZlZCwgc2V0U2F2ZWRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtwaG90b0Vycm9yLCBzZXRQaG90b0Vycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtzaG93RGVsZXRlQ29uZmlybWF0aW9uLCBzZXRTaG93RGVsZXRlQ29uZmlybWF0aW9uXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtkZWxldGVQYXNzd29yZCwgc2V0RGVsZXRlUGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2RlbGV0ZUNvbmZpcm1hdGlvbiwgc2V0RGVsZXRlQ29uZmlybWF0aW9uXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtkZWxldGluZ0FjY291bnQsIHNldERlbGV0aW5nQWNjb3VudF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGdldFByb2ZpbGUoKVxyXG4gICAgICAudGhlbigocHJvZmlsZSkgPT4ge1xyXG4gICAgICAgIHNldE5hbWUocHJvZmlsZS5uYW1lKVxyXG4gICAgICAgIHNldEVtYWlsKHByb2ZpbGUuZW1haWwpXHJcbiAgICAgICAgaWYgKHByb2ZpbGVQaG90bykgc2V0UGhvdG8ocHJvZmlsZVBob3RvKVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKHByb2ZpbGVFcnJvcikgPT4gc2V0RXJyb3IoZ2V0QXBpRXJyb3IocHJvZmlsZUVycm9yKSkpXHJcbiAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxyXG4gIH0sIFtwcm9maWxlUGhvdG9dKVxyXG5cclxuICBjb25zdCBjaG9vc2VQaG90byA9IChmaWxlPzogRmlsZSkgPT4ge1xyXG4gICAgc2V0UGhvdG9FcnJvcignJylcclxuICAgIGlmICghZmlsZSkgcmV0dXJuXHJcblxyXG4gICAgY29uc3QgYWxsb3dlZFR5cGVzID0gWydpbWFnZS9qcGVnJywgJ2ltYWdlL3BuZyddXHJcbiAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7XHJcbiAgICAgIHNldFBob3RvRXJyb3IoJ0xlIGZpY2hpZXIgZG9pdCDDqnRyZSB1bmUgaW1hZ2UgYXUgZm9ybWF0IEpQRyBvdSBQTkcuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGZpbGUuc2l6ZSA+IE1BWF9GSUxFX1NJWkUpIHtcclxuICAgICAgc2V0UGhvdG9FcnJvcignTGEgcGhvdG8gZG9pdCBmYWlyZSAyIE1vIG1heGltdW0uJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKVxyXG4gICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gdHlwZW9mIHJlYWRlci5yZXN1bHQgPT09ICdzdHJpbmcnID8gcmVhZGVyLnJlc3VsdCA6ICcnXHJcbiAgICAgIHNldFBob3RvKHJlc3VsdClcclxuICAgICAgc2V0U2F2ZWQoZmFsc2UpXHJcbiAgICB9XHJcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2F2ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgc2V0UGhvdG9FcnJvcignJylcclxuXHJcbiAgICBpZiAocGFzc3dvcmQgJiYgcGFzc3dvcmQgIT09IHBhc3N3b3JkQ29uZmlybWF0aW9uKSB7XHJcbiAgICAgIHNldEVycm9yKCdMZXMgbW90cyBkZSBwYXNzZSBuZSBjb3JyZXNwb25kZW50IHBhcy4nKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwcm9maWxlID0gYXdhaXQgdXBkYXRlUHJvZmlsZSh7XHJcbiAgICAgICAgbmFtZTogbmFtZS50cmltKCkgfHwgaW5pdGlhbE5hbWUsXHJcbiAgICAgICAgZW1haWwsXHJcbiAgICAgICAgcHJvZmlsZV9waG90bzogcGhvdG8sXHJcbiAgICAgICAgLi4uKHBhc3N3b3JkID8geyBwYXNzd29yZCB9IDoge30pLFxyXG4gICAgICB9KVxyXG5cclxuICAgICAgb25TYXZlTmFtZShwcm9maWxlLm5hbWUpXHJcbiAgICAgIG9uU2F2ZVBob3RvKHByb2ZpbGUucHJvZmlsZV9waG90byA/PyAnJylcclxuICAgICAgc2V0TmFtZShwcm9maWxlLm5hbWUpXHJcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxyXG4gICAgICBzZXRQYXNzd29yZENvbmZpcm1hdGlvbignJylcclxuICAgICAgc2V0U2F2ZWQodHJ1ZSlcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTYXZlZChmYWxzZSksIDI1MDApXHJcbiAgICB9IGNhdGNoIChzYXZlRXJyb3IpIHtcclxuICAgICAgc2V0RXJyb3IoZ2V0QXBpRXJyb3Ioc2F2ZUVycm9yKSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGNvbmZpcm1EZWxldGVBY2NvdW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0RXJyb3IoJycpXHJcbiAgICBpZiAoZGVsZXRlQ29uZmlybWF0aW9uICE9PSAnU1VQUFJJTUVSJykge1xyXG4gICAgICBzZXRFcnJvcignU2Fpc2lzc2V6IFNVUFBSSU1FUiBwb3VyIGNvbmZpcm1lciBsYSBzdXBwcmVzc2lvbiBkw6lmaW5pdGl2ZS4nKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuICAgIGlmICghZGVsZXRlUGFzc3dvcmQpIHtcclxuICAgICAgc2V0RXJyb3IoJ1NhaXNpc3NleiB2b3RyZSBtb3QgZGUgcGFzc2UgYWN0dWVsIHBvdXIgY29uZmlybWVyLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIHNldERlbGV0aW5nQWNjb3VudCh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZGVsZXRlQWNjb3VudFJlcXVlc3QoZGVsZXRlUGFzc3dvcmQpXHJcbiAgICAgIG9uQWNjb3VudERlbGV0ZWQocmVzdWx0LmZpbGVzX2NsZWFudXBfcGVuZGluZylcclxuICAgIH0gY2F0Y2ggKGRlbGV0ZUVycm9yKSB7XHJcbiAgICAgIHNldEVycm9yKGdldEFwaUVycm9yKGRlbGV0ZUVycm9yKSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldERlbGV0aW5nQWNjb3VudChmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLXBhZ2VcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1wYWdlLWlubmVyXCI+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJzZXR0aW5ncy1iYWNrXCIgb25DbGljaz17b25CYWNrfT48QXJyb3dMZWZ0IHNpemU9ezE2fSAvPiBSZXRvdXIgw6AgbOKAmWFuYWx5c2U8L2J1dHRvbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWhlYWRpbmdcIj5cclxuICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwid29ya3NwYWNlLWtpY2tlclwiPkNPTVBURSBVVElMSVNBVEVVUjwvc3Bhbj48aDE+UGFyYW3DqHRyZXMgZHUgcHJvZmlsPC9oMT48cD5Hw6lyZXogdm9zIGluZm9ybWF0aW9ucyBwZXJzb25uZWxsZXMgZXQgdm9zIHByw6lmw6lyZW5jZXMuPC9wPjwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvbiBzYXZlLXRvcFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgc2F2ZSgpfSBkaXNhYmxlZD17bG9hZGluZyB8fCBkZWxldGluZ0FjY291bnR9PlxyXG4gICAgICAgICAgICB7c2F2ZWQgPyA8PjxDaGVjayBzaXplPXsxNn0gLz4gRW5yZWdpc3Ryw6k8Lz4gOiA8PjxTYXZlIHNpemU9ezE2fSAvPiB7bG9hZGluZyA/ICdDaGFyZ2VtZW50Li4uJyA6ICdFbnJlZ2lzdHJlcid9PC8+fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3ItYmFubmVyIHNldHRpbmdzLWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvZGl2Pn1cclxuICAgICAgICB7cGhvdG9FcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImVycm9yLWJhbm5lciBzZXR0aW5ncy1lcnJvclwiIHJvbGU9XCJhbGVydFwiPntwaG90b0Vycm9yfTwvZGl2Pn1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWxheW91dFwiPlxyXG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2V0dGluZ3MtY2FyZCBwcm9maWxlLWNhcmRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1jYXJkLWhlYWRpbmdcIj48ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInNlY3Rpb24ta2lja2VyXCI+Vk9UUkUgUFJPRklMPC9zcGFuPjxoMj5JbmZvcm1hdGlvbnMgcGVyc29ubmVsbGVzPC9oMj48L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXBob3RvLXJvd1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcHJvZmlsZS1waG90byAke3Bob3RvID8gJ3Byb2ZpbGUtcGhvdG8tZmlsbGVkJyA6ICcnfWB9PntwaG90byA/IDxpbWcgc3JjPXtwaG90b30gYWx0PVwiUGhvdG8gZGUgcHJvZmlsXCIgLz4gOiA8VXNlclJvdW5kIHNpemU9ezMwfSAvPn08L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHN0cm9uZz5QaG90byBkZSBwcm9maWw8L3N0cm9uZz48cD5KUEcgb3UgUE5HLCAyIE1vIG1heGltdW0uPC9wPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHJlZj17cGhvdG9JbnB1dH0gdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS9wbmcsaW1hZ2UvanBlZ1wiIGhpZGRlbiBvbkNoYW5nZT17KGV2ZW50KSA9PiB7IGNvbnN0IGZpbGUgPSBldmVudC50YXJnZXQuZmlsZXM/LlswXTsgY2hvb3NlUGhvdG8oZmlsZSk7IGlmIChldmVudC50YXJnZXQpIGV2ZW50LnRhcmdldC52YWx1ZSA9ICcnIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInBob3RvLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHBob3RvSW5wdXQuY3VycmVudD8uY2xpY2soKX0+PENhbWVyYSBzaXplPXsxNX0gLz4gQ2hhbmdlciBsYSBwaG90bzwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGxhYmVsPk5vbSBjb21wbGV0PGlucHV0IHZhbHVlPXtuYW1lfSBvbkNoYW5nZT17KGV2ZW50KSA9PiB7IHNldE5hbWUoZXZlbnQudGFyZ2V0LnZhbHVlKTsgc2V0U2F2ZWQoZmFsc2UpIH19IC8+PC9sYWJlbD5cclxuICAgICAgICAgICAgPGxhYmVsPkVtYWlsIHByb2Zlc3Npb25uZWw8aW5wdXQgdHlwZT1cImVtYWlsXCIgdmFsdWU9e2VtYWlsfSBvbkNoYW5nZT17KGV2ZW50KSA9PiB7IHNldEVtYWlsKGV2ZW50LnRhcmdldC52YWx1ZSk7IHNldFNhdmVkKGZhbHNlKSB9fSAvPjwvbGFiZWw+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzZXR0aW5ncy1jYXJkXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtY2FyZC1oZWFkaW5nXCI+PGRpdj48c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWtpY2tlclwiPlPDiUNVUklUw4k8L3NwYW4+PGgyPk1vZGlmaWVyIGxlIG1vdCBkZSBwYXNzZTwvaDI+PC9kaXY+PExvY2tLZXlob2xlIHNpemU9ezE4fSAvPjwvZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWw+TW90IGRlIHBhc3NlIGFjdHVlbDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiIC8+PC9sYWJlbD5cclxuICAgICAgICAgICAgPGxhYmVsPk5vdXZlYXUgbW90IGRlIHBhc3NlPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIHZhbHVlPXtwYXNzd29yZH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UGFzc3dvcmQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIiAvPjwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxsYWJlbD5Db25maXJtZXIgbGUgbm91dmVhdSBtb3QgZGUgcGFzc2U8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgdmFsdWU9e3Bhc3N3b3JkQ29uZmlybWF0aW9ufSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRQYXNzd29yZENvbmZpcm1hdGlvbihldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiIC8+PC9sYWJlbD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicGFzc3dvcmQtaGludFwiPlV0aWxpc2V6IGF1IG1vaW5zIDggY2FyYWN0w6hyZXMgYXZlYyB1biBtw6lsYW5nZSBkZSBsZXR0cmVzIGV0IGRlIGNoaWZmcmVzLjwvcD5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzZXR0aW5ncy1jYXJkIGRhbmdlci16b25lXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWNhcmQtaGVhZGluZ1wiPjxkaXY+PHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi1raWNrZXIgZGFuZ2VyLWtpY2tlclwiPlpPTkUgREFOR0VSRVVTRTwvc3Bhbj48aDI+U3VwcHJpbWVyIG1vbiBjb21wdGU8L2gyPjwvZGl2PjxUcmFzaDIgc2l6ZT17MTh9IC8+PC9kaXY+XHJcbiAgICAgICAgICA8cD5MYSBzdXBwcmVzc2lvbiBlc3QgZMOpZmluaXRpdmUuIFZvdHJlIHByb2ZpbCwgdm9zIGFuYWx5c2VzLCB2b3RyZSBoaXN0b3JpcXVlIGV0IHRvdXMgdm9zIGZpY2hpZXJzIGltcG9ydMOpcyBzZXJvbnQgc3VwcHJpbcOpcy48L3A+XHJcbiAgICAgICAgICB7IXNob3dEZWxldGVDb25maXJtYXRpb24gPyAoXHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZGFuZ2VyLWJ1dHRvblwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB7IHNldEVycm9yKCcnKTsgc2V0U2hvd0RlbGV0ZUNvbmZpcm1hdGlvbih0cnVlKSB9fT5cclxuICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezE2fSAvPiBTdXBwcmltZXIgbW9uIGNvbXB0ZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsZXRlLWFjY291bnQtY29uZmlybWF0aW9uXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPk1vdCBkZSBwYXNzZSBhY3R1ZWw8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgdmFsdWU9e2RlbGV0ZVBhc3N3b3JkfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREZWxldGVQYXNzd29yZChldmVudC50YXJnZXQudmFsdWUpfSBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCIgLz48L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5TYWlzaXNzZXogU1VQUFJJTUVSIHBvdXIgY29uZmlybWVyPGlucHV0IHZhbHVlPXtkZWxldGVDb25maXJtYXRpb259IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldERlbGV0ZUNvbmZpcm1hdGlvbihldmVudC50YXJnZXQudmFsdWUpfSBhdXRvQ29tcGxldGU9XCJvZmZcIiAvPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWxldGUtYWNjb3VudC1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNldHRpbmdzLWJhY2tcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRTaG93RGVsZXRlQ29uZmlybWF0aW9uKGZhbHNlKTsgc2V0RGVsZXRlUGFzc3dvcmQoJycpOyBzZXREZWxldGVDb25maXJtYXRpb24oJycpOyBzZXRFcnJvcignJykgfX0gZGlzYWJsZWQ9e2RlbGV0aW5nQWNjb3VudH0+QW5udWxlcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJkYW5nZXItYnV0dG9uXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHZvaWQgY29uZmlybURlbGV0ZUFjY291bnQoKX0gZGlzYWJsZWQ9e2RlbGV0aW5nQWNjb3VudCB8fCBsb2FkaW5nfT5cclxuICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNn0gLz4ge2RlbGV0aW5nQWNjb3VudCA/ICdTdXBwcmVzc2lvbi4uLicgOiAnQ29uZmlybWVyIGxhIHN1cHByZXNzaW9uJ31cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufSJdfQ==