import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AnalysisBar.tsx");const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { ArrowUp, FileImage, FileSpreadsheet, FileText, FileUp, Paperclip, X } from "/node_modules/.vite/deps/lucide-react.js?v=5b99bddd";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import * as XLSX from "/node_modules/.vite/deps/xlsx.js?v=5b99bddd";
import { getApiError } from "/src/services/api.ts";
import { uploadFiles } from "/src/services/fileService.ts";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisBar.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$();
const ACCEPT_STRING = ".pdf,.doc,.docx,.csv,.xls,.xlsx,.png,.jpg,.jpeg";
const isValidFile = (file) => {
	const name = file.name.toLowerCase();
	const mime = file.type.toLowerCase();
	if (name.endsWith(".pdf") || mime.includes("pdf")) return true;
	if (name.endsWith(".doc") || name.endsWith(".docx") || mime.includes("word")) return true;
	if (name.endsWith(".csv") || mime.includes("csv")) return true;
	if (name.endsWith(".xls") || name.endsWith(".xlsx") || mime.includes("excel") || mime.includes("sheet")) return true;
	if (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || mime.includes("image")) return true;
	return false;
};
const getFileKind = (file) => {
	const name = file.name.toLowerCase();
	const mime = file.type.toLowerCase();
	if (name.endsWith(".pdf") || mime.includes("pdf")) return "pdf";
	if (name.endsWith(".doc") || name.endsWith(".docx") || mime.includes("word")) return "word";
	if (name.endsWith(".csv") || mime.includes("csv")) return "csv";
	if (name.endsWith(".xls") || name.endsWith(".xlsx") || mime.includes("excel") || mime.includes("sheet")) return "excel";
	if (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || mime.includes("image")) return "image";
	return "pdf";
};
const getFileIcon = (kind) => {
	if (kind === "image") return FileImage;
	if (kind === "excel" || kind === "csv") return FileSpreadsheet;
	if (kind === "pdf" || kind === "word") return FileText;
	return FileUp;
};
const parseExcelData = async (file) => {
	const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
	const sheetName = workbook.SheetNames[0];
	const sheet = workbook.Sheets[sheetName];
	const rows = XLSX.utils.sheet_to_json(sheet, {
		header: 1,
		raw: false
	});
	if (!rows.length) {
		return {
			columns: [],
			previewRows: [],
			rowCount: 0,
			columnCount: 0
		};
	}
	const columns = rows[0].map((header, index) => String(header ?? `Colonne ${index + 1}`));
	const previewRows = rows.slice(1, 6).map((row) => {
		const record = {};
		columns.forEach((column, index) => {
			record[column] = row[index] ?? "";
		});
		return record;
	});
	return {
		columns,
		previewRows,
		rowCount: Math.max(rows.length - 1, 0),
		columnCount: columns.length
	};
};
const buildPreview = async (file) => {
	const kind = getFileKind(file);
	if (kind === "excel") {
		const excelData = await parseExcelData(file);
		return {
			id: `${file.name}-${file.size}-${file.lastModified}`,
			file,
			kind,
			...excelData
		};
	}
	if (kind === "pdf") {
		return {
			id: `${file.name}-${file.size}-${file.lastModified}`,
			file,
			kind
		};
	}
	if (kind === "image") {
		return {
			id: `${file.name}-${file.size}-${file.lastModified}`,
			file,
			kind,
			previewUrl: URL.createObjectURL(file)
		};
	}
	return {
		id: `${file.name}-${file.size}-${file.lastModified}`,
		file,
		kind
	};
};
export function AnalysisBar({ onAnalyze }) {
	_s();
	const inputRef = useRef(null);
	const [files, setFiles] = useState([]);
	const [previews, setPreviews] = useState([]);
	const [question, setQuestion] = useState("");
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);
	const chooseFiles = async (candidates) => {
		if (!candidates) return;
		const newFiles = Array.from(candidates);
		const invalidFile = newFiles.find((file) => !isValidFile(file));
		if (invalidFile) {
			setError("Format non supporté. Utilisez un fichier PDF, Word, CSV, Excel, PNG ou JPG.");
			if (inputRef.current) inputRef.current.value = "";
			return;
		}
		const preparedFiles = await Promise.all(newFiles.map(buildPreview));
		setError("");
		setPreviews((previousPreviews) => {
			const combinedPreviews = [...previousPreviews, ...preparedFiles];
			return combinedPreviews.filter((preview, index, self) => index === self.findIndex((other) => other.file.name === preview.file.name && other.file.size === preview.file.size && other.file.lastModified === preview.file.lastModified));
		});
		setFiles((previousFiles) => {
			const combinedFiles = [...previousFiles, ...newFiles];
			return combinedFiles.filter((file, index, self) => index === self.findIndex((other) => other.name === file.name && other.size === file.size && other.lastModified === file.lastModified));
		});
		if (inputRef.current) inputRef.current.value = "";
	};
	const removeFile = (indexToRemove) => {
		setFiles((previousFiles) => previousFiles.filter((_, index) => index !== indexToRemove));
		setPreviews((previousPreviews) => previousPreviews.filter((_, index) => index !== indexToRemove));
		setError("");
	};
	const submit = async () => {
		if (files.length === 0 && !question.trim()) return;
		setLoading(true);
		setError("");
		try {
			const datasets = files.length > 0 ? await uploadFiles(files) : [];
			onAnalyze(datasets, question.trim());
		} catch (uploadError) {
			setError(getApiError(uploadError));
		} finally {
			setLoading(false);
		}
	};
	const renderPreview = (preview, index) => {
		if (preview.kind === "excel") {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "file-preview-content file-preview-table-wrap",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "file-preview-summary",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: [preview.rowCount ?? 0, " lignes"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [preview.columnCount ?? 0, " colonnes"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 11
					}, this),
					preview.columns && preview.columns.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "file-preview-columns",
						children: preview.columns.map((column, index) => /* @__PURE__ */ _jsxDEV("span", {
							className: "file-preview-column-chip",
							children: column
						}, `${column}-${index}`, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 218,
						columnNumber: 13
					}, this),
					preview.previewRows && preview.previewRows.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "file-preview-table-wrapper",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "file-preview-table",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: preview.columns?.map((column) => /* @__PURE__ */ _jsxDEV("th", { children: column }, column, false, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 23
							}, this)) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: preview.previewRows.map((row, index) => /* @__PURE__ */ _jsxDEV("tr", { children: preview.columns?.map((column) => /* @__PURE__ */ _jsxDEV("td", { children: String(row[column] ?? "") }, `${column}-${index}`, false, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 25
							}, this)) }, `${preview.file.name}-${index}`, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 21
							}, this)) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 9
			}, this);
		}
		if (preview.kind === "pdf" || preview.kind === "word") return null;
		if (preview.kind === "image" && preview.previewUrl) {
			return /* @__PURE__ */ _jsxDEV("div", {
				className: "file-preview-content file-preview-image-wrap",
				children: [/* @__PURE__ */ _jsxDEV("img", {
					src: preview.previewUrl,
					alt: preview.file.name,
					className: "file-preview-image"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 255,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "remove-image-preview-button",
					onClick: () => removeFile(index),
					disabled: loading,
					"aria-label": `Supprimer ${preview.file.name}`,
					title: `Supprimer ${preview.file.name}`,
					children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 254,
				columnNumber: 9
			}, this);
		}
		return null;
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "analysis-bar",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "analysis-bar-top",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "section-kicker",
					children: "NOUVELLE ANALYSE"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 269,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "analysis-bar-hint",
					children: "Posez une question sur vos données"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 270,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 268,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "analysis-chat-row",
				children: [/* @__PURE__ */ _jsxDEV("input", {
					className: "question-input",
					value: question,
					onChange: (event) => setQuestion(event.target.value),
					onKeyDown: (event) => {
						if (event.key === "Enter") {
							void submit();
						}
					},
					placeholder: "Posez une question sur vos données..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "send-button analysis-send",
					"aria-label": "Lancer l'analyse",
					onClick: () => void submit(),
					disabled: loading || files.length === 0 && !question.trim(),
					children: /* @__PURE__ */ _jsxDEV(ArrowUp, { size: 17 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 287,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 273,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "analysis-file-row",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "icon-button",
						onClick: () => inputRef.current?.click(),
						"aria-label": "Importer des fichiers",
						title: "Importer des fichiers",
						disabled: loading,
						children: /* @__PURE__ */ _jsxDEV(Paperclip, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 292,
						columnNumber: 9
					}, this),
					previews.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "analysis-selected-files",
						children: previews.map((preview, index) => {
							const Icon = getFileIcon(preview.kind);
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "selected-file selected-file-chip",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "selected-file-main",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "selected-file-icon",
										children: /* @__PURE__ */ _jsxDEV(Icon, { size: 15 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 58
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 303,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "selected-file-name",
										title: preview.file.name,
										children: preview.file.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 304,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "remove-file-button",
									onClick: () => removeFile(index),
									disabled: loading,
									"aria-label": `Supprimer ${preview.file.name}`,
									title: `Supprimer ${preview.file.name}`,
									children: /* @__PURE__ */ _jsxDEV(X, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 19
								}, this)]
							}, preview.id, true, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 17
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 297,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						className: "file-hint",
						children: loading ? "Import en cours..." : "Ajouter un fichier PDF, Word, CSV, Excel, image ou autre document"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 314,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						ref: inputRef,
						type: "file",
						accept: ACCEPT_STRING,
						multiple: true,
						hidden: true,
						onChange: (event) => {
							void chooseFiles(event.target.files);
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 317,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 291,
				columnNumber: 7
			}, this),
			previews.some((preview) => preview.kind === "excel" || preview.kind === "image") && /* @__PURE__ */ _jsxDEV("div", {
				className: "analysis-file-previews",
				children: previews.map((preview, index) => {
					const content = renderPreview(preview, index);
					return content ? /* @__PURE__ */ _jsxDEV("div", {
						className: "analysis-file-preview",
						children: content
					}, preview.id, false, {
						fileName: _jsxFileName,
						lineNumber: 324,
						columnNumber: 30
					}, this) : null;
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 321,
				columnNumber: 9
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "error-banner",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 329,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 267,
		columnNumber: 5
	}, this);
}
_s(AnalysisBar, "iL5xwDnaGf02XPaUtc/rLtUBr3E=");
_c = AnalysisBar;
var _c;
$RefreshReg$(_c, "AnalysisBar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AnalysisBar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/AnalysisBar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FDRSxTQUNBLFdBQ0EsaUJBQ0EsVUFDQSxRQUNBLFdBQ0EsU0FDSztBQUNQLFNBQVMsUUFBUSxnQkFBZ0I7QUFDakMsWUFBWSxVQUFVO0FBRXRCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsbUJBQXdDOzs7O0FBbUJqRCxNQUFNLGdCQUFnQjtBQUV0QixNQUFNLGVBQWUsU0FBZTtDQUNsQyxNQUFNLE9BQU8sS0FBSyxLQUFLLFlBQVk7Q0FDbkMsTUFBTSxPQUFPLEtBQUssS0FBSyxZQUFZO0NBRW5DLElBQUksS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLFNBQVMsS0FBSyxHQUFHLE9BQU87Q0FDMUQsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxPQUFPLEtBQUssS0FBSyxTQUFTLE1BQU0sR0FBRyxPQUFPO0NBQ3JGLElBQUksS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLFNBQVMsS0FBSyxHQUFHLE9BQU87Q0FDMUQsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxPQUFPLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsT0FBTyxHQUFHLE9BQU87Q0FDaEgsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsT0FBTyxHQUFHLE9BQU87Q0FFL0csT0FBTztBQUNUO0FBRUEsTUFBTSxlQUFlLFNBQXlCO0NBQzVDLE1BQU0sT0FBTyxLQUFLLEtBQUssWUFBWTtDQUNuQyxNQUFNLE9BQU8sS0FBSyxLQUFLLFlBQVk7Q0FFbkMsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxLQUFLLEdBQUcsT0FBTztDQUMxRCxJQUFJLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsTUFBTSxHQUFHLE9BQU87Q0FDckYsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxLQUFLLEdBQUcsT0FBTztDQUMxRCxJQUFJLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsT0FBTyxLQUFLLEtBQUssU0FBUyxPQUFPLEdBQUcsT0FBTztDQUNoSCxJQUFJLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLFNBQVMsT0FBTyxLQUFLLEtBQUssU0FBUyxPQUFPLEdBQUcsT0FBTztDQUMvRyxPQUFPO0FBQ1Q7QUFFQSxNQUFNLGVBQWUsU0FBbUI7Q0FDdEMsSUFBSSxTQUFTLFNBQVMsT0FBTztDQUM3QixJQUFJLFNBQVMsV0FBVyxTQUFTLE9BQU8sT0FBTztDQUMvQyxJQUFJLFNBQVMsU0FBUyxTQUFTLFFBQVEsT0FBTztDQUM5QyxPQUFPO0FBQ1Q7QUFFQSxNQUFNLGlCQUFpQixPQUFPLFNBQWU7Q0FDM0MsTUFBTSxXQUFXLEtBQUssS0FBSyxNQUFNLEtBQUssWUFBWSxHQUFHLEVBQUUsTUFBTSxRQUFRLENBQUM7Q0FDdEUsTUFBTSxZQUFZLFNBQVMsV0FBVztDQUN0QyxNQUFNLFFBQVEsU0FBUyxPQUFPO0NBQzlCLE1BQU0sT0FBTyxLQUFLLE1BQU0sY0FBYyxPQUFPO0VBQUUsUUFBUTtFQUFHLEtBQUs7Q0FBTSxDQUFDO0NBRXRFLElBQUksQ0FBQyxLQUFLLFFBQVE7RUFDaEIsT0FBTztHQUFFLFNBQVMsQ0FBQztHQUFHLGFBQWEsQ0FBQztHQUFHLFVBQVU7R0FBRyxhQUFhO0VBQUU7Q0FDckU7Q0FFQSxNQUFNLFVBQVcsS0FBSyxFQUFFLENBQTZDLEtBQUssUUFBUSxVQUFVLE9BQU8sVUFBVSxXQUFXLFFBQVEsR0FBRyxDQUFDO0NBQ3BJLE1BQU0sY0FBYyxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVE7RUFDaEQsTUFBTSxTQUFrQyxDQUFDO0VBQ3pDLFFBQVEsU0FBUyxRQUFRLFVBQVU7R0FDakMsT0FBTyxVQUFVLElBQUksVUFBVTtFQUNqQyxDQUFDO0VBQ0QsT0FBTztDQUNULENBQUM7Q0FFRCxPQUFPO0VBQ0w7RUFDQTtFQUNBLFVBQVUsS0FBSyxJQUFJLEtBQUssU0FBUyxHQUFHLENBQUM7RUFDckMsYUFBYSxRQUFRO0NBQ3ZCO0FBQ0Y7QUFFQSxNQUFNLGVBQWUsT0FBTyxTQUE2QztDQUN2RSxNQUFNLE9BQU8sWUFBWSxJQUFJO0NBRTdCLElBQUksU0FBUyxTQUFTO0VBQ3BCLE1BQU0sWUFBWSxNQUFNLGVBQWUsSUFBSTtFQUMzQyxPQUFPO0dBQ0wsSUFBSSxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUs7R0FDdEM7R0FDQTtHQUNBLEdBQUc7RUFDTDtDQUNGO0NBRUEsSUFBSSxTQUFTLE9BQU87RUFDbEIsT0FBTztHQUNMLElBQUksR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLO0dBQ3RDO0dBQ0E7RUFDRjtDQUNGO0NBRUEsSUFBSSxTQUFTLFNBQVM7RUFDcEIsT0FBTztHQUNMLElBQUksR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLO0dBQ3RDO0dBQ0E7R0FDQSxZQUFZLElBQUksZ0JBQWdCLElBQUk7RUFDdEM7Q0FDRjtDQUVBLE9BQU87RUFDTCxJQUFJLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSztFQUN0QztFQUNBO0NBQ0Y7QUFDRjtBQUVBLE9BQU8sU0FBUyxZQUFZLEVBQUUsYUFBb0I7O0NBQ2hELE1BQU0sV0FBVyxPQUF5QixJQUFJO0NBRTlDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBaUIsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBZ0MsQ0FBQyxDQUFDO0NBQ2xFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBRTVDLE1BQU0sY0FBYyxPQUFPLGVBQWdDO0VBQ3pELElBQUksQ0FBQyxZQUFZO0VBRWpCLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVTtFQUN0QyxNQUFNLGNBQWMsU0FBUyxNQUFNLFNBQVMsQ0FBQyxZQUFZLElBQUksQ0FBQztFQUU5RCxJQUFJLGFBQWE7R0FDZixTQUFTLDZFQUE2RTtHQUN0RixJQUFJLFNBQVMsU0FBUyxTQUFTLFFBQVEsUUFBUTtHQUMvQztFQUNGO0VBRUEsTUFBTSxnQkFBZ0IsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJLFlBQVksQ0FBQztFQUVsRSxTQUFTLEVBQUU7RUFDWCxhQUFhLHFCQUFxQjtHQUNoQyxNQUFNLG1CQUFtQixDQUFDLEdBQUcsa0JBQWtCLEdBQUcsYUFBYTtHQUMvRCxPQUFPLGlCQUFpQixRQUNyQixTQUFTLE9BQU8sU0FDZixVQUNBLEtBQUssV0FDRixVQUNDLE1BQU0sS0FBSyxTQUFTLFFBQVEsS0FBSyxRQUNqQyxNQUFNLEtBQUssU0FBUyxRQUFRLEtBQUssUUFDakMsTUFBTSxLQUFLLGlCQUFpQixRQUFRLEtBQUssWUFDN0MsQ0FDSjtFQUNGLENBQUM7RUFFRCxVQUFVLGtCQUFrQjtHQUMxQixNQUFNLGdCQUFnQixDQUFDLEdBQUcsZUFBZSxHQUFHLFFBQVE7R0FDcEQsT0FBTyxjQUFjLFFBQ2xCLE1BQU0sT0FBTyxTQUNaLFVBQ0EsS0FBSyxXQUNGLFVBQ0MsTUFBTSxTQUFTLEtBQUssUUFDcEIsTUFBTSxTQUFTLEtBQUssUUFDcEIsTUFBTSxpQkFBaUIsS0FBSyxZQUNoQyxDQUNKO0VBQ0YsQ0FBQztFQUVELElBQUksU0FBUyxTQUFTLFNBQVMsUUFBUSxRQUFRO0NBQ2pEO0NBRUEsTUFBTSxjQUFjLGtCQUEwQjtFQUM1QyxVQUFVLGtCQUFrQixjQUFjLFFBQVEsR0FBRyxVQUFVLFVBQVUsYUFBYSxDQUFDO0VBQ3ZGLGFBQWEscUJBQXFCLGlCQUFpQixRQUFRLEdBQUcsVUFBVSxVQUFVLGFBQWEsQ0FBQztFQUNoRyxTQUFTLEVBQUU7Q0FDYjtDQUVBLE1BQU0sU0FBUyxZQUFZO0VBQ3pCLElBQUksTUFBTSxXQUFXLEtBQUssQ0FBQyxTQUFTLEtBQUssR0FBRztFQUU1QyxXQUFXLElBQUk7RUFDZixTQUFTLEVBQUU7RUFFWCxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sU0FBUyxJQUFJLE1BQU0sWUFBWSxLQUFLLElBQUksQ0FBQztHQUNoRSxVQUFVLFVBQVUsU0FBUyxLQUFLLENBQUM7RUFDckMsU0FBUyxhQUFhO0dBQ3BCLFNBQVMsWUFBWSxXQUFXLENBQUM7RUFDbkMsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsTUFBTSxpQkFBaUIsU0FBOEIsVUFBa0I7RUFDckUsSUFBSSxRQUFRLFNBQVMsU0FBUztHQUM1QixPQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTyxRQUFRLFlBQVksR0FBRSxTQUFhOzs7O2dCQUMxQyx3QkFBQyxRQUFELGFBQU8sUUFBUSxlQUFlLEdBQUUsV0FBZTs7OztjQUM1Qzs7Ozs7O0tBQ0osUUFBUSxXQUFXLFFBQVEsUUFBUSxTQUFTLEtBQzNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFFBQVEsUUFBUSxLQUFLLFFBQVEsVUFDNUIsd0JBQUMsUUFBRDtPQUFpQyxXQUFVO2lCQUE0QjtNQUFhLEdBQXpFLEdBQUcsT0FBTyxHQUFHOzs7O2FBQTRELENBQ3JGO0tBQ0U7Ozs7O0tBRU4sUUFBUSxlQUFlLFFBQVEsWUFBWSxTQUFTLEtBQ25ELHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFELFlBQ0csUUFBUSxTQUFTLEtBQUssV0FDckIsd0JBQUMsTUFBRCxZQUFrQixPQUFXLEdBQXBCOzs7O2NBQW9CLENBQzlCLEVBQ0M7Ozs7Z0JBQ0M7Ozs7aUJBQ1Asd0JBQUMsU0FBRCxZQUNHLFFBQVEsWUFBWSxLQUFLLEtBQUssVUFDN0Isd0JBQUMsTUFBRCxZQUNHLFFBQVEsU0FBUyxLQUFLLFdBQ3JCLHdCQUFDLE1BQUQsWUFBZ0MsT0FBTyxJQUFJLFdBQVcsRUFBRSxFQUFNLEdBQXJELEdBQUcsT0FBTyxHQUFHOzs7O2NBQXdDLENBQy9ELEVBQ0MsR0FKSyxHQUFHLFFBQVEsS0FBSyxLQUFLLEdBQUc7Ozs7Y0FJN0IsQ0FDTCxFQUNJOzs7O2VBQ0Y7Ozs7OztLQUNKOzs7OztJQUVKOzs7Ozs7RUFFVDtFQUVBLElBQUksUUFBUSxTQUFTLFNBQVMsUUFBUSxTQUFTLFFBQVEsT0FBTztFQUU5RCxJQUFJLFFBQVEsU0FBUyxXQUFXLFFBQVEsWUFBWTtHQUNsRCxPQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssS0FBSyxRQUFRO0tBQVksS0FBSyxRQUFRLEtBQUs7S0FBTSxXQUFVO0lBQXNCOzs7O2NBQ3RGLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsV0FBVTtLQUE4QixlQUFlLFdBQVcsS0FBSztLQUFHLFVBQVU7S0FBUyxjQUFZLGFBQWEsUUFBUSxLQUFLO0tBQVEsT0FBTyxhQUFhLFFBQVEsS0FBSztlQUNoTSx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztJQUNSOzs7O1lBQ0w7Ozs7OztFQUVUO0VBRUEsT0FBTztDQUNUO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFpQjtJQUFzQjs7OztjQUN2RCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFvQjtJQUF3Qzs7OztZQUN6RTs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFNBQUQ7S0FDRSxXQUFVO0tBQ1YsT0FBTztLQUNQLFdBQVcsVUFBVSxZQUFZLE1BQU0sT0FBTyxLQUFLO0tBQ25ELFlBQVksVUFBVTtNQUNwQixJQUFJLE1BQU0sUUFBUSxTQUFTO09BQ3pCLEtBQUssT0FBTztNQUNkO0tBQ0Y7S0FDQSxhQUFZO0lBQ2I7Ozs7Y0FFRCx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUE0QixjQUFXO0tBQW1CLGVBQWUsS0FBSyxPQUFPO0tBQUcsVUFBVSxXQUFZLE1BQU0sV0FBVyxLQUFLLENBQUMsU0FBUyxLQUFLO2VBQ25LLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O0lBQ2Q7Ozs7WUFDTDs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFjLGVBQWUsU0FBUyxTQUFTLE1BQU07TUFBRyxjQUFXO01BQXdCLE9BQU07TUFBd0IsVUFBVTtnQkFDakssd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7S0FDaEI7Ozs7O0tBRVAsU0FBUyxTQUFTLElBQ2pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFNBQVMsS0FBSyxTQUFTLFVBQVU7T0FDaEMsTUFBTSxPQUFPLFlBQVksUUFBUSxJQUFJO09BQ3JDLE9BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFxQix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztTQUFPOzs7O21CQUM3RCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtVQUFxQixPQUFPLFFBQVEsS0FBSztvQkFBTyxRQUFRLEtBQUs7U0FBVzs7OztpQkFDckY7Ozs7O2tCQUNMLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUFxQixlQUFlLFdBQVcsS0FBSztTQUFHLFVBQVU7U0FBUyxjQUFZLGFBQWEsUUFBUSxLQUFLO1NBQVEsT0FBTyxhQUFhLFFBQVEsS0FBSzttQkFDdkwsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7UUFDUjs7OztnQkFDTDtVQVJrRCxRQUFROzs7O2NBUTFEO01BRVQsQ0FBQztLQUNFOzs7O2dCQUVMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFhLFVBQVUsdUJBQXVCO0tBQTBFOzs7OztLQUcxSSx3QkFBQyxTQUFEO01BQU8sS0FBSztNQUFVLE1BQUs7TUFBTyxRQUFRO01BQWU7TUFBUztNQUFPLFdBQVcsVUFBVTtPQUFFLEtBQUssWUFBWSxNQUFNLE9BQU8sS0FBSztNQUFFO0tBQUk7Ozs7O0lBQ3RJOzs7Ozs7R0FFSixTQUFTLE1BQU0sWUFBWSxRQUFRLFNBQVMsV0FBVyxRQUFRLFNBQVMsT0FBTyxLQUM5RSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFNBQVMsS0FBSyxTQUFTLFVBQVU7S0FDaEMsTUFBTSxVQUFVLGNBQWMsU0FBUyxLQUFLO0tBQzVDLE9BQU8sVUFBVSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBMEM7S0FBYSxHQUExQixRQUFROzs7O1lBQWtCLElBQUk7SUFDN0YsQ0FBQztHQUNFOzs7OztHQUdOLFNBQVMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZ0I7R0FBVzs7Ozs7RUFDN0M7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFuYWx5c2lzQmFyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHtcclxuICBBcnJvd1VwLFxyXG4gIEZpbGVJbWFnZSxcclxuICBGaWxlU3ByZWFkc2hlZXQsXHJcbiAgRmlsZVRleHQsXHJcbiAgRmlsZVVwLFxyXG4gIFBhcGVyY2xpcCxcclxuICBYLFxyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgKiBhcyBYTFNYIGZyb20gJ3hsc3gnXHJcblxyXG5pbXBvcnQgeyBnZXRBcGlFcnJvciB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaSdcclxuaW1wb3J0IHsgdXBsb2FkRmlsZXMsIHR5cGUgRGF0YXNldFByZXZpZXcgfSBmcm9tICcuLi9zZXJ2aWNlcy9maWxlU2VydmljZSdcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgb25BbmFseXplOiAoZGF0YXNldHM6IERhdGFzZXRQcmV2aWV3W10sIHF1ZXN0aW9uOiBzdHJpbmcpID0+IHZvaWRcclxufVxyXG5cclxudHlwZSBGaWxlS2luZCA9ICdjc3YnIHwgJ2V4Y2VsJyB8ICdwZGYnIHwgJ3dvcmQnIHwgJ2ltYWdlJ1xyXG5cclxudHlwZSBTZWxlY3RlZEZpbGVQcmV2aWV3ID0ge1xyXG4gIGlkOiBzdHJpbmdcclxuICBmaWxlOiBGaWxlXHJcbiAga2luZDogRmlsZUtpbmRcclxuICByb3dDb3VudD86IG51bWJlclxyXG4gIGNvbHVtbkNvdW50PzogbnVtYmVyXHJcbiAgY29sdW1ucz86IHN0cmluZ1tdXHJcbiAgcHJldmlld1Jvd3M/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdXHJcbiAgcHJldmlld1VybD86IHN0cmluZ1xyXG59XHJcblxyXG5jb25zdCBBQ0NFUFRfU1RSSU5HID0gJy5wZGYsLmRvYywuZG9jeCwuY3N2LC54bHMsLnhsc3gsLnBuZywuanBnLC5qcGVnJ1xyXG5cclxuY29uc3QgaXNWYWxpZEZpbGUgPSAoZmlsZTogRmlsZSkgPT4ge1xyXG4gIGNvbnN0IG5hbWUgPSBmaWxlLm5hbWUudG9Mb3dlckNhc2UoKVxyXG4gIGNvbnN0IG1pbWUgPSBmaWxlLnR5cGUudG9Mb3dlckNhc2UoKVxyXG5cclxuICBpZiAobmFtZS5lbmRzV2l0aCgnLnBkZicpIHx8IG1pbWUuaW5jbHVkZXMoJ3BkZicpKSByZXR1cm4gdHJ1ZVxyXG4gIGlmIChuYW1lLmVuZHNXaXRoKCcuZG9jJykgfHwgbmFtZS5lbmRzV2l0aCgnLmRvY3gnKSB8fCBtaW1lLmluY2x1ZGVzKCd3b3JkJykpIHJldHVybiB0cnVlXHJcbiAgaWYgKG5hbWUuZW5kc1dpdGgoJy5jc3YnKSB8fCBtaW1lLmluY2x1ZGVzKCdjc3YnKSkgcmV0dXJuIHRydWVcclxuICBpZiAobmFtZS5lbmRzV2l0aCgnLnhscycpIHx8IG5hbWUuZW5kc1dpdGgoJy54bHN4JykgfHwgbWltZS5pbmNsdWRlcygnZXhjZWwnKSB8fCBtaW1lLmluY2x1ZGVzKCdzaGVldCcpKSByZXR1cm4gdHJ1ZVxyXG4gIGlmIChuYW1lLmVuZHNXaXRoKCcucG5nJykgfHwgbmFtZS5lbmRzV2l0aCgnLmpwZycpIHx8IG5hbWUuZW5kc1dpdGgoJy5qcGVnJykgfHwgbWltZS5pbmNsdWRlcygnaW1hZ2UnKSkgcmV0dXJuIHRydWVcclxuXHJcbiAgcmV0dXJuIGZhbHNlXHJcbn1cclxuXHJcbmNvbnN0IGdldEZpbGVLaW5kID0gKGZpbGU6IEZpbGUpOiBGaWxlS2luZCA9PiB7XHJcbiAgY29uc3QgbmFtZSA9IGZpbGUubmFtZS50b0xvd2VyQ2FzZSgpXHJcbiAgY29uc3QgbWltZSA9IGZpbGUudHlwZS50b0xvd2VyQ2FzZSgpXHJcblxyXG4gIGlmIChuYW1lLmVuZHNXaXRoKCcucGRmJykgfHwgbWltZS5pbmNsdWRlcygncGRmJykpIHJldHVybiAncGRmJ1xyXG4gIGlmIChuYW1lLmVuZHNXaXRoKCcuZG9jJykgfHwgbmFtZS5lbmRzV2l0aCgnLmRvY3gnKSB8fCBtaW1lLmluY2x1ZGVzKCd3b3JkJykpIHJldHVybiAnd29yZCdcclxuICBpZiAobmFtZS5lbmRzV2l0aCgnLmNzdicpIHx8IG1pbWUuaW5jbHVkZXMoJ2NzdicpKSByZXR1cm4gJ2NzdidcclxuICBpZiAobmFtZS5lbmRzV2l0aCgnLnhscycpIHx8IG5hbWUuZW5kc1dpdGgoJy54bHN4JykgfHwgbWltZS5pbmNsdWRlcygnZXhjZWwnKSB8fCBtaW1lLmluY2x1ZGVzKCdzaGVldCcpKSByZXR1cm4gJ2V4Y2VsJ1xyXG4gIGlmIChuYW1lLmVuZHNXaXRoKCcucG5nJykgfHwgbmFtZS5lbmRzV2l0aCgnLmpwZycpIHx8IG5hbWUuZW5kc1dpdGgoJy5qcGVnJykgfHwgbWltZS5pbmNsdWRlcygnaW1hZ2UnKSkgcmV0dXJuICdpbWFnZSdcclxuICByZXR1cm4gJ3BkZidcclxufVxyXG5cclxuY29uc3QgZ2V0RmlsZUljb24gPSAoa2luZDogRmlsZUtpbmQpID0+IHtcclxuICBpZiAoa2luZCA9PT0gJ2ltYWdlJykgcmV0dXJuIEZpbGVJbWFnZVxyXG4gIGlmIChraW5kID09PSAnZXhjZWwnIHx8IGtpbmQgPT09ICdjc3YnKSByZXR1cm4gRmlsZVNwcmVhZHNoZWV0XHJcbiAgaWYgKGtpbmQgPT09ICdwZGYnIHx8IGtpbmQgPT09ICd3b3JkJykgcmV0dXJuIEZpbGVUZXh0XHJcbiAgcmV0dXJuIEZpbGVVcFxyXG59XHJcblxyXG5jb25zdCBwYXJzZUV4Y2VsRGF0YSA9IGFzeW5jIChmaWxlOiBGaWxlKSA9PiB7XHJcbiAgY29uc3Qgd29ya2Jvb2sgPSBYTFNYLnJlYWQoYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpLCB7IHR5cGU6ICdhcnJheScgfSlcclxuICBjb25zdCBzaGVldE5hbWUgPSB3b3JrYm9vay5TaGVldE5hbWVzWzBdXHJcbiAgY29uc3Qgc2hlZXQgPSB3b3JrYm9vay5TaGVldHNbc2hlZXROYW1lXVxyXG4gIGNvbnN0IHJvd3MgPSBYTFNYLnV0aWxzLnNoZWV0X3RvX2pzb24oc2hlZXQsIHsgaGVhZGVyOiAxLCByYXc6IGZhbHNlIH0pIGFzIEFycmF5PEFycmF5PHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCBudWxsPj5cclxuXHJcbiAgaWYgKCFyb3dzLmxlbmd0aCkge1xyXG4gICAgcmV0dXJuIHsgY29sdW1uczogW10sIHByZXZpZXdSb3dzOiBbXSwgcm93Q291bnQ6IDAsIGNvbHVtbkNvdW50OiAwIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSAocm93c1swXSBhcyBBcnJheTxzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgbnVsbD4pLm1hcCgoaGVhZGVyLCBpbmRleCkgPT4gU3RyaW5nKGhlYWRlciA/PyBgQ29sb25uZSAke2luZGV4ICsgMX1gKSlcclxuICBjb25zdCBwcmV2aWV3Um93cyA9IHJvd3Muc2xpY2UoMSwgNikubWFwKChyb3cpID0+IHtcclxuICAgIGNvbnN0IHJlY29yZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fVxyXG4gICAgY29sdW1ucy5mb3JFYWNoKChjb2x1bW4sIGluZGV4KSA9PiB7XHJcbiAgICAgIHJlY29yZFtjb2x1bW5dID0gcm93W2luZGV4XSA/PyAnJ1xyXG4gICAgfSlcclxuICAgIHJldHVybiByZWNvcmRcclxuICB9KVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY29sdW1ucyxcclxuICAgIHByZXZpZXdSb3dzLFxyXG4gICAgcm93Q291bnQ6IE1hdGgubWF4KHJvd3MubGVuZ3RoIC0gMSwgMCksXHJcbiAgICBjb2x1bW5Db3VudDogY29sdW1ucy5sZW5ndGgsXHJcbiAgfVxyXG59XHJcblxyXG5jb25zdCBidWlsZFByZXZpZXcgPSBhc3luYyAoZmlsZTogRmlsZSk6IFByb21pc2U8U2VsZWN0ZWRGaWxlUHJldmlldz4gPT4ge1xyXG4gIGNvbnN0IGtpbmQgPSBnZXRGaWxlS2luZChmaWxlKVxyXG5cclxuICBpZiAoa2luZCA9PT0gJ2V4Y2VsJykge1xyXG4gICAgY29uc3QgZXhjZWxEYXRhID0gYXdhaXQgcGFyc2VFeGNlbERhdGEoZmlsZSlcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGlkOiBgJHtmaWxlLm5hbWV9LSR7ZmlsZS5zaXplfS0ke2ZpbGUubGFzdE1vZGlmaWVkfWAsXHJcbiAgICAgIGZpbGUsXHJcbiAgICAgIGtpbmQsXHJcbiAgICAgIC4uLmV4Y2VsRGF0YSxcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlmIChraW5kID09PSAncGRmJykge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgaWQ6IGAke2ZpbGUubmFtZX0tJHtmaWxlLnNpemV9LSR7ZmlsZS5sYXN0TW9kaWZpZWR9YCxcclxuICAgICAgZmlsZSxcclxuICAgICAga2luZCxcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlmIChraW5kID09PSAnaW1hZ2UnKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBpZDogYCR7ZmlsZS5uYW1lfS0ke2ZpbGUuc2l6ZX0tJHtmaWxlLmxhc3RNb2RpZmllZH1gLFxyXG4gICAgICBmaWxlLFxyXG4gICAgICBraW5kLFxyXG4gICAgICBwcmV2aWV3VXJsOiBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpLFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGlkOiBgJHtmaWxlLm5hbWV9LSR7ZmlsZS5zaXplfS0ke2ZpbGUubGFzdE1vZGlmaWVkfWAsXHJcbiAgICBmaWxlLFxyXG4gICAga2luZCxcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBbmFseXNpc0Jhcih7IG9uQW5hbHl6ZSB9OiBQcm9wcykge1xyXG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpXHJcblxyXG4gIGNvbnN0IFtmaWxlcywgc2V0RmlsZXNdID0gdXNlU3RhdGU8RmlsZVtdPihbXSlcclxuICBjb25zdCBbcHJldmlld3MsIHNldFByZXZpZXdzXSA9IHVzZVN0YXRlPFNlbGVjdGVkRmlsZVByZXZpZXdbXT4oW10pXHJcbiAgY29uc3QgW3F1ZXN0aW9uLCBzZXRRdWVzdGlvbl0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG5cclxuICBjb25zdCBjaG9vc2VGaWxlcyA9IGFzeW5jIChjYW5kaWRhdGVzOiBGaWxlTGlzdCB8IG51bGwpID0+IHtcclxuICAgIGlmICghY2FuZGlkYXRlcykgcmV0dXJuXHJcblxyXG4gICAgY29uc3QgbmV3RmlsZXMgPSBBcnJheS5mcm9tKGNhbmRpZGF0ZXMpXHJcbiAgICBjb25zdCBpbnZhbGlkRmlsZSA9IG5ld0ZpbGVzLmZpbmQoKGZpbGUpID0+ICFpc1ZhbGlkRmlsZShmaWxlKSlcclxuXHJcbiAgICBpZiAoaW52YWxpZEZpbGUpIHtcclxuICAgICAgc2V0RXJyb3IoJ0Zvcm1hdCBub24gc3VwcG9ydMOpLiBVdGlsaXNleiB1biBmaWNoaWVyIFBERiwgV29yZCwgQ1NWLCBFeGNlbCwgUE5HIG91IEpQRy4nKVxyXG4gICAgICBpZiAoaW5wdXRSZWYuY3VycmVudCkgaW5wdXRSZWYuY3VycmVudC52YWx1ZSA9ICcnXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHByZXBhcmVkRmlsZXMgPSBhd2FpdCBQcm9taXNlLmFsbChuZXdGaWxlcy5tYXAoYnVpbGRQcmV2aWV3KSlcclxuXHJcbiAgICBzZXRFcnJvcignJylcclxuICAgIHNldFByZXZpZXdzKChwcmV2aW91c1ByZXZpZXdzKSA9PiB7XHJcbiAgICAgIGNvbnN0IGNvbWJpbmVkUHJldmlld3MgPSBbLi4ucHJldmlvdXNQcmV2aWV3cywgLi4ucHJlcGFyZWRGaWxlc11cclxuICAgICAgcmV0dXJuIGNvbWJpbmVkUHJldmlld3MuZmlsdGVyKFxyXG4gICAgICAgIChwcmV2aWV3LCBpbmRleCwgc2VsZikgPT5cclxuICAgICAgICAgIGluZGV4ID09PVxyXG4gICAgICAgICAgc2VsZi5maW5kSW5kZXgoXHJcbiAgICAgICAgICAgIChvdGhlcikgPT5cclxuICAgICAgICAgICAgICBvdGhlci5maWxlLm5hbWUgPT09IHByZXZpZXcuZmlsZS5uYW1lICYmXHJcbiAgICAgICAgICAgICAgb3RoZXIuZmlsZS5zaXplID09PSBwcmV2aWV3LmZpbGUuc2l6ZSAmJlxyXG4gICAgICAgICAgICAgIG90aGVyLmZpbGUubGFzdE1vZGlmaWVkID09PSBwcmV2aWV3LmZpbGUubGFzdE1vZGlmaWVkXHJcbiAgICAgICAgICApXHJcbiAgICAgIClcclxuICAgIH0pXHJcblxyXG4gICAgc2V0RmlsZXMoKHByZXZpb3VzRmlsZXMpID0+IHtcclxuICAgICAgY29uc3QgY29tYmluZWRGaWxlcyA9IFsuLi5wcmV2aW91c0ZpbGVzLCAuLi5uZXdGaWxlc11cclxuICAgICAgcmV0dXJuIGNvbWJpbmVkRmlsZXMuZmlsdGVyKFxyXG4gICAgICAgIChmaWxlLCBpbmRleCwgc2VsZikgPT5cclxuICAgICAgICAgIGluZGV4ID09PVxyXG4gICAgICAgICAgc2VsZi5maW5kSW5kZXgoXHJcbiAgICAgICAgICAgIChvdGhlcikgPT5cclxuICAgICAgICAgICAgICBvdGhlci5uYW1lID09PSBmaWxlLm5hbWUgJiZcclxuICAgICAgICAgICAgICBvdGhlci5zaXplID09PSBmaWxlLnNpemUgJiZcclxuICAgICAgICAgICAgICBvdGhlci5sYXN0TW9kaWZpZWQgPT09IGZpbGUubGFzdE1vZGlmaWVkXHJcbiAgICAgICAgICApXHJcbiAgICAgIClcclxuICAgIH0pXHJcblxyXG4gICAgaWYgKGlucHV0UmVmLmN1cnJlbnQpIGlucHV0UmVmLmN1cnJlbnQudmFsdWUgPSAnJ1xyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVtb3ZlRmlsZSA9IChpbmRleFRvUmVtb3ZlOiBudW1iZXIpID0+IHtcclxuICAgIHNldEZpbGVzKChwcmV2aW91c0ZpbGVzKSA9PiBwcmV2aW91c0ZpbGVzLmZpbHRlcigoXywgaW5kZXgpID0+IGluZGV4ICE9PSBpbmRleFRvUmVtb3ZlKSlcclxuICAgIHNldFByZXZpZXdzKChwcmV2aW91c1ByZXZpZXdzKSA9PiBwcmV2aW91c1ByZXZpZXdzLmZpbHRlcigoXywgaW5kZXgpID0+IGluZGV4ICE9PSBpbmRleFRvUmVtb3ZlKSlcclxuICAgIHNldEVycm9yKCcnKVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGZpbGVzLmxlbmd0aCA9PT0gMCAmJiAhcXVlc3Rpb24udHJpbSgpKSByZXR1cm5cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpXHJcbiAgICBzZXRFcnJvcignJylcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBkYXRhc2V0cyA9IGZpbGVzLmxlbmd0aCA+IDAgPyBhd2FpdCB1cGxvYWRGaWxlcyhmaWxlcykgOiBbXVxyXG4gICAgICBvbkFuYWx5emUoZGF0YXNldHMsIHF1ZXN0aW9uLnRyaW0oKSlcclxuICAgIH0gY2F0Y2ggKHVwbG9hZEVycm9yKSB7XHJcbiAgICAgIHNldEVycm9yKGdldEFwaUVycm9yKHVwbG9hZEVycm9yKSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCByZW5kZXJQcmV2aWV3ID0gKHByZXZpZXc6IFNlbGVjdGVkRmlsZVByZXZpZXcsIGluZGV4OiBudW1iZXIpID0+IHtcclxuICAgIGlmIChwcmV2aWV3LmtpbmQgPT09ICdleGNlbCcpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy1jb250ZW50IGZpbGUtcHJldmlldy10YWJsZS13cmFwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy1zdW1tYXJ5XCI+XHJcbiAgICAgICAgICAgIDxzcGFuPntwcmV2aWV3LnJvd0NvdW50ID8/IDB9IGxpZ25lczwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3ByZXZpZXcuY29sdW1uQ291bnQgPz8gMH0gY29sb25uZXM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIHtwcmV2aWV3LmNvbHVtbnMgJiYgcHJldmlldy5jb2x1bW5zLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy1jb2x1bW5zXCI+XHJcbiAgICAgICAgICAgICAge3ByZXZpZXcuY29sdW1ucy5tYXAoKGNvbHVtbiwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGtleT17YCR7Y29sdW1ufS0ke2luZGV4fWB9IGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy1jb2x1bW4tY2hpcFwiPntjb2x1bW59PC9zcGFuPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICB7cHJldmlldy5wcmV2aWV3Um93cyAmJiBwcmV2aWV3LnByZXZpZXdSb3dzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy10YWJsZS13cmFwcGVyXCI+XHJcbiAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy10YWJsZVwiPlxyXG4gICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAge3ByZXZpZXcuY29sdW1ucz8ubWFwKChjb2x1bW4pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBrZXk9e2NvbHVtbn0+e2NvbHVtbn08L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAge3ByZXZpZXcucHJldmlld1Jvd3MubWFwKChyb3csIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17YCR7cHJldmlldy5maWxlLm5hbWV9LSR7aW5kZXh9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cHJldmlldy5jb2x1bW5zPy5tYXAoKGNvbHVtbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQga2V5PXtgJHtjb2x1bW59LSR7aW5kZXh9YH0+e1N0cmluZyhyb3dbY29sdW1uXSA/PyAnJyl9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBpZiAocHJldmlldy5raW5kID09PSAncGRmJyB8fCBwcmV2aWV3LmtpbmQgPT09ICd3b3JkJykgcmV0dXJuIG51bGxcclxuXHJcbiAgICBpZiAocHJldmlldy5raW5kID09PSAnaW1hZ2UnICYmIHByZXZpZXcucHJldmlld1VybCkge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsZS1wcmV2aWV3LWNvbnRlbnQgZmlsZS1wcmV2aWV3LWltYWdlLXdyYXBcIj5cclxuICAgICAgICAgIDxpbWcgc3JjPXtwcmV2aWV3LnByZXZpZXdVcmx9IGFsdD17cHJldmlldy5maWxlLm5hbWV9IGNsYXNzTmFtZT1cImZpbGUtcHJldmlldy1pbWFnZVwiIC8+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJyZW1vdmUtaW1hZ2UtcHJldmlldy1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiByZW1vdmVGaWxlKGluZGV4KX0gZGlzYWJsZWQ9e2xvYWRpbmd9IGFyaWEtbGFiZWw9e2BTdXBwcmltZXIgJHtwcmV2aWV3LmZpbGUubmFtZX1gfSB0aXRsZT17YFN1cHByaW1lciAke3ByZXZpZXcuZmlsZS5uYW1lfWB9PlxyXG4gICAgICAgICAgICA8WCBzaXplPXsxNH0gLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG51bGxcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJhbmFseXNpcy1iYXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmFseXNpcy1iYXItdG9wXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi1raWNrZXJcIj5OT1VWRUxMRSBBTkFMWVNFPC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFuYWx5c2lzLWJhci1oaW50XCI+UG9zZXogdW5lIHF1ZXN0aW9uIHN1ciB2b3MgZG9ubsOpZXM8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmFseXNpcy1jaGF0LXJvd1wiPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicXVlc3Rpb24taW5wdXRcIlxyXG4gICAgICAgICAgdmFsdWU9e3F1ZXN0aW9ufVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UXVlc3Rpb24oZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFbnRlcicpIHtcclxuICAgICAgICAgICAgICB2b2lkIHN1Ym1pdCgpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBvc2V6IHVuZSBxdWVzdGlvbiBzdXIgdm9zIGRvbm7DqWVzLi4uXCJcclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNlbmQtYnV0dG9uIGFuYWx5c2lzLXNlbmRcIiBhcmlhLWxhYmVsPVwiTGFuY2VyIGwnYW5hbHlzZVwiIG9uQ2xpY2s9eygpID0+IHZvaWQgc3VibWl0KCl9IGRpc2FibGVkPXtsb2FkaW5nIHx8IChmaWxlcy5sZW5ndGggPT09IDAgJiYgIXF1ZXN0aW9uLnRyaW0oKSl9PlxyXG4gICAgICAgICAgPEFycm93VXAgc2l6ZT17MTd9IC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmFseXNpcy1maWxlLXJvd1wiPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImljb24tYnV0dG9uXCIgb25DbGljaz17KCkgPT4gaW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX0gYXJpYS1sYWJlbD1cIkltcG9ydGVyIGRlcyBmaWNoaWVyc1wiIHRpdGxlPVwiSW1wb3J0ZXIgZGVzIGZpY2hpZXJzXCIgZGlzYWJsZWQ9e2xvYWRpbmd9PlxyXG4gICAgICAgICAgPFBhcGVyY2xpcCBzaXplPXsxN30gLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAge3ByZXZpZXdzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuYWx5c2lzLXNlbGVjdGVkLWZpbGVzXCI+XHJcbiAgICAgICAgICAgIHtwcmV2aWV3cy5tYXAoKHByZXZpZXcsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGdldEZpbGVJY29uKHByZXZpZXcua2luZClcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWxlY3RlZC1maWxlIHNlbGVjdGVkLWZpbGUtY2hpcFwiIGtleT17cHJldmlldy5pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VsZWN0ZWQtZmlsZS1tYWluXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VsZWN0ZWQtZmlsZS1pY29uXCI+PEljb24gc2l6ZT17MTV9IC8+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlbGVjdGVkLWZpbGUtbmFtZVwiIHRpdGxlPXtwcmV2aWV3LmZpbGUubmFtZX0+e3ByZXZpZXcuZmlsZS5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJlbW92ZS1maWxlLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHJlbW92ZUZpbGUoaW5kZXgpfSBkaXNhYmxlZD17bG9hZGluZ30gYXJpYS1sYWJlbD17YFN1cHByaW1lciAke3ByZXZpZXcuZmlsZS5uYW1lfWB9IHRpdGxlPXtgU3VwcHJpbWVyICR7cHJldmlldy5maWxlLm5hbWV9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmaWxlLWhpbnRcIj57bG9hZGluZyA/ICdJbXBvcnQgZW4gY291cnMuLi4nIDogJ0Fqb3V0ZXIgdW4gZmljaGllciBQREYsIFdvcmQsIENTViwgRXhjZWwsIGltYWdlIG91IGF1dHJlIGRvY3VtZW50J308L3NwYW4+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPGlucHV0IHJlZj17aW5wdXRSZWZ9IHR5cGU9XCJmaWxlXCIgYWNjZXB0PXtBQ0NFUFRfU1RSSU5HfSBtdWx0aXBsZSBoaWRkZW4gb25DaGFuZ2U9eyhldmVudCkgPT4geyB2b2lkIGNob29zZUZpbGVzKGV2ZW50LnRhcmdldC5maWxlcykgfX0gLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7cHJldmlld3Muc29tZSgocHJldmlldykgPT4gcHJldmlldy5raW5kID09PSAnZXhjZWwnIHx8IHByZXZpZXcua2luZCA9PT0gJ2ltYWdlJykgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5hbHlzaXMtZmlsZS1wcmV2aWV3c1wiPlxyXG4gICAgICAgICAge3ByZXZpZXdzLm1hcCgocHJldmlldywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY29udGVudCA9IHJlbmRlclByZXZpZXcocHJldmlldywgaW5kZXgpXHJcbiAgICAgICAgICAgIHJldHVybiBjb250ZW50ID8gPGRpdiBjbGFzc05hbWU9XCJhbmFseXNpcy1maWxlLXByZXZpZXdcIiBrZXk9e3ByZXZpZXcuaWR9Pntjb250ZW50fTwvZGl2PiA6IG51bGxcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3ItYmFubmVyXCI+e2Vycm9yfTwvZGl2Pn1cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn0iXX0=