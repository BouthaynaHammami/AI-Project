import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PublicSharedAnalysis.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5b99bddd";
import logoUrl from "/@fs/D:/Esprit/5 SAE/IA/AI-Project/ai-data-analyst-icon.jpg?import";
import { getPublicSharedAnalysis } from "/src/services/analysisService.ts";
import { ChartRenderer } from "/src/components/ChartRenderer.tsx";
var _jsxFileName = "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/PublicSharedAnalysis.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5b99bddd";
var _s = $RefreshSig$();
export function PublicSharedAnalysis({ token }) {
	_s();
	const [analysis, setAnalysis] = useState(null);
	const [unavailable, setUnavailable] = useState(false);
	useEffect(() => {
		let active = true;
		const previousTitle = document.title;
		const robots = document.querySelector("meta[name=\"robots\"]") ?? document.createElement("meta");
		const createdRobots = !robots.isConnected;
		robots.setAttribute("name", "robots");
		robots.setAttribute("content", "noindex, nofollow, noarchive");
		if (createdRobots) document.head.appendChild(robots);
		document.title = "Analyse partagée · AI Data Analyst";
		getPublicSharedAnalysis(token).then((result) => {
			if (active) setAnalysis(result);
		}).catch(() => {
			if (active) setUnavailable(true);
		});
		return () => {
			active = false;
			document.title = previousTitle;
			if (createdRobots) robots.remove();
		};
	}, [token]);
	let chart = null;
	try {
		chart = analysis?.chart_config ? JSON.parse(analysis.chart_config) : null;
	} catch {
		chart = null;
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "public-share-page",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "public-share-header",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "public-share-brand",
				children: [/* @__PURE__ */ _jsxDEV("img", {
					src: logoUrl,
					alt: ""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["AI Data ", /* @__PURE__ */ _jsxDEV("strong", { children: "Analyst" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 25
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "public-share-label",
				children: "Analyse partagée"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this), analysis ? /* @__PURE__ */ _jsxDEV("article", {
			className: "public-share-content",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "public-share-meta",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "workspace-kicker",
						children: "RAPPORT D’ANALYSE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("time", {
						dateTime: analysis.created_at,
						children: new Date(analysis.created_at).toLocaleString("fr-FR", {
							dateStyle: "long",
							timeStyle: "short"
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "public-share-question",
					children: /* @__PURE__ */ _jsxDEV("h1", { children: analysis.question }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "public-share-answer",
					"aria-label": "Réponse de l’analyse",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Réponse" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: analysis.answer }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 11
				}, this),
				chart && /* @__PURE__ */ _jsxDEV("section", {
					className: "public-share-chart",
					"aria-label": "Graphique de l’analyse",
					children: /* @__PURE__ */ _jsxDEV(ChartRenderer, { config: chart }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 9
		}, this) : unavailable ? /* @__PURE__ */ _jsxDEV("section", {
			className: "public-share-unavailable",
			role: "status",
			children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Ce lien n’est plus disponible" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Il a peut-être expiré ou été révoqué par son propriétaire." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("p", {
			className: "public-share-loading",
			role: "status",
			children: "Chargement de l’analyse…"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
}
_s(PublicSharedAnalysis, "67fI1uGe/9OpwqbkZwzPSzf0maA=");
_c = PublicSharedAnalysis;
var _c;
$RefreshReg$(_c, "PublicSharedAnalysis");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PublicSharedAnalysis.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/PublicSharedAnalysis.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/PublicSharedAnalysis.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Esprit/5 SAE/IA/AI-Project/frontend/src/components/PublicSharedAnalysis.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPLGFBQWE7QUFDcEIsU0FBUywrQkFBNEU7QUFFckYsU0FBUyxxQkFBcUI7Ozs7QUFNOUIsT0FBTyxTQUFTLHFCQUFxQixFQUFFLFNBQWdCOztDQUNyRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWdDLElBQUk7Q0FDcEUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUVwRCxnQkFBZ0I7RUFDZCxJQUFJLFNBQVM7RUFDYixNQUFNLGdCQUFnQixTQUFTO0VBQy9CLE1BQU0sU0FBUyxTQUFTLGNBQWMsdUJBQXFCLEtBQUssU0FBUyxjQUFjLE1BQU07RUFDN0YsTUFBTSxnQkFBZ0IsQ0FBQyxPQUFPO0VBQzlCLE9BQU8sYUFBYSxRQUFRLFFBQVE7RUFDcEMsT0FBTyxhQUFhLFdBQVcsOEJBQThCO0VBQzdELElBQUksZUFBZSxTQUFTLEtBQUssWUFBWSxNQUFNO0VBQ25ELFNBQVMsUUFBUTtFQUNqQix3QkFBd0IsS0FBSyxDQUFDLENBQzNCLE1BQU0sV0FBVztHQUNoQixJQUFJLFFBQVEsWUFBWSxNQUFNO0VBQ2hDLENBQUMsQ0FBQyxDQUNELFlBQVk7R0FDWCxJQUFJLFFBQVEsZUFBZSxJQUFJO0VBQ2pDLENBQUM7RUFDSCxhQUFhO0dBQ1gsU0FBUztHQUNULFNBQVMsUUFBUTtHQUNqQixJQUFJLGVBQWUsT0FBTyxPQUFPO0VBQ25DO0NBQ0YsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUVWLElBQUksUUFBNEI7Q0FDaEMsSUFBSTtFQUNGLFFBQVEsVUFBVSxlQUFlLEtBQUssTUFBTSxTQUFTLFlBQVksSUFBbUI7Q0FDdEYsUUFBUTtFQUNOLFFBQVE7Q0FDVjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEIsQ0FDRSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUFsQixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssS0FBSztLQUFTLEtBQUk7SUFBSTs7OztjQUMzQix3QkFBQyxRQUFELGFBQU0sWUFBUSx3QkFBQyxVQUFELFlBQVEsVUFBZTs7OztZQUFPOzs7O1lBQ3pDOzs7OzthQUNMLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQXFCO0dBQXNCOzs7O1dBQ3JEOzs7OztZQUNQLFdBQ0Msd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkI7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1CO0tBQXVCOzs7O2VBQzFELHdCQUFDLFFBQUQ7TUFBTSxVQUFVLFNBQVM7Z0JBQ3RCLElBQUksS0FBSyxTQUFTLFVBQVUsQ0FBQyxDQUFDLGVBQWUsU0FBUztPQUNyRCxXQUFXO09BQ1gsV0FBVztNQUNiLENBQUM7S0FDRzs7OzthQUNIOzs7Ozs7SUFDTCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUNqQix3QkFBQyxNQUFELFlBQUssU0FBUyxTQUFhOzs7OztJQUNwQjs7Ozs7SUFDVCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtLQUFzQixjQUFXO2VBQXBELENBQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7ZUFDZix3QkFBQyxLQUFELFlBQUksU0FBUyxPQUFVOzs7O2FBQ2hCOzs7Ozs7SUFDUixTQUNDLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO0tBQXFCLGNBQVc7ZUFDakQsd0JBQUMsZUFBRCxFQUFlLFFBQVEsTUFBUTs7Ozs7SUFDeEI7Ozs7O0dBRUo7Ozs7O2FBQ1AsY0FDRix3QkFBQyxXQUFEO0dBQVMsV0FBVTtHQUEyQixNQUFLO2FBQW5ELENBQ0Usd0JBQUMsTUFBRCxZQUFJLGdDQUFpQzs7OzthQUNyQyx3QkFBQyxLQUFELFlBQUcsNkRBQTZEOzs7O1dBQ3pEOzs7OzthQUVULHdCQUFDLEtBQUQ7R0FBRyxXQUFVO0dBQXVCLE1BQUs7YUFBUztFQUEyQjs7OztVQUUzRTs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHVibGljU2hhcmVkQW5hbHlzaXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IGxvZ29VcmwgZnJvbSAnLi4vLi4vLi4vYWktZGF0YS1hbmFseXN0LWljb24uanBnJ1xyXG5pbXBvcnQgeyBnZXRQdWJsaWNTaGFyZWRBbmFseXNpcywgdHlwZSBQdWJsaWNTaGFyZWRBbmFseXNpcyBhcyBTaGFyZWRBbmFseXNpcyB9IGZyb20gJy4uL3NlcnZpY2VzL2FuYWx5c2lzU2VydmljZSdcclxuaW1wb3J0IHR5cGUgeyBDaGFydENvbmZpZyB9IGZyb20gJy4uL3R5cGVzJ1xyXG5pbXBvcnQgeyBDaGFydFJlbmRlcmVyIH0gZnJvbSAnLi9DaGFydFJlbmRlcmVyJ1xyXG5cclxudHlwZSBQcm9wcyA9IHtcclxuICB0b2tlbjogc3RyaW5nXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQdWJsaWNTaGFyZWRBbmFseXNpcyh7IHRva2VuIH06IFByb3BzKSB7XHJcbiAgY29uc3QgW2FuYWx5c2lzLCBzZXRBbmFseXNpc10gPSB1c2VTdGF0ZTxTaGFyZWRBbmFseXNpcyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW3VuYXZhaWxhYmxlLCBzZXRVbmF2YWlsYWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBhY3RpdmUgPSB0cnVlXHJcbiAgICBjb25zdCBwcmV2aW91c1RpdGxlID0gZG9jdW1lbnQudGl0bGVcclxuICAgIGNvbnN0IHJvYm90cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ21ldGFbbmFtZT1cInJvYm90c1wiXScpID8/IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ21ldGEnKVxyXG4gICAgY29uc3QgY3JlYXRlZFJvYm90cyA9ICFyb2JvdHMuaXNDb25uZWN0ZWRcclxuICAgIHJvYm90cy5zZXRBdHRyaWJ1dGUoJ25hbWUnLCAncm9ib3RzJylcclxuICAgIHJvYm90cy5zZXRBdHRyaWJ1dGUoJ2NvbnRlbnQnLCAnbm9pbmRleCwgbm9mb2xsb3csIG5vYXJjaGl2ZScpXHJcbiAgICBpZiAoY3JlYXRlZFJvYm90cykgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChyb2JvdHMpXHJcbiAgICBkb2N1bWVudC50aXRsZSA9ICdBbmFseXNlIHBhcnRhZ8OpZSDCtyBBSSBEYXRhIEFuYWx5c3QnXHJcbiAgICBnZXRQdWJsaWNTaGFyZWRBbmFseXNpcyh0b2tlbilcclxuICAgICAgLnRoZW4oKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgIGlmIChhY3RpdmUpIHNldEFuYWx5c2lzKHJlc3VsdClcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICBpZiAoYWN0aXZlKSBzZXRVbmF2YWlsYWJsZSh0cnVlKVxyXG4gICAgICB9KVxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgYWN0aXZlID0gZmFsc2VcclxuICAgICAgZG9jdW1lbnQudGl0bGUgPSBwcmV2aW91c1RpdGxlXHJcbiAgICAgIGlmIChjcmVhdGVkUm9ib3RzKSByb2JvdHMucmVtb3ZlKClcclxuICAgIH1cclxuICB9LCBbdG9rZW5dKVxyXG5cclxuICBsZXQgY2hhcnQ6IENoYXJ0Q29uZmlnIHwgbnVsbCA9IG51bGxcclxuICB0cnkge1xyXG4gICAgY2hhcnQgPSBhbmFseXNpcz8uY2hhcnRfY29uZmlnID8gSlNPTi5wYXJzZShhbmFseXNpcy5jaGFydF9jb25maWcpIGFzIENoYXJ0Q29uZmlnIDogbnVsbFxyXG4gIH0gY2F0Y2gge1xyXG4gICAgY2hhcnQgPSBudWxsXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwicHVibGljLXNoYXJlLXBhZ2VcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJwdWJsaWMtc2hhcmUtaGVhZGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdWJsaWMtc2hhcmUtYnJhbmRcIj5cclxuICAgICAgICAgIDxpbWcgc3JjPXtsb2dvVXJsfSBhbHQ9XCJcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+QUkgRGF0YSA8c3Ryb25nPkFuYWx5c3Q8L3N0cm9uZz48L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHVibGljLXNoYXJlLWxhYmVsXCI+QW5hbHlzZSBwYXJ0YWfDqWU8L3NwYW4+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgICB7YW5hbHlzaXMgPyAoXHJcbiAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwicHVibGljLXNoYXJlLWNvbnRlbnRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHVibGljLXNoYXJlLW1ldGFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid29ya3NwYWNlLWtpY2tlclwiPlJBUFBPUlQgROKAmUFOQUxZU0U8L3NwYW4+XHJcbiAgICAgICAgICAgIDx0aW1lIGRhdGVUaW1lPXthbmFseXNpcy5jcmVhdGVkX2F0fT5cclxuICAgICAgICAgICAgICB7bmV3IERhdGUoYW5hbHlzaXMuY3JlYXRlZF9hdCkudG9Mb2NhbGVTdHJpbmcoJ2ZyLUZSJywge1xyXG4gICAgICAgICAgICAgICAgZGF0ZVN0eWxlOiAnbG9uZycsXHJcbiAgICAgICAgICAgICAgICB0aW1lU3R5bGU6ICdzaG9ydCcsXHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvdGltZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicHVibGljLXNoYXJlLXF1ZXN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxoMT57YW5hbHlzaXMucXVlc3Rpb259PC9oMT5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInB1YmxpYy1zaGFyZS1hbnN3ZXJcIiBhcmlhLWxhYmVsPVwiUsOpcG9uc2UgZGUgbOKAmWFuYWx5c2VcIj5cclxuICAgICAgICAgICAgPGgyPlLDqXBvbnNlPC9oMj5cclxuICAgICAgICAgICAgPHA+e2FuYWx5c2lzLmFuc3dlcn08L3A+XHJcbiAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICB7Y2hhcnQgJiYgKFxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwdWJsaWMtc2hhcmUtY2hhcnRcIiBhcmlhLWxhYmVsPVwiR3JhcGhpcXVlIGRlIGzigJlhbmFseXNlXCI+XHJcbiAgICAgICAgICAgICAgPENoYXJ0UmVuZGVyZXIgY29uZmlnPXtjaGFydH0gLz5cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICkgOiB1bmF2YWlsYWJsZSA/IChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwdWJsaWMtc2hhcmUtdW5hdmFpbGFibGVcIiByb2xlPVwic3RhdHVzXCI+XHJcbiAgICAgICAgICA8aDE+Q2UgbGllbiBu4oCZZXN0IHBsdXMgZGlzcG9uaWJsZTwvaDE+XHJcbiAgICAgICAgICA8cD5JbCBhIHBldXQtw6p0cmUgZXhwaXLDqSBvdSDDqXTDqSByw6l2b3F1w6kgcGFyIHNvbiBwcm9wcmnDqXRhaXJlLjwvcD5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicHVibGljLXNoYXJlLWxvYWRpbmdcIiByb2xlPVwic3RhdHVzXCI+Q2hhcmdlbWVudCBkZSBs4oCZYW5hbHlzZeKApjwvcD5cclxuICAgICAgKX1cclxuICAgIDwvbWFpbj5cclxuICApXHJcbn1cclxuIl19